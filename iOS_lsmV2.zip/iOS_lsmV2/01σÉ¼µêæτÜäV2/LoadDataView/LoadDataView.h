//
//  LoadDataView.h
//  ListenToMe
//
//  Created by zhw on 15/6/2.
//  Copyright (c) 2015年 listentome. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoadDataView : UIView

@end
