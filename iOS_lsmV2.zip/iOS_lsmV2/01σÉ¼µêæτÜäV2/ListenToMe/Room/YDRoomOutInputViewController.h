//
//  YDRoomOutInputViewController.h
//  ListenToMe
//
//  Created by afei on 15/4/10.
//  Copyright (c) 2015年 listentome. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YDRoomOutInputViewController : UIViewController{
    UITextField *mTextFInput;
}

@end
