//
//  YDBindRoomVC.h
//  ListenToMe
//
//  Created by afei on 15/4/9.
//  Copyright (c) 2015年 listentome. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YDBindRoomVC : UIViewController

@end
