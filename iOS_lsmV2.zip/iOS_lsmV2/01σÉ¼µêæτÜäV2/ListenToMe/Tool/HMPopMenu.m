//
//  HMPopMenu.m
//  ListenToMe
//
//  Created by yadong on 2/10/15.
//  Copyright (c) 2015 listentome. All rights reserved.
//

#import "HMPopMenu.h"

@interface HMPopMenu()
@property (nonatomic, strong) UIView *contentView;
/**
 *  最底部的遮盖 ：屏蔽除菜单以外控件的事件
 */
@property (nonatomic, weak) UIButton *cover;
/**
 *  容器 ：容纳具体要显示的内容contentView
 */
@property (nonatomic, weak) UIImageView *container;
@end

@implementation HMPopMenu
#pragma mark - 初始化方法
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        /** 添加菜单内部的2个子控件 **/
        // 添加一个遮盖按钮
        UIButton *cover = [[UIButton alloc] init];
        cover.backgroundColor = [UIColor clearColor];
        [cover addTarget:self action:@selector(coverClick) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:cover];
        self.cover = cover;
        
        // 添加带箭头的菜单图片
        UIImageView *container = [[UIImageView alloc] init];
        container.userInteractionEnabled = YES;
        [self addSubview:container];
        self.container = container;
        self.container.userInteractionEnabled = YES;
        
        // 默认箭头指向中间
        self.arrowPosition = HMPopMenuArrowPositionCenter;
    }
    return self;
}

- (instancetype)initWithContentView:(UIView *)contentView
{
    if (self = [super init]) {
        contentView.userInteractionEnabled = YES;
        self.contentView = contentView;
        self.contentView.userInteractionEnabled = YES;
    }
    return self;
}

+ (instancetype)popMenuWithContentView:(UIView *)contentView
{
    return [[self alloc] initWithContentView:contentView];
}


- (void)layoutSubviews
{
    [super layoutSubviews];
    
    self.cover.frame = self.bounds;
}

#pragma mark - 内部方法
- (void)coverClick
{
    [self dismiss];
}

#pragma mark - 公共方法
- (void)setDimBackground:(BOOL)dimBackground
{
    _dimBackground = dimBackground;
    
    if (dimBackground) {
        self.cover.backgroundColor = [UIColor blackColor];
        self.cover.alpha = 0.3;
    } else {
        self.cover.backgroundColor = [UIColor clearColor];
        self.cover.alpha = 1.0;
    }
}

- (void)setArrowPosition:(HMPopMenuArrowPosition)arrowPosition
{
    _arrowPosition = arrowPosition;
    
    switch (arrowPosition) {
        case HMPopMenuArrowPositionCenter:
//            self.container.image = [UIImage resizedImage:@"popover_background"];
//            self.container.image = [UIImage resizableImageWithName:@"popMenuBg@2x.png"];
            self.container.image = [UIImage imageNamed:@"popMenuBg@2x.png"];
            break;
            
        case HMPopMenuArrowPositionLeft:
//            self.container.image = [UIImage resizedImage:@"popover_background_left"];
//             self.container.image = [UIImage resizableImageWithName:@"popMenuBg@2x.png"];
            self.container.image = [UIImage imageNamed:@"popMenuBg@2x.png"];
            break;
            
        case HMPopMenuArrowPositionRight:
//            self.container.image = [UIImage resizedImage:@"popover_background_right"];
//self.container.image = [UIImage resizableImageWithName:@"popMenuBg@2x.png"];
            self.container.image = [UIImage imageNamed:@"popMenuBg@2x.png"];
            break;
    }
}

- (void)setBackground:(UIImage *)background
{ 
    self.container.image = background;
}

- (void)showInRect:(CGRect)rect
{
    // 添加菜单整体到窗口身上
    UIWindow *window = [UIApplication sharedApplication].keyWindow;
    self.frame = window.bounds;
    [window addSubview:self];
    
    // 设置容器的frame
    self.container.frame = rect;
    [self.container addSubview:self.contentView];
    
    // 设置容器里面内容的frame
    CGFloat topMargin = 0;
    CGFloat leftMargin = 0;
    CGFloat rightMargin = 0;
    CGFloat bottomMargin = 0;
    
    self.contentView.y = topMargin;
    self.contentView.x = leftMargin;
    self.contentView.width = self.container.width - leftMargin - rightMargin;
    self.contentView.height = self.container.height - topMargin - bottomMargin;
}

- (void)dismiss
{
    if ([self.delegate respondsToSelector:@selector(popMenuDidDismissed:)]) {
        [self.delegate popMenuDidDismissed:self];
    }
    
    [self removeFromSuperview];
}
@end
