//
//  YDScrollLabel.m
//  ListenToMe
//
//  Created by yadong on 2/10/15.
//  Copyright (c) 2015 listentome. All rights reserved.
//

#import "YDScrollLabel.h"

@implementation YDScrollLabel

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
