//
//  HWDBManager.m
//  ListenToMe
//
//  Created by zhw on 15/7/14.
//  Copyright (c) 2015年 listentome. All rights reserved.
//

#import "HWDBManager.h"
#import "FMDB.h"
#import "FreindMsgModel.h"


#define kMESSAGE_TYPE @"type"
#define kMESSAGE_MESSAGETYPE @"messageType"
#define kMESSAGE_FROM @"fromUserId"
#define kMESSAGE_TO @"toUserId"
#define kMESSAGE_CONTENT @"content"
#define kMESSAGE_ID @"messageId"
#define kMESSAGE_No @"messageNo"
#define kMESSAGE_TIMESEND @"timeSend"
#define kMESSAGE_TIMERECEIVE @"timeReceive"
#define kMESSAGE_ISSEND @"isSend"
#define kMESSAGE_ISREAD @"isRead"
#define kMESSAGE_SENDMUSICID @"sendMusicId"
#define kMESSAGE_SENDMUSICNAME @"sendMusicName"




@interface HWDBManager ()

@end

@implementation HWDBManager

static HWDBManager *shareDBManager;

+(HWDBManager *)shareInstance{
    static dispatch_once_t myDBManager;
    dispatch_once(&myDBManager,^{
        shareDBManager = [[HWDBManager alloc]init];
        
    });
    
    return shareDBManager;
}

-(void)dealloc{
    [db close];
}


-(FMDatabase *)openUserDB:(NSString *)userId{
   
    NSString* t =  NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)[0];
    NSString* s = [NSString stringWithFormat:@"%@/%@.db",t,userId];
    NSLog(@"---DB patch: %@",t);
    db = [[FMDatabase alloc] initWithPath:s];
    
    
    
    if (![db open]) {
        NSLog(@"数据库打开失败");
        return nil;
    };
    return db;

}

+(BOOL)createChatTableInDB:(NSString *)dbName tableName:(NSString *)tableName{
    if ([dbName length] <= 0) {
        return NO;
    }
    
    
    //根据用户ID创建一个表,每一条会话代表一张表,每一个表里只记录当前用户和另一个用户直接的消息记录
    
    FMDatabase *dbManager = [[HWDBManager shareInstance] openUserDB:dbName];
    
    
    //根据用户ID创建一个表,没一个会话记录代表一张表,每一个表里面记录着用户聊天记录,消息
    NSString *createStr=[NSString stringWithFormat:@"CREATE  TABLE IF NOT EXISTS '%@' ('messageNo' INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL  UNIQUE , 'fromUserId' VARCHAR, 'toUserId' VARCHAR, 'content' VARCHAR, 'timeSend' DATETIME,'timeReceive' DATETIME,'type' INTEGER,'messageType' INTEGER, 'messageId' VARCHAR,'isRead' INTEGER,'isSend' INTEGER, 'sendMusicId' VARCHAR, 'sendMusicName' VARCHAR)",tableName];
    
    BOOL worked = [dbManager executeUpdate:createStr];
    if (worked) {
        NSLog(@"----created DB success");
    }else{
        NSLog(@"----created DB failed");
    }
    return worked;
}


+(BOOL)haveSaveTableInDB:(NSString *)dbName tableName:(NSString *)tableName{
    if ([dbName length] <= 0) {
        return NO;
    }
    
    FMDatabase *dbManager = [[HWDBManager shareInstance] openUserDB:dbName];
    
    //根据用户ID创建一个表,没一个会话记录代表一张表,每一个表里面记录着用户聊天记录,消息
    NSString *createStr=[NSString stringWithFormat:@"CREATE  TABLE IF NOT EXISTS '%@' ('messageNo' INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL  UNIQUE , 'fromUserId' VARCHAR, 'toUserId' VARCHAR, 'content' VARCHAR, 'timeSend' DATETIME,'timeReceive' DATETIME,'type' INTEGER,'messageType' INTEGER, 'messageId' VARCHAR,'isRead' INTEGER,'isSend' INTEGER ,'sendMusicId' VARCHAR, 'sendMusicName' VARCHAR)",tableName];
    
    BOOL worked = [dbManager executeUpdate:createStr];
    if (worked) {
        NSLog(@"----created DB success");
    }else{
        NSLog(@"----created DB failed");
    }
    return worked;
}

+(BOOL)saveMessage:(NSString *)dbName tableName:(NSString *)tableName messageObject:(FreindMsgModel *)messageObject{
    if ([dbName length] <= 0) {
        return NO;
    }
    //根据用户ID创建一个表,每一条会话代表一张表,每一个表里只记录当前用户和另一个用户直接的消息记录
    
    FMDatabase *dbManager = [[HWDBManager shareInstance] openUserDB:dbName];
    
    //当发送消息,或者接收到消息时,将这条消息记录存入相对应的用户ID的表中
    NSString *insertStr=[NSString stringWithFormat:@"INSERT INTO '%@' (fromUserId,toUserId,content,type,messageType,messageId,timeSend,timeReceive,isRead,isSend,sendMusicId,sendMusicName) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",tableName];
    //添加歌曲ID歌曲名
    BOOL worked =  [dbManager executeUpdate:insertStr,messageObject.fromUserId,messageObject.toUserId,messageObject.content,[NSNumber numberWithInt:messageObject.type],messageObject.messageType,messageObject.messageId,messageObject.timeSend,messageObject.timeReceive,messageObject.isRead,messageObject.isSend,messageObject.sendMusicId,messageObject.sendMusicName];
    //    FMDBQuickCheck(worked);
    
    
    //    worked=[db executeUpdate:[NSString stringWithFormat:@"update friend set content=?,type=?,timeSend=?,newMsgs=newMsgs+1 where userId=?"],s,self.type,self.timeSend,tableName];
    
    
    if (worked) {
        NSLog(@"----insert new message to table success");
    }else{
         NSLog(@"----insert new message to table failed");
    }
    
    [[NSNotificationCenter defaultCenter]postNotificationName:kNewMsgNotifaction object:nil userInfo:[NSDictionary dictionaryWithObject:messageObject forKey:@"newMsg"]];
    
    return worked;
   
}

+(BOOL)haveSaveMessageInDB:(NSString *)dbName inTableName:(NSString *)tableName messageId:(NSString *)messageId{
    if ([dbName length] <= 0) {
        return NO;
    }
    
    FMDatabase *dbManager = [[HWDBManager shareInstance] openUserDB:dbName];
    
    FMResultSet *result = [dbManager executeQuery:[NSString stringWithFormat:@"select count(*) from '%@' where messageId=?",tableName],messageId];
    int count = 0;
    while ([result next]) {
        count = [result intForColumnIndex:0];
    }
    
    if (count != 0) {
        [result close];
        return YES;
    }else{
        [result close];
        return NO;
    }
}


+(NSMutableArray *)fetchMessageListInDB:(NSString *)dbName inTableName:(NSString *)tableName WithUserId:(NSString *)userId byPage:(int)pageIndex{
    NSMutableArray *messageListArr = [NSMutableArray array];
    FMDatabase *dbManager = [[HWDBManager shareInstance]openUserDB:dbName];
    
    FMResultSet *result = [dbManager executeQuery:[NSString stringWithFormat:@"select * from '%@' where fromUserId='%@' or toUserId='%@' order by messageId",tableName,userId,userId]];//order by timeReceive desc limit ?*20,20 //,[NSNumber numberWithInt:pageIndex] // limit ?*20,20
    while ([result next]) {
        FreindMsgModel *message = [[FreindMsgModel alloc]init];
        
        message.fromUserId = [result stringForColumn:kMESSAGE_FROM];
        message.toUserId = [result stringForColumn:kMESSAGE_TO];
        message.content = [result stringForColumn:kMESSAGE_CONTENT];
        message.timeSend = [result dateForColumn:kMESSAGE_TIMESEND];
        message.timeReceive = [result dateForColumn:kMESSAGE_TIMERECEIVE];
        message.type = [[result objectForColumnName:kMESSAGE_TYPE] intValue];
        message.messageId = [result stringForColumn:kMESSAGE_ID];
        message.messageNo = [result objectForColumnName:kMESSAGE_No];
        message.isSend = [result objectForColumnName:kMESSAGE_ISSEND];
        message.isRead = [result objectForColumnName:kMESSAGE_ISREAD];
        message.messageType = [result objectForColumnName:kMESSAGE_MESSAGETYPE];
        message.sendMusicId = [result stringForColumn:kMESSAGE_SENDMUSICID];
        message.sendMusicName = [result stringForColumn:kMESSAGE_SENDMUSICNAME];
        
        [messageListArr addObject:message];
        
    }
    [result close];
    
    return messageListArr;
}




@end
