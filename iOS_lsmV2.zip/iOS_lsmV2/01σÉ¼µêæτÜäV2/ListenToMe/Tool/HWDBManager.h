//
//  HWDBManager.h
//  ListenToMe
//
//  Created by zhw on 15/7/14.
//  Copyright (c) 2015年 listentome. All rights reserved.
//

#import <Foundation/Foundation.h>

#define kNewMsgNotifaction @"newMsgNotifaction"

@class FMDatabase;
@class FreindMsgModel;
@interface HWDBManager : NSObject
{
    FMDatabase *db;
}
+(HWDBManager *)shareInstance;

/**
 *  创建用户DB数据库,并打开数据库
 *
 *  @param userId 用户的UUID
 *
 *  @return 返回db对象
 */
-(FMDatabase *)openUserDB:(NSString *)userId;

/**
 *  创建会话表
 *
 *  @param dbName    db数据库文件
 *  @param tableName 会话表名
 *
 *  @return 创建成功返回YES,创建失败返回NO
 */
+(BOOL)createChatTableInDB:(NSString *)dbName tableName:(NSString *)tableName;

/**
 *  判断数据库文件中是否已经存在相关的会话表
 *
 *  @param dbName    db数据库文件
 *  @param tableName 会话表名
 *
 *  @return 如果会话表存在则返回yes,否则返回no
 */
+(BOOL)haveSaveTableInDB:(NSString *)dbName tableName:(NSString *)tableName;

/**
 *  将消息记录存入相对应的会话表中
 *
 *  @param dbName        db数据库文件
 *  @param tableName     会话表名
 *  @param messageObject 消息对象
 *
 *  @return 存储消息成功则返回yes,失败返回no
 */
+(BOOL)saveMessage:(NSString *)dbName tableName:(NSString *)tableName messageObject:(FreindMsgModel *)messageObject;

/**
 *  查看该条消息是否已经在会话表中
 *
 *  @param dbName    db数据文件
 *  @param tableName 会话表名
 *  @param messageId 会话消息的id
 *
 *  @return 该消息存在则返回yes,否则返回no
 */
+(BOOL)haveSaveMessageInDB:(NSString *)dbName inTableName:(NSString *)tableName messageId:(NSString *)messageId;

/**
 *  查询某个会话表的消息记录
 *
 *  @param dbName    db数据库文件
 *  @param tableName 会话表
 *  @param userId    查询消息记录的用户ID
 *  @param pageIndex 从第几页开始查询
 *
 *  @return 返回一组消息记录
 */
+(NSMutableArray *)fetchMessageListInDB:(NSString *)dbName inTableName:(NSString *)tableName WithUserId:(NSString *)userId byPage:(int)pageIndex;
@end
