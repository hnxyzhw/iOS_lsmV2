//
//  PIVC.h
//  ListenToMe
//
//  Created by yadong on 2/7/15.
//  Copyright (c) 2015 listentome. All rights reserved.
//  个人信息

#import <UIKit/UIKit.h>

@interface PIVC : YDBaseVC
@property(nonatomic,strong)NSMutableArray *array;

@end
