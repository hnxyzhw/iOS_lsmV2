//
//  MyKSongMemoryVC.h
//  ListenToMe
//
//  Created by zhw on 15/7/22.
//  Copyright (c) 2015年 listentome. All rights reserved.
//

#import "YDBaseVC.h"

@interface MyKSongMemoryVC : YDBaseVC
@property(nonatomic,assign) int64_t uuid;
@property(nonatomic,assign) int32_t iOffset;
@property(nonatomic,assign) int32_t iNum;
@property(nonatomic,assign) int64_t lWatchUserId;
/**
 *  是否是从个人中心页面跳转进入的
 */
@property(nonatomic,assign)BOOL isPushFromPerCenter;
@end
