//
//  MyKSongMemoryVC.m
//  ListenToMe
//
//  Created by zhw on 15/7/22.
//  Copyright (c) 2015年 listentome. All rights reserved.
//

#import "MyKSongMemoryVC.h"
#import "MyWorksVC.h"
#import "MyBookVC.h"
#import "CommemorateCommentListVC.h"

@interface MyKSongMemoryVC ()<MyBookVCDelegate>
/**
 *  查看我的纪念册
 */
@property(nonatomic,strong)UIButton *btnCheckMyBook;
/**
 *  查看我的单曲,音乐作品
 */
@property(nonatomic,strong)UIButton *btnCheckMyWorks;
/**
 *  纪念册
 */
@property(nonatomic,strong)MyBookVC *myBookVC;
/**
 *  单曲
 */
@property(nonatomic,strong)MyWorksVC *myWorksVC;
@end

@implementation MyKSongMemoryVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.navigationItem.title = @"我的K歌回忆";
    
    [self setNavigation];
    
    //布局子视图
    
    [self setUI];
    
}

#pragma mark 导航栏
-(void)setNavigation
{
    //    self.navigationItem.title = @"我的相册";
    [self setLeftBtnItem];
    [self setRightBtnItem];
}

// 导航栏左边的Btn
-(void)setLeftBtnItem
{
    UIButton *leftBtn = [[UIButton alloc]init];
    UIImage *leftBtnImg = [UIImage imageNamed:@"whiteBack.png"];
    leftBtn.frame = CGRectMake(0, 0, leftBtnImg.size.width, leftBtnImg.size.height);
    [leftBtn setImage:leftBtnImg forState:UIControlStateNormal];
    [leftBtn addTarget:self action:@selector(clickLeftBarBtnItem) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *customLeftBtnItem = [[UIBarButtonItem alloc]initWithCustomView:leftBtn];
    self.navigationItem.leftBarButtonItem = customLeftBtnItem;
}

// 导航栏右边的Btn
-(void)setRightBtnItem
{
    UIButton *rightBtn = [[UIButton alloc]init];
    UIImage *imgMore = [UIImage imageNamed:@"more.png"];
    rightBtn.frame = CGRectMake(0, 0, imgMore.size.width, imgMore.size.height);
    [rightBtn setImage:imgMore forState:UIControlStateNormal];
    [rightBtn addTarget:self action:@selector(clickRightBarBtnItem) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *customRightBtnItem = [[UIBarButtonItem alloc]initWithCustomView:rightBtn];
    self.navigationItem.rightBarButtonItem = customRightBtnItem;
}

#pragma mark -点击事件
-(void)clickRightBarBtnItem
{
    YDLog(@"点击了导航栏的右边按钮");
}

-(void)clickLeftBarBtnItem
{
    //    [self.navigationController popToRootViewControllerAnimated:YES];
    
    [self.navigationController popViewControllerAnimated:YES];
    YDLog(@"点击了导航栏左边的Btn");
}


#pragma mark - setUI
-(void)setUI{
    
    //查看纪念册
    CGFloat btnCheckMyBook_X = 0;
    CGFloat btnCheckMyBook_Y = 64;
    CGFloat btnCheckMyBook_W = self.view.width * 0.5;
    CGFloat btnCheckMyBook_H = 50;
    
    self.btnCheckMyBook = [[UIButton alloc]initWithFrame:CGRectMake(btnCheckMyBook_X, btnCheckMyBook_Y, btnCheckMyBook_W, btnCheckMyBook_H)];
    [self.btnCheckMyBook setTitle:@"纪念册" forState:UIControlStateNormal];
    [self.btnCheckMyBook setTitleColor:[UIColor rgbFromHexString:@"#9B9B9B" alpaa:1.0] forState:UIControlStateNormal];
    [self.btnCheckMyBook setTitleColor:[UIColor rgbFromHexString:@"#AC56FF" alpaa:1.0] forState:UIControlStateSelected];
    self.btnCheckMyBook.backgroundColor = [UIColor whiteColor];
    self.btnCheckMyBook.titleLabel.font = [UIFont systemFontOfSize:15.0];
    self.btnCheckMyBook.selected = YES;
    
    [self.btnCheckMyBook addTarget:self action:@selector(checkMyBookVC:) forControlEvents:UIControlEventTouchUpInside];
    
    [self.view addSubview:self.btnCheckMyBook];
    
    
    
    
    //查看单曲
    self.btnCheckMyWorks = [[UIButton alloc]initWithFrame:CGRectMake(btnCheckMyBook_X + btnCheckMyBook_W, btnCheckMyBook_Y, btnCheckMyBook_W, btnCheckMyBook_H)];
    [self.btnCheckMyWorks setTitle:@"单曲" forState:UIControlStateNormal];
    [self.btnCheckMyWorks setTitleColor:[UIColor rgbFromHexString:@"#9B9B9B" alpaa:1.0] forState:UIControlStateNormal];
    [self.btnCheckMyWorks setTitleColor:[UIColor rgbFromHexString:@"#AC56FF" alpaa:1.0] forState:UIControlStateSelected];
    self.btnCheckMyWorks.titleLabel.font = [UIFont systemFontOfSize:15.0];
    self.btnCheckMyWorks.backgroundColor = [UIColor whiteColor];
    self.btnCheckMyWorks.selected = NO;
    
    [self.btnCheckMyWorks addTarget:self action:@selector(checkMyWorksVC:) forControlEvents:UIControlEventTouchUpInside];
    
    [self.view addSubview:self.btnCheckMyWorks];
    
    //分割线
    UIImageView *lineImgView = [[UIImageView alloc]initWithFrame:CGRectMake(btnCheckMyBook_W , btnCheckMyBook_Y, 1, btnCheckMyBook_H)];
    lineImgView.backgroundColor = [UIColor rgbFromHexString:@"#9B9B9B" alpaa:1.0];
    [self.view addSubview:lineImgView];
    
    //默认显示纪念册
    self.myBookVC = [[MyBookVC alloc]init];
    self.myBookVC.view.frame= CGRectMake(0, self.btnCheckMyBook.height + naviAndStatusH, self.view.width, self.view.height - self.btnCheckMyBook.height);
    self.myBookVC.isPushFromPerCenter = YES;
    self.myBookVC.delegate = self;
    [self.view addSubview:self.myBookVC.view];
    
    
    
}


#pragma mark - 查看我的纪念册
-(void)checkMyBookVC:(UIButton *)button{
    if (!button.selected) {
        self.btnCheckMyBook.selected = YES;
        self.btnCheckMyWorks.selected = NO;
        [self.view bringSubviewToFront:self.myBookVC.view];
        
        
    }else{
        return;
    }
    
}

#pragma mark - 查看我的单曲
-(void)checkMyWorksVC:(UIButton *)button{

    if (!button.selected) {
        self.btnCheckMyBook.selected = NO;
        self.btnCheckMyWorks.selected = YES;
        
        if (!self.myWorksVC) {
            self.myWorksVC = [[MyWorksVC alloc]init];
            self.myWorksVC.isPushFromPerCenter = self.isPushFromPerCenter;
            self.myWorksVC.uuid = self.uuid;
            self.myWorksVC.iNum = self.iNum;
            self.myWorksVC.iOffset = self.iOffset;
            self.myWorksVC.lWatchUserId = self.lWatchUserId;
            self.myWorksVC.view.frame =  CGRectMake(0, self.btnCheckMyBook.height + naviAndStatusH, self.view.width, self.view.height - self.btnCheckMyBook.height - naviAndStatusH);
            self.myWorksVC.mTableViw.frame = CGRectMake(0, 0, self.myWorksVC.view.width, self.myWorksVC.view.height);
            [self.view addSubview:self.myWorksVC.view];
        }else{
            
            [self.view bringSubviewToFront:self.myWorksVC.view];
        }
        
        
        
    }else{
        return;
    }

}


#pragma mark - MYBookVCDelegate,通过代理传入要编辑的纪念册
-(void)editedCommemorate:(CommemorateBaseInfo *)commemorateBaseInfo{
    
    
    YDBaseVC *editeCommemortteVC = [[YDBaseVC alloc]init];
    editeCommemortteVC.navigationItem.title = [NSString stringWithFormat:@"编辑%@纪念册",commemorateBaseInfo.sCommName];
    [self.navigationController pushViewController:editeCommemortteVC animated:YES];
    
}


#pragma makr - MYBookVCDelegate,透过代理,传入纪念册信息,查看相关纪念册的评论列表
-(void)checkCommemorateCommentList:(CommemorateBaseInfo *)commemorateInfo{
    CommemorateCommentListVC *commemorateCommentListVC = [[CommemorateCommentListVC alloc]init];
    commemorateCommentListVC.navigationItem.title = commemorateInfo.sCommName;
    commemorateCommentListVC.commemorateBaseInfo = commemorateInfo;
    [self.navigationController pushViewController:commemorateCommentListVC animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
