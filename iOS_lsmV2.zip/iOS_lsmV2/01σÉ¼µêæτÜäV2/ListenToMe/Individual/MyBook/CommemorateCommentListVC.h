//
//  CommemorateCommentListVC.h
//  ListenToMe
//
//  Created by zhw on 15/7/23.
//  Copyright (c) 2015年 listentome. All rights reserved.
//

#import "YDBaseVC.h"

@interface CommemorateCommentListVC : YDBaseVC
/**
 *  当前要查看论列表的纪念册
 */
@property(nonatomic,strong) CommemorateBaseInfo *commemorateBaseInfo;
@end
