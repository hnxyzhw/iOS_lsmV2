//
//  MyBookVC.h
//  ListenToMe
//
//  Created by yadong on 2/5/15.
//  Copyright (c) 2015 listentome. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol MyBookVCDelegate <NSObject>
@optional
/**
 *  代理方法,将要编辑的纪念册信息传给代理
 *
 *  @param commemorateBaseInfo 传入的纪念册信息
 */
-(void)editedCommemorate:(CommemorateBaseInfo *)commemorateBaseInfo;
/**
 *  查看纪念册评论列表
 *
 *  @param commemorateInfo 传入的纪念册信息
 */
-(void)checkCommemorateCommentList:(CommemorateBaseInfo *)commemorateInfo;

@end


@interface MyBookVC : YDBaseVC
/**
 *  是否是从个人中心页面跳转进入的
 */
@property(nonatomic,assign)BOOL isPushFromPerCenter;
/**
 *  代理
 */
@property(nonatomic,assign) id<MyBookVCDelegate> delegate;
@end
