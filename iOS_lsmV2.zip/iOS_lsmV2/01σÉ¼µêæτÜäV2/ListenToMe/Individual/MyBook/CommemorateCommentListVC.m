//
//  CommemorateCommentListVC.m
//  ListenToMe
//
//  Created by zhw on 15/7/23.
//  Copyright (c) 2015年 listentome. All rights reserved.
//

#import "CommemorateCommentListVC.h"
#import "YDRoomMsgCell.h"
#import "NSDate+ZHW.h"
@interface CommemorateCommentListVC ()<UITableViewDataSource,UITableViewDelegate,UITextFieldDelegate>
/**
 *  加载数据的列表
 */
@property(nonatomic,strong) UITableView *tableView;
/**
 *  数据管理对象
 */
@property(nonatomic,strong) ListenToMeData *listenToMeData;
/**
 *  输入框背景视图
 */
@property(nonatomic,strong) UIImageView *opinionView;
/**
 *  输入框
 */
@property(nonatomic,strong) UITextField * tfOpinion;
/**
 *  键盘高度
 */
@property(nonatomic,assign) NSInteger keyboardhight;
/**
 *  评论的信息
 */
@property(nonatomic,strong) NSString *opinionContent;

@end

@implementation CommemorateCommentListVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self setNavigation];
    
    [self setUI];
}


#pragma mark 导航栏
-(void)setNavigation
{
    //    self.navigationItem.title = @"我的相册";
    [self setLeftBtnItem];
}

// 导航栏左边的Btn
-(void)setLeftBtnItem
{
    UIButton *leftBtn = [[UIButton alloc]init];
    UIImage *leftBtnImg = [UIImage imageNamed:@"whiteBack.png"];
    leftBtn.frame = CGRectMake(0, 0, leftBtnImg.size.width, leftBtnImg.size.height);
    [leftBtn setImage:leftBtnImg forState:UIControlStateNormal];
    [leftBtn addTarget:self action:@selector(clickLeftBarBtnItem) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *customLeftBtnItem = [[UIBarButtonItem alloc]initWithCustomView:leftBtn];
    self.navigationItem.leftBarButtonItem = customLeftBtnItem;
}

#pragma mark -点击事件

-(void)clickLeftBarBtnItem
{
    //    [self.navigationController popToRootViewControllerAnimated:YES];
    
    [self.navigationController popViewControllerAnimated:YES];
    YDLog(@"点击了导航栏左边的Btn");
}

#pragma mark - setUI
-(void)setUI{
    
    [self setTableViewUI];
    
    //参与讨论的弹窗视图
    [self setDiscussView];
    
    [self initData];
    
    
}

#pragma mark - initData
-(void)initData{
    
    self.listenToMeData = [ListenToMeData getInstance];
    
    //获取纪念册评论列表
    [[NetReqManager getInstance] sendGetCommemorateCommentListByLCommemorateId:self.commemorateBaseInfo.lCommid IOffset:0 INum:10];
    
    //监听获取纪念册评论列表的通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshTable) name:NOTIFY_GET_COMMEMORATE_COMMENTLIST_PAGE_RESP object:nil];
    
    //监听评论纪念册消息,回包的通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(addCommentToCommemorate) name:NOTIFY_ADD_COMMEMORATE_COMMENT_PAGE_RESP object:nil];
}




#pragma mark - refreshTable
-(void)refreshTable{
    
    
    [self.tableView reloadData];
}

-(void)addCommentToCommemorate{
    [self.listenToMeData.arrCommemorateCommentList insertObject:self.listenToMeData.addCommemorateCommentInfo atIndex:0];
//    NSMutableArray *tempArr = self.listenToMeData.arrCommemorateCommentList;
//    [tempArr insertObject:self.listenToMeData.addCommemorateCommentInfo atIndex:0];
//    self.listenToMeData.arrCommemorateCommentList = tempArr;
    
//    NSMutableArray *indexPaths = [[NSMutableArray alloc] init];
//    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:0 inSection:0];
//    [indexPaths addObject:indexPath];
//    [self.tableView beginUpdates];
//    [self.tableView insertRowsAtIndexPaths:indexPaths withRowAnimation:UITableViewRowAnimationTop];
//    [self.tableView endUpdates];
//    [self.tableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0] atScrollPosition:UITableViewScrollPositionBottom animated:YES];
    
    [self.tableView reloadData];
    
    //添加新评论后滑动到评论列表的顶部
    [self.tableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0] atScrollPosition:UITableViewScrollPositionTop animated:YES];
    
    
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:NOTIFY_GET_COMMEMORATE_COMMENTLIST_PAGE_RESP object:nil];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:NOTIFY_ADD_COMMEMORATE_COMMENT_PAGE_RESP object:nil];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardDidShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil];

}

#pragma mark - setTableView
-(void)setTableViewUI{
    self.tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, screenWidth, screenHeight - 49)];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.bounces = YES;
    self.tableView.scrollsToTop = YES;
    
    self.tableView.showsVerticalScrollIndicator = NO;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.tableView registerClass:[YDRoomMsgCell class] forCellReuseIdentifier:@"msgRecordCell"];
    [self.view addSubview:self.tableView];
}


#pragma mark - setDiscussview
-(void)setDiscussView{
    //参与讨论
    CGFloat opinionH = 55;
    CGFloat opinionW = screenWidth;
    CGFloat opinionX = 0;
    CGFloat opinionY = screenHeight - 55;
    self.opinionView = [[UIImageView alloc]initWithFrame:CGRectMake(opinionX, opinionY, opinionW, opinionH)];
    self.opinionView.backgroundColor = [UIColor whiteColor];
    //    UIImage *opinionBgImg = [UIImage imageNamed:@"opinionBgImg"];
    //    [self.opinionView setImage:opinionBgImg];
    self.opinionView.userInteractionEnabled = YES;
    [self.view addSubview:self.opinionView];
    //    self.opinionView.hidden = YES;
    
    CGFloat tfOpW = self.opinionView.width - 30;
    CGFloat tfOpH = 30;
    CGFloat tfOpX = 15;
    CGFloat tfOpY = (self.opinionView.height - tfOpH) * 0.5;
    self.tfOpinion = [[UITextField alloc]initWithFrame:CGRectMake(tfOpX, tfOpY, tfOpW, tfOpH)];
    [self.tfOpinion setFont:[UIFont systemFontOfSize:12.0]];
//    [self.tfOpinion setBackgroundColor:[UIColor rgbFromHexString:@"#AC56FF" alpaa:0.3]];
    [self.tfOpinion setBorderStyle:UITextBorderStyleNone];
    self.tfOpinion.layer.borderWidth = 1;
    self.tfOpinion.layer.borderColor = [[UIColor rgbFromHexString:@"#AC56FF" alpaa:1.0] CGColor];
    self.tfOpinion.placeholder = @"评论纪念册";
    self.tfOpinion.layer.masksToBounds = YES;
    self.tfOpinion.layer.cornerRadius = 5;
    self.tfOpinion.keyboardType = UIKeyboardAppearanceDefault;
    self.tfOpinion.clearButtonMode = UITextFieldViewModeWhileEditing;
    self.tfOpinion.delegate = self;
    [self.opinionView addSubview:self.tfOpinion];
    
    //监听键盘
    [self registerForKeyboardNotifications];
}


#pragma mark - 监测键盘
- (void)registerForKeyboardNotifications
{
    //使用NSNotificationCenter 鍵盤出現時
    [[NSNotificationCenter defaultCenter] addObserver:self
     
                                             selector:@selector(keyboardWasShown:)
     
                                                 name:UIKeyboardDidShowNotification object:nil];
    
    //使用NSNotificationCenter 鍵盤隐藏時
    [[NSNotificationCenter defaultCenter] addObserver:self
     
                                             selector:@selector(keyboardWillBeHidden:)
     
                                                 name:UIKeyboardWillHideNotification object:nil];
    
    
}

//实现当键盘出现的时候计算键盘的高度大小。用于输入框显示位置
- (void)keyboardWasShown:(NSNotification*)aNotification
{
    
    
    NSDictionary* info = [aNotification userInfo];
    //kbSize即為鍵盤尺寸 (有width, height)
    CGSize kbSize = [[info objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].size;//得到鍵盤的高度
    _keyboardhight = kbSize.height;
    //输入框位置动画加载
    [self begainMoveUpAnimation:_keyboardhight];
    
}

-(void)begainMoveUpAnimation:(NSInteger) keyboardH{
    
    CGFloat opinionH = 55;
    CGFloat opinionW = screenWidth;
    CGFloat opinionX = 0;
    CGFloat opinionY = screenHeight - 55 - keyboardH;
    self.opinionView.frame = CGRectMake(opinionX, opinionY, opinionW, opinionH);
}

//当键盘隐藏的时候
- (void)keyboardWillBeHidden:(NSNotification*)aNotification
{
    CGFloat opinionH = 55;
    CGFloat opinionW = screenWidth;
    CGFloat opinionX = 0;
    CGFloat opinionY = screenHeight - 55;
    self.view.frame = CGRectMake(0, 0, screenWidth, screenHeight);
    self.opinionView.frame = CGRectMake(opinionX, opinionY, opinionW, opinionH);
    
    
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    
    
    if(textField.text.length > 0){
        
        //评论音乐作品请求,使用UTF8编码,解决表情输入问题
        [[NetReqManager getInstance] sendAddCommentCommemorateWithUserId:[ListenToMeDBManager getUuid] LCommemorateId:self.commemorateBaseInfo.lCommid SContent:textField.text];//[textField.text stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]
    }
    
    //显示讨论的底图视图
    
    CGFloat opinionH = 55;
    CGFloat opinionW = screenWidth;
    CGFloat opinionX = 0;
    CGFloat opinionY = screenHeight - 55;
    self.view.frame = CGRectMake(0, 0, screenWidth, screenHeight);
    self.opinionView.frame = CGRectMake(opinionX, opinionY, opinionW, opinionH);
    
    //将输入框内的内容清空
    textField.text = nil;
    
    //关闭键盘
    [textField resignFirstResponder];
    
    return NO;
}



#pragma mark - UITableViewDataSource,UITableViewDelegate

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
       return self.listenToMeData.arrCommemorateCommentList.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 130;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    YDRoomMsgCell * cell = [tableView dequeueReusableCellWithIdentifier:@"msgRecordCell"];
    
    
    if (cell) {
        cell = [[YDRoomMsgCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"msgRecordCell"];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.contentView.backgroundColor =[UIColor rgbFromHexString:@"#F1F1F1" alpaa:1.0];
    if (self.listenToMeData.arrCommemorateCommentList != nil) {
        CommentInfo *commentInfo = self.listenToMeData.arrCommemorateCommentList[indexPath.row];//(self.listenToMeData.arrCommentListInfo.count - indexPath.row -1)
        UserBaseInfoNet *userBaseInfoNet = commentInfo.stUserBaseInfoNet;
        [cell.avatarImgView sd_setImageWithURL:[NSURL URLWithString:userBaseInfoNet.sCovver] placeholderImage:[UIImage imageNamed:@"icon.png"]];
        cell.lbFromPerson.text = userBaseInfoNet.sNick;
        //使用UTF8解码,解决表情问题
        cell.lbContents.text = [commentInfo.sCommentContent stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        cell.lbTime.text = [self getCreatedTime:commentInfo.lCommentTime];
    }

    
    return cell;
}


#pragma mark - 计算时间间隔
-(NSString *)getCreatedTime:(int64_t)lCreateTime{
    
    int64_t time = lCreateTime;
    NSDate *createdDate = [[NSDate alloc]initWithTimeIntervalSince1970:time/1000.0];
    
    NSDateFormatter *fmt = [[NSDateFormatter alloc] init];
    fmt.dateFormat = @"EEE MMM dd HH:mm:ss Z yyyy";
    
#warning 真机调试下, 必须加上这段
    fmt.locale = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US"];
    
    // 2..判断创建时间 和 现在时间 的差距
    if (createdDate.isToday) { // 今天
        if (createdDate.deltaWithNow.hour >= 1) {
            return [NSString stringWithFormat:@"%ld小时前", createdDate.deltaWithNow.hour];
        } else if (createdDate.deltaWithNow.minute >= 1) {
            return [NSString stringWithFormat:@"%ld分钟前", createdDate.deltaWithNow.minute];
        } else {
            return @"刚刚";
        }
    } else if (createdDate.isYesterday) { // 昨天
        fmt.dateFormat = @"昨天 HH:mm";
        return [fmt stringFromDate:createdDate];
    } else if (createdDate.isThisYear) { // 今年(至少是前天)
        fmt.dateFormat = @"MM-dd";
        return [fmt stringFromDate:createdDate];
    } else { // 非今年
        fmt.dateFormat = @"yyyy-MM-dd";
        return [fmt stringFromDate:createdDate];
    }
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
