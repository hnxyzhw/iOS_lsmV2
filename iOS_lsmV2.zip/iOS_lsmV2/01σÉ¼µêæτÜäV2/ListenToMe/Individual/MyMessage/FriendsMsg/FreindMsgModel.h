//
//  FreindMsgModel.h
//  ListenToMe
//
//  Created by yadong on 2/11/15.
//  Copyright (c) 2015 listentome. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 * 消息类型--谁发的
 */
typedef enum
{
    FreindMsgModelTypeMe = 0,
    FreindMsgModelTypeOther = 1
}FreindMsgModelType;

@interface FreindMsgModel : NSObject
/**
 *  消息的主键,序列号,数值类型
 */
@property(nonatomic,strong) NSNumber *messageNo;
/**
 *  消息的类型,系统消息,文本消息,送礼物消息
 */
@property(nonatomic,strong) NSNumber *messageType;
/**
 *  该条消息的发送者ID,字符串
 */
@property(nonatomic,strong) NSString *fromUserId;
/**
 *  该条消息的接收者ID,字符串
 */
@property(nonatomic,strong) NSString *toUserId;
/**
 *  这条消息的ID,标识符,字符串类型
 */
@property(nonatomic,strong) NSString *messageId;
/**
 * 消息内容
 */
@property(nonatomic,copy) NSString *content;
/**
 *  是否已经发送
 */
@property(nonatomic,strong) NSNumber *isSend;
/**
 *  是否已阅读
 */
@property(nonatomic,strong) NSNumber *isRead;
/**
 *  发送的时间
 */
@property(nonatomic,strong) NSDate *timeSend;
/**
 *  收到的时间
 */
@property(nonatomic,strong) NSDate *timeReceive;
/**
 *  送歌曲的ID
 */
@property(nonatomic,strong) NSString *sendMusicId;
/**
 *  送歌的歌名
 */
@property(nonatomic,strong) NSString *sendMusicName;
/**
 * 时间
 */
@property(nonatomic,copy) NSString *time;
/**
 * 消息类型,是自己发的还是别人发的
 */
@property(assign,nonatomic) FreindMsgModelType type;
/**
 *  是否隐藏时间
 */
@property (nonatomic, assign) BOOL hiddenTime;

NJInitH(FreindMsgModel)

@end
