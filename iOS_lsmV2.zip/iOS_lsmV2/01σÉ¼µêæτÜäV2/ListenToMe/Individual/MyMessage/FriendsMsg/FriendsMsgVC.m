//
//  FriendsMsgVC.m
//  ListenToMe
//
//  Created by zhw on 2/7/15.
//  Copyright (c) 2015 listentome. All rights reserved.
//

#import "FriendsMsgVC.h"
#import "FreindMsgModel.h"
#import "FreindMsgFrameModel.h"
#import "FriendMsgCell.h"
#import "GivingFlowerView.h"
#import "MyGiftCertificateVC.h"
#import "MyWorksVC.h"
#import "HWDBManager.h"
#import "HWPerHomePageVC.h"
#import "HWMusicPlayVC.h"


@interface FriendsMsgVC ()<UITableViewDataSource,UITableViewDelegate,UITextFieldDelegate,UIScrollViewDelegate,UIGestureRecognizerDelegate,STKAudioPlayerDelegate>
{
    STKAudioPlayer *audioPlayers;/**< 音乐播放器 */
}
/**
 *  展示消息的列表
 */
@property(strong,nonatomic) UITableView *mTableView;
/**
 * 顶部工具栏
 */
@property(strong,nonatomic) UIView *viewTopBar;
/**
 * 底部工具栏
 */
@property(strong,nonatomic) UIView *viewBottom;
/**
 *  送礼物
 */
@property(strong,nonatomic) UIButton *btnGift;
/**
 *  送歌
 */
@property(strong,nonatomic) UIButton *btnSong;
/**
 *  关进小黑屋
 */
@property(strong,nonatomic) UIButton *btnBlackRoom;
/**
 * 存放---消息数据
 */
@property(strong,nonatomic) NSMutableArray *arrayMessages;
/**
 * 存放所有的自动回复数据
 */
@property(strong,nonatomic) NSDictionary *dicAutoReplays;
/**
 * 输入框架
 */
@property(strong,nonatomic) UITextField *textFInput;
/**
 *  遮盖视图
 */
@property(strong,nonatomic) UIView *coverView;
/**
 *  送礼物弹窗背景
 */
@property(strong,nonatomic) UIButton *alertForGift;
/**
 *  送礼物(鲜花,优惠券)
 */
@property(strong,nonatomic) UIView *giftView;
/**
 *  送歌弹窗背景
 */
@property(strong,nonatomic) UIButton *sendSongView;
/**
 *  关进小黑屋弹窗背景
 */
@property(strong,nonatomic) UIButton *alertForBlackRoom;
/**
 *  送花
 */
@property(strong,nonatomic) GivingFlowerView *sendFlowerView;

/**
 *  默认送出鲜花数
 */
@property(assign,nonatomic) int sendFlowerNum;
/**
 *  用户拥有的鲜花数
 */
@property(assign,nonatomic) NSInteger haveFlowerNum;
/**
 *  数据
 */
@property(nonatomic,strong) ListenToMeData *listenToMeData;
/**
 *  当前发送的聊天model
 */
@property(nonatomic,strong) FreindMsgModel *sendFriendMsgModel;
/**
 *  最近一次聊天的model
 */
@property(nonatomic,strong) FreindMsgModel *recentlyFriendMsgModel;
/**
 *  歌曲播放时的显示的播放进度背景图
 */
@property(nonatomic,strong)UIImageView *playProgressBgImgView;
/**
 *  歌曲播放时的显示的播放进度前景图
 */
@property(nonatomic,strong)UIView *playProgressPerView;
/**
 *  歌曲时长
 */
@property(nonatomic,strong)UILabel *lbSongLength;
/**
 *  播放时间的定时器
 */
@property(nonatomic,strong)NSTimer *progressUpdateTimer;
@end

@implementation FriendsMsgVC

#pragma mark -生命周期
- (void)viewDidLoad {
    [super viewDidLoad];
    
    [ListenToMeData getInstance].privateChatUser = self.friendUserBaseInfoNet;
    
    //创建会话表
    [HWDBManager createChatTableInDB:[NSString stringWithFormat:@"%lld",[ListenToMeDBManager getUuid]] tableName:[NSString stringWithFormat:@"%lld",self.friendUserBaseInfoNet.uuid]];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillChange:) name:UIKeyboardWillChangeFrameNotification object:nil];
    
    [self setUpUI];
    
    [self initData];

    
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    if (_arrayMessages.count > 0) {
        [self.mTableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:[_arrayMessages count] - 1 inSection:0] atScrollPosition:UITableViewScrollPositionBottom animated:YES];
    }
    
    
}


#pragma mark - initData
-(void)initData{
    self.listenToMeData = [ListenToMeData getInstance];
    
    //歌曲自动播放
    audioPlayers = self.listenToMeData.audioPlayer;
    audioPlayers.delegate = self;
    
    _arrayMessages = [NSMutableArray array];
    
    NSString *dbName = [NSString stringWithFormat:@"%lld",[ListenToMeDBManager getUuid]];
    NSString *tableName = [NSString stringWithFormat:@"%lld",self.friendUserBaseInfoNet.uuid];
    NSString *userId = [NSString stringWithFormat:@"%lld",self.friendUserBaseInfoNet.uuid];

    if (self.listenToMeData.arrUserMsgRecord.count > 0) {
        
        for (PushMsg *sMsg in self.listenToMeData.arrUserMsgRecord) {
            if ((sMsg.stFromUser.uuid == self.friendUserBaseInfoNet.uuid) || (sMsg.stToUser.uuid == self.friendUserBaseInfoNet.uuid)) {
                //如果该条消息还未存入数据表中,那么就将改条消息存入数据表中
                NSLog(@"stfromuuid---%lld,sttouuid---%lld",sMsg.stFromUser.uuid,sMsg.stToUser.uuid);
                if (![HWDBManager haveSaveMessageInDB:dbName inTableName:tableName messageId:[NSString stringWithFormat:@"%lld",sMsg.lMsgId]]) {
                    
                    FreindMsgModel *messageModel = [[FreindMsgModel alloc] init];
                    messageModel.content = sMsg.sMsg;
                    
                    if (sMsg.stFromUser.uuid == [ListenToMeDBManager getUuid]) {
                        messageModel.type = FreindMsgModelTypeMe;
                    }else{
                        messageModel.type = FreindMsgModelTypeOther;
                    }
                    
                    messageModel.fromUserId = [NSString stringWithFormat:@"%lld",sMsg.stFromUser.uuid];
                    messageModel.toUserId = [NSString stringWithFormat:@"%lld",sMsg.stToUser.uuid];
                    messageModel.content = sMsg.sMsg;
                    messageModel.messageId =[NSString stringWithFormat:@"%lld",sMsg.lMsgId];
                    messageModel.timeSend =[[NSDate alloc]initWithTimeIntervalSince1970:sMsg.lMsgId / 1000.0];
                    messageModel.messageType = [NSNumber numberWithInt:sMsg.eMessageType];
                    
                    
                    [HWDBManager saveMessage:[NSString stringWithFormat:@"%lld",[ListenToMeDBManager getUuid]] tableName:[NSString stringWithFormat:@"%lld",self.friendUserBaseInfoNet.uuid] messageObject:messageModel];
                }
                
            }
       
        }
    }
    
    //取出消息记录
    NSArray *arrMessageRecord =  [HWDBManager fetchMessageListInDB:dbName inTableName:tableName WithUserId:userId byPage:0];
    
    for (NSInteger index = 0; index < arrMessageRecord.count; index ++) {
        FreindMsgModel *message = arrMessageRecord[index];
        FreindMsgFrameModel *msgFrameModel = [[FreindMsgFrameModel alloc]init];
        if (index + 1 < arrMessageRecord.count) {
            FreindMsgModel *recentyMessage = arrMessageRecord[index +1];
            recentyMessage.hiddenTime = [self showOrHiddednTime:recentyMessage.timeSend recentyDate:message.timeSend];
        }
        msgFrameModel.message = message;
        [_arrayMessages addObject:msgFrameModel];
//        NSLog(@"---messageID : %@",message.messageId);
    }

    
    //首先要获取当前私聊对象的小黑屋状态,然后在根据其状态执行是否将其关进(释放)小黑屋
    [[NetReqManager getInstance] sendGetBlackRoomState:self.listenToMeData.stUserBaseInfoNet.uuid LToUserId:self.friendUserBaseInfoNet.uuid];
    
    //发送消息成功后的回包
//    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshTable) name:NOTIFY_GET_SEND_Message_PAGE_RESP object:nil];
    
    //系统下发的聊天的消息记录
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshTable) name:NOTIFY_GET_PUSHMSG_PAGE_RESP object:nil];
    
    //消息本地存储成功后,发送一个通知刷新列表
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(newMsgCome:) name:kNewMsgNotifaction object:nil];
    
    //点击赠送的歌曲,获取当前要播放的歌曲信息
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getSendMosicWork) name:NOTIFY_GET_MUSICWOKRBSAEINFO_PAGE_RESP object:nil];
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:NOTIFY_GET_PUSHMSG_PAGE_RESP object:nil];
//    [[NSNotificationCenter defaultCenter] removeObserver:self name:NOTIFY_GET_SEND_Message_PAGE_RESP object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kNewMsgNotifaction object:nil];
    [[NSNotificationCenter defaultCenter]removeObserver:self name:NOTIFY_GET_MUSICWOKRBSAEINFO_PAGE_RESP object:nil];
    audioPlayers = nil;
}


#pragma mark - 刷新数据
-(void)refreshTable{

    for (PushMsg *sMsg in self.listenToMeData.arrUserMsgRecord) {
//        if (sMsg.eMessageType == MESSAGE_TYPEMessageTypePrivate) {
            //如果该条消息还未存入数据表中,那么就将改条消息存入数据表中
            if (sMsg.stFromUser.uuid == self.friendUserBaseInfoNet.uuid || sMsg.stToUser.uuid == self.friendUserBaseInfoNet.uuid) {
                if (![HWDBManager haveSaveMessageInDB:[NSString stringWithFormat:@"%lld",[ListenToMeDBManager getUuid]] inTableName:[NSString stringWithFormat:@"%lld",self.friendUserBaseInfoNet.uuid] messageId:[NSString stringWithFormat:@"%lld",sMsg.lMsgId]]) {
                
                    //送歌的消息
                    if (sMsg.eMessageType == MESSAGE_TYPEMessageTypeSongs) {
                        if (!self.sendFriendMsgModel) {
                            self.sendFriendMsgModel = [[FreindMsgModel alloc]init];
                        }
                        self.sendFriendMsgModel.fromUserId = [NSString stringWithFormat:@"%lld",sMsg.stFromUser.uuid];
                        self.sendFriendMsgModel.toUserId = [NSString stringWithFormat:@"%lld",sMsg.stToUser.uuid];
                        self.sendFriendMsgModel.content = sMsg.sMsg;
                        
                        if (sMsg.stFromUser.uuid == self.friendUserBaseInfoNet.uuid) {
                            self.sendFriendMsgModel.type = FreindMsgModelTypeOther;
                        }else{
                            self.sendFriendMsgModel.type = FreindMsgModelTypeMe;
                        }
                        
                        self.sendFriendMsgModel.isSend = [NSNumber numberWithBool:YES];
                        
                        if ([ListenToMeData getInstance].sendMusicWorkBaseInfo) {
                            self.sendFriendMsgModel.sendMusicId = [NSString stringWithFormat:@"%lld",[ListenToMeData getInstance].sendMusicWorkBaseInfo.lMusicWorkId];
                            
                            self.sendFriendMsgModel.sendMusicName = [ListenToMeData getInstance].sendMusicWorkBaseInfo.stSongInfo.sSongName;
                        }
                        

                    }
                    
                    self.sendFriendMsgModel.messageId = [NSString stringWithFormat:@"%lld",sMsg.lMsgId];
                    self.sendFriendMsgModel.messageType = [NSNumber numberWithInt:sMsg.eMessageType];

                    long long time = [[NSString stringWithFormat:@"%lld",sMsg.lMsgId] longLongValue];
                    NSDate *dateTime =[[NSDate alloc]initWithTimeIntervalSince1970:time/1000.0];
                    self.sendFriendMsgModel.timeSend = dateTime;
                   
                    [HWDBManager saveMessage:[NSString stringWithFormat:@"%lld",[ListenToMeDBManager getUuid]] tableName:[NSString stringWithFormat:@"%lld",self.friendUserBaseInfoNet.uuid] messageObject:self.sendFriendMsgModel];
                }
            }
            
//        }else if (sMsg.eMessageType == MESSAGE_TYPEMessageTypeSongs){
            
//        }
        
        
    }
    
    

    
//    [self.mTableView reloadData];
}

#pragma mark  接受新消息广播
-(void)newMsgCome:(NSNotification *)notifacation
{
    FreindMsgModel *msg = [notifacation.userInfo objectForKey:@"newMsg"];
    
    if([msg.fromUserId longLongValue] == self.friendUserBaseInfoNet.uuid || [msg.toUserId longLongValue] == self.friendUserBaseInfoNet.uuid){
        NSMutableArray *indexPaths = [[NSMutableArray alloc] init];
        
        FreindMsgFrameModel *msgFrameModel = [[FreindMsgFrameModel alloc]init];
        FreindMsgModel *recentlyFriendMsgModel = (FreindMsgModel *)[[_arrayMessages lastObject] message];
        msg.hiddenTime = [self showOrHiddednTime:msg.timeSend recentyDate:recentlyFriendMsgModel.timeSend];
        
        msgFrameModel.message = msg;
        [_arrayMessages addObject:msgFrameModel];
        NSIndexPath *indexPath = [NSIndexPath indexPathForRow:[_arrayMessages count]-1 inSection:0];
        [indexPaths addObject:indexPath];
        [self.mTableView beginUpdates];
        [self.mTableView insertRowsAtIndexPaths:indexPaths withRowAnimation:UITableViewRowAnimationBottom];
        [self.mTableView endUpdates];
        [self.mTableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:_arrayMessages.count-1 inSection:0] atScrollPosition:UITableViewScrollPositionBottom animated:YES];
    }
    
//    [self.mTableView reloadData];

}


#pragma mark -UI
-(void)setUpUI
{
    [self setLeftBtnItem];
    
    [self setRightBtnItem];
    
    //顶部送花送歌小黑屋
    [self setUpviewTopBar];
    
    //底部输入框
    [self setUpBottom];
    
    //会话列表
    [self setUpTableview];
    
    //真心话
    [self setUpTrueWords];
    
   
}

// 导航栏左边的Btn
-(void)setLeftBtnItem
{
    UIButton *leftBtn = [[UIButton alloc]init];
    UIImage *leftBtnImg = [UIImage imageNamed:@"whiteBack.png"];
    leftBtn.frame = CGRectMake(0, 0, leftBtnImg.size.width, leftBtnImg.size.height);
    [leftBtn setImage:leftBtnImg forState:UIControlStateNormal];
    [leftBtn addTarget:self action:@selector(clickLeftBarBtnItem) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *customLeftBtnItem = [[UIBarButtonItem alloc]initWithCustomView:leftBtn];
    self.navigationItem.leftBarButtonItem = customLeftBtnItem;
}

// 导航栏右边的Btn
-(void)setRightBtnItem
{
    UIButton *rightBtn = [[UIButton alloc]init];
    UIImage *imgMore = [UIImage imageNamed:@"more.png"];
    rightBtn.frame = CGRectMake(0, 0, imgMore.size.width, imgMore.size.height);
    [rightBtn setImage:imgMore forState:UIControlStateNormal];
    [rightBtn addTarget:self action:@selector(clickRightBarBtnItem) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *customRightBtnItem = [[UIBarButtonItem alloc]initWithCustomView:rightBtn];
    self.navigationItem.rightBarButtonItem = customRightBtnItem;
}

-(void)clickRightBarBtnItem
{
    YDLog(@"点击了导航栏的右边的按钮");
}

-(void)clickLeftBarBtnItem
{
    
    [self.navigationController popViewControllerAnimated:YES];
}


#pragma mark 顶部-工具栏
-(void)setUpviewTopBar
{
    _viewTopBar = [[UIView alloc]initWithFrame:CGRectMake(0,naviAndStatusH, screenWidth, 44 + 30)];
    [_viewTopBar setBackgroundColor:[UIColor whiteColor]];
    [self.view addSubview:_viewTopBar];
    
    //去他主页转转
    CGFloat lbGotoPerHomePage_X = 15;
    CGFloat lbGotoPerHomePage_Y = 0;
    CGFloat lbGotoPerHomePage_H = 30;
    CGFloat lbGotoPerHomePage_W = screenWidth - 30;
    UILabel *lbGotoPerHomePage = [[UILabel alloc]initWithFrame:CGRectMake(lbGotoPerHomePage_X, lbGotoPerHomePage_Y, lbGotoPerHomePage_W, lbGotoPerHomePage_H)];
    
    lbGotoPerHomePage.text = @"去TA主页转转";
    lbGotoPerHomePage.textColor = [UIColor rgbFromHexString:@"#AC56FF" alpaa:1.0];
    lbGotoPerHomePage.font = [UIFont systemFontOfSize:12.0];
    lbGotoPerHomePage.textAlignment = NSTextAlignmentLeft;
    [_viewTopBar addSubview:lbGotoPerHomePage];
    
    UIButton *btnGotoPerHomePage = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, _viewTopBar.width, lbGotoPerHomePage.height)];
    btnGotoPerHomePage.backgroundColor = [UIColor clearColor];
    [btnGotoPerHomePage addTarget:self action:@selector(gotoPerHomePage) forControlEvents:UIControlEventTouchUpInside];
    
    [_viewTopBar addSubview:btnGotoPerHomePage];
    
    UIImageView *lineView = [[UIImageView alloc]initWithFrame:CGRectMake(0,btnGotoPerHomePage.y + btnGotoPerHomePage.height, btnGotoPerHomePage.width, 1)];
    lineView.backgroundColor = [UIColor rgbFromHexString:@"#AC56FF" alpaa:0.5];
    [btnGotoPerHomePage addSubview:lineView];
    [_viewTopBar addSubview:lineView];
    
    
    CGFloat eachW = _viewTopBar.width / 3;
    CGFloat frontY = 6 ;
    CGFloat frontX = (eachW - 15) * 0.5;
    CGFloat btnsW = 15;
    CGFloat btnsH = 18;
    CGFloat btnsY = 15 * 0.5 + lbGotoPerHomePage.height;
    
    // 送礼物
    _btnGift = [[UIButton alloc]initWithFrame:CGRectMake(frontX, btnsY, btnsW, btnsH)];
    [_viewTopBar addSubview:_btnGift];
    
    [_btnGift setImage:[UIImage imageNamed:@"送花01.png"] forState:UIControlStateNormal];
    UILabel *lbGift = [[UILabel alloc]initWithFrame:CGRectMake(_btnGift.centerX - 25, _btnGift.y + btnsH, 50, 20)];
    lbGift.text = @"送花";
    [lbGift setTextColor:[UIColor rgbFromHexString:@"#FF0053" alpaa:1.0]];
    [lbGift setTextAlignment:NSTextAlignmentCenter];
    [lbGift setFont:[UIFont systemFontOfSize:8.0]];
    [_viewTopBar addSubview:lbGift];
    UIButton *giftTemp = [[UIButton alloc]initWithFrame:CGRectMake(lbGift.x, _btnGift.y, lbGift.width, _btnGift.height + lbGift.height)];
    giftTemp.backgroundColor = [UIColor clearColor];
    [_viewTopBar addSubview:giftTemp];
    [giftTemp addTarget:self action:@selector(pushGiftView) forControlEvents:UIControlEventTouchUpInside];
    
    
    // 送歌
    _btnSong = [[UIButton alloc]initWithFrame:CGRectMake(_btnGift.x + eachW, btnsY, btnsW, btnsH)];
    [_viewTopBar addSubview:_btnSong];
    
    [_btnSong setImage:[UIImage imageNamed:@"送歌.png"] forState:UIControlStateNormal];
    UILabel *lbSong = [[UILabel alloc]initWithFrame:CGRectMake(_btnSong.centerX - 25, _btnSong.y + btnsH, 50, 20)];
    lbSong.text = @"送歌";
    [lbSong setTextColor:[UIColor rgbFromHexString:@"#AC56FF" alpaa:1.0]];
    [lbSong setTextAlignment:NSTextAlignmentCenter];
    [lbSong setFont:[UIFont systemFontOfSize:8.0]];
    [_viewTopBar addSubview:lbSong];
    
    UIButton *songTemp = [[UIButton alloc]initWithFrame:CGRectMake(lbSong.x, _btnSong.y, lbSong.width, _btnSong.height + lbSong.height)];
    songTemp.backgroundColor = [UIColor clearColor];
    [_viewTopBar addSubview:songTemp];
    [songTemp addTarget:self action:@selector(pushSongView) forControlEvents:UIControlEventTouchUpInside];
    
    
    
    // 关进小黑屋
    _btnBlackRoom = [[UIButton alloc]initWithFrame:CGRectMake(_btnGift.x + eachW * 2, btnsY, btnsW, btnsH)];
    [_viewTopBar addSubview:_btnBlackRoom];
    
    [_btnBlackRoom setImage:[UIImage imageNamed:@"关进小黑屋.png"] forState:UIControlStateNormal];
    UILabel *lbBlackRoom = [[UILabel alloc]initWithFrame:CGRectMake(_btnBlackRoom.centerX - 25, _btnBlackRoom.y + btnsH, 50, 20)];
    lbBlackRoom.text = @"关进小黑屋";
    [lbBlackRoom setTextColor:[UIColor darkGrayColor]];
    [lbBlackRoom setTextAlignment:NSTextAlignmentCenter];
    [lbBlackRoom setFont:[UIFont systemFontOfSize:8.0]];
    [_viewTopBar addSubview:lbBlackRoom];
    
    UIButton *blackRoomTemp = [[UIButton alloc]initWithFrame:CGRectMake(lbBlackRoom.x, _btnBlackRoom.y, lbBlackRoom.width, _btnBlackRoom.height + lbBlackRoom.height)];
    blackRoomTemp.backgroundColor = [UIColor clearColor];
    [_viewTopBar addSubview:blackRoomTemp];
    [blackRoomTemp addTarget:self action:@selector(pushBlackRoomView) forControlEvents:UIControlEventTouchUpInside];
    
    
    for (int index = 0; index < 2; index ++) {
        UIImageView *lineImgView = [[UIImageView alloc]initWithFrame:CGRectMake( eachW * (index + 1)  - 1 , btnsY, 1, _viewTopBar.height - btnsY - frontY)];
        UIImage *lineImg =[UIImage imageNamed:@"分割线"];
        lineImgView.alpha = 0.2;
        [lineImgView setImage:lineImg];
        [_viewTopBar addSubview:lineImgView];
    }
    
    UIImageView *lineView2 = [[UIImageView alloc]initWithFrame:CGRectMake(0,_viewTopBar.height - 1, _viewTopBar.width, 1)];
    lineView2.backgroundColor = [UIColor rgbFromHexString:@"#AC56FF" alpaa:0.5 ];
    [btnGotoPerHomePage addSubview:lineView2];
    [_viewTopBar addSubview:lineView2];
    
    //初始化遮盖视图
    self.coverView = [[UIView alloc]initWithFrame:[UIScreen mainScreen].bounds];
    self.coverView.backgroundColor = [UIColor clearColor];
    self.coverView.alpha  = 1.0;
//
    self.alertForGift = [[UIButton alloc]initWithFrame:[UIScreen mainScreen].bounds];
    //    [self.alertForGift setBackgroundColor:[UIColor clearColor]];
    //    self.alertForGift.alpha = 1;
    self.alertForGift.backgroundColor = [UIColor blackColor];
    self.alertForGift.alpha = 0.3;
    [self.alertForGift addTarget:self action:@selector(backToView:) forControlEvents:UIControlEventTouchUpInside];
    [self.coverView addSubview:self.alertForGift];
    
}


#pragma mark - 去他人主页转转
-(void)gotoPerHomePage{
    
    HWPerHomePageVC *perHomePageVC = [[HWPerHomePageVC alloc]init];
    perHomePageVC.userBaseInfoNet = self.friendUserBaseInfoNet;
    [self.navigationController pushViewController:perHomePageVC animated:YES];
    
    //移除送歌时的播放界面
    if (self.sendSongView) {
        [self backToView:nil];
    }
}

#pragma mark 底部-工具栏
-(void)setUpBottom
{
    // 底部承载视图
    _viewBottom = [[UIView alloc]initWithFrame:CGRectMake(0, screenHeight - 60, screenWidth, 60)];
    _viewBottom.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:_viewBottom];
    
    UIImageView *lineImgView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, _viewBottom.width, 1)];
    lineImgView.backgroundColor = [UIColor lightGrayColor];
    [_viewBottom addSubview:lineImgView];
    
    // 输入框
    CGFloat inputW = _viewBottom.width - 30;
    CGFloat inputH = 35;
    CGFloat inputX = 15;
    CGFloat inputY =( _viewBottom.height - inputH ) * 0.5;
    _textFInput = [[UITextField alloc]initWithFrame:CGRectMake(inputX, inputY, inputW, inputH)];
    UIImage *inputBgImg = [UIImage imageNamed:@"inputBgImg.png"];
    [_textFInput setBackground:inputBgImg];
    [_textFInput setTextColor:[UIColor rgbFromHexString:@"#000000" alpaa:1.0]];
    _textFInput.clearButtonMode = UITextFieldViewModeWhileEditing;
//    _textFInput.backgroundColor = [UIColor colorWithRed:0.8 green:0.8 blue:0.8 alpha:1.0];
    [_viewBottom addSubview:_textFInput];
    
    _textFInput.delegate = self;
}

#pragma mark - 布局真心话
-(void)setUpTrueWords{
    CGFloat btnTrueWords_X = screenWidth - 15 - 44;
    CGFloat btnTrueWords_Y = _viewBottom.y - 20 - 44;
    CGFloat btnTrueWords_W = 44;
    CGFloat btnTrueWords_H = 44;
    UIButton *btnTrueWords =[[UIButton alloc]initWithFrame:CGRectMake(btnTrueWords_X, btnTrueWords_Y, btnTrueWords_W, btnTrueWords_H)];
    UIImage *imgTrueWords = [UIImage imageNamed:@"真心话.png"];
    [btnTrueWords setImage:imgTrueWords forState:UIControlStateNormal];
    [btnTrueWords setImage:imgTrueWords forState:UIControlStateHighlighted];
    btnTrueWords.backgroundColor = [UIColor clearColor];
    [btnTrueWords addTarget:self action:@selector(sendTrueWordsForAdventure) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btnTrueWords];
    
}

#pragma mark - 发送真心话大冒险
-(void)sendTrueWordsForAdventure{
    YDLog(@"发送真心话大冒险");
}

#pragma mark tableview
-(void)setUpTableview
{
    CGFloat tableviewH = screenHeight - naviAndStatusH - _viewTopBar.height - _viewBottom.height;  // tableview的高度
    _mTableView = [[UITableView alloc]initWithFrame:CGRectMake(0, _viewTopBar.y + _viewTopBar.height, screenWidth,tableviewH) style:UITableViewStylePlain];
    _mTableView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:_mTableView];
    
    _mTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    _mTableView.showsVerticalScrollIndicator = NO;
    _mTableView.allowsSelection = NO;
    _mTableView.delegate = self;
    _mTableView.dataSource = self;
    [self addAGesutreRecognizerForYourView];
}


#pragma mark -delegate & datasource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _arrayMessages.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    FreindMsgFrameModel *modelFrame = self.arrayMessages[indexPath.row];
    return modelFrame.cellHeight;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    
//    FriendMsgCell *cell = [FriendMsgCell cellWithTableView:tableView];
    NSString *identifier = [NSString stringWithFormat:@"msgCell%ld",indexPath.row];
    FriendMsgCell *cell = [tableView dequeueReusableHeaderFooterViewWithIdentifier:identifier];
    if (!cell) {
        cell = [[FriendMsgCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    
    cell.thePerosnCover = self.friendUserBaseInfoNet.sCovver;
    cell.messageFrame = _arrayMessages[indexPath.row];
    

    FreindMsgModel *friendMsgModel = ((FreindMsgFrameModel *)_arrayMessages[indexPath.row]).message;
    
    if ([friendMsgModel.messageType intValue] == MESSAGE_TYPEMessageTypeSongs) {
        UIButton *btn = [[UIButton alloc]initWithFrame:cell.btnContent.frame];
        [cell.contentView addSubview:btn];
        [btn addTarget:self action:@selector(playSendingMusic:) forControlEvents:UIControlEventTouchUpInside];
        
    }
    
    return cell;
    
    
}


#pragma mark - 播放赠送的歌曲
-(void)playSendingMusic:(UIButton *)btnContent{
    YDLog(@"播放歌曲---");
    UITableViewCell *cell = (UITableViewCell *)[[btnContent superview] superview];
    //获取cell的indexPath的值
    NSIndexPath *indexPath = [self.mTableView indexPathForCell:cell];
    FreindMsgModel *friendMsgModel = ((FreindMsgFrameModel *)_arrayMessages[indexPath.row]).message;
    
    if ([friendMsgModel.messageType integerValue] == MESSAGE_TYPEMessageTypeSongs) {
        NSArray *arrContent = [friendMsgModel.content componentsSeparatedByString:@"-"];
        
        //当点击送歌的消息时,根据传入的消息内容 音乐作品Id-歌曲名,截取音乐作品的id,通过音乐作品的ID发送一条请求获取音乐作品的相关信息
        [[NetReqManager getInstance] sendGetMusicWorkByID:[ListenToMeDBManager getUuid] LWorkID:[arrContent.firstObject longLongValue]];
    }
    
}

#pragma mark - 弹出当前送歌的歌曲试听播放界面
-(void)getSendMosicWork{
    
    //当获取音乐作品信息成功时,发送一条通知过来,执行以下代码
    //初始化送歌播放界面
    [self setSendSongView];
    
    //弹出阴影遮盖视图
    [[[UIApplication sharedApplication]keyWindow] addSubview:self.coverView];
    
}


#pragma mark - 弹出送歌,歌曲礼盒试听的界面
-(void)setSendSongView{
    
    MusicWorkBaseInfo *musicWorkBaseInfo = self.listenToMeData.musicWorkBaseInfo;
    
    CGFloat sendSongView_X = 15;
    CGFloat sendSongView_Y = 190;
    CGFloat sendSongView_W = self.coverView.width - 30;
    CGFloat sendSongView_H = 290;
    
    self.sendSongView = [[UIButton alloc]initWithFrame:CGRectMake(sendSongView_X, sendSongView_Y, sendSongView_W, sendSongView_H)];
//    self.sendSongView.backgroundColor = [UIColor redColor];
    [self.sendSongView addTarget:self action:@selector(currentMusicPlay) forControlEvents:UIControlEventTouchUpInside];
    [self.coverView addSubview:self.sendSongView];
    
    //歌曲展开背景1
    CGFloat sendSongBgView1_X = 0;
    CGFloat sendSongBgView1_Y = 0;
    CGFloat sendSongBgView1_W = sendSongView_W;
    CGFloat sendSongBgView1_H = 44;
    
    
    UIImageView *sendSongBgView1 = [[UIImageView alloc]initWithFrame:CGRectMake(sendSongBgView1_X, sendSongBgView1_Y, sendSongBgView1_W, sendSongBgView1_H)];
    [sendSongBgView1 setImage:[UIImage imageNamed:@"歌曲展开背景1.png"]];
//    sendSongBgView1.userInteractionEnabled = YES;
    
    [self.sendSongView addSubview:sendSongBgView1];
    
    //歌曲展开图
    CGFloat sendSongTitleView_X = 15;
    CGFloat sendSongTitleView_Y = sendSongBgView1.height  - 35;
    CGFloat sendSongTitleView_W = sendSongBgView1.width - 30;
    CGFloat sendSongTitleView_H = 35;
    
    UIImageView *sendSongTitleView =[[UIImageView alloc]initWithFrame:CGRectMake(sendSongTitleView_X, sendSongTitleView_Y, sendSongTitleView_W, sendSongTitleView_H)];
    [sendSongTitleView setImage:[UIImage imageNamed:@"歌曲展开图.png"]];
    [sendSongBgView1 addSubview:sendSongTitleView];
    
    //关闭
    CGFloat btnCloseSendSong_X = sendSongBgView1.width - 30;
    CGFloat btnCloseSendSong_Y = 15;
    CGFloat btnCloseSendSong_W = 15;
    CGFloat btnCloseSendSong_H = 15;
    
    UIButton *btnCloseSendSong = [[UIButton alloc]initWithFrame:CGRectMake(btnCloseSendSong_X, btnCloseSendSong_Y, btnCloseSendSong_W, btnCloseSendSong_H)];
    [btnCloseSendSong setImage:[UIImage imageNamed:@"关闭.png"] forState:UIControlStateNormal];
    [btnCloseSendSong addTarget:self action:@selector(backToView:) forControlEvents:UIControlEventTouchUpInside];
    
    [self.sendSongView addSubview:btnCloseSendSong];
    
    
    //展开歌曲背景2
    CGFloat sendSongBgView2_X = 0;
    CGFloat sendSongBgView2_Y = sendSongBgView1.y + sendSongBgView1.height;
    CGFloat sendSongBgView2_W = sendSongView_W;
    CGFloat sendSongBgView2_H = 290 - sendSongBgView1.height;//self.sendSongView.height - sendSongBgView1.height;
    
    UIImageView *sendSongBgView2 = [[UIImageView alloc]initWithFrame:CGRectMake(sendSongBgView2_X, sendSongBgView2_Y, sendSongBgView2_W, sendSongBgView2_H)];
    [sendSongBgView2 setImage:[UIImage imageNamed:@"歌曲展开背景2.png"]];
//    sendSongBgView2.userInteractionEnabled  = YES;
    
    [self.sendSongView addSubview:sendSongBgView2];
    
    
    //歌曲名
    CGFloat lbSongName_X = 0;
    CGFloat lbSongName_Y =  sendSongBgView2.y + 29;
    CGFloat lbSongName_W = sendSongBgView2.width;
    CGFloat lbSongName_H = 15;
    
    UILabel *lbSongName = [[UILabel alloc]initWithFrame:CGRectMake(lbSongName_X, lbSongName_Y, lbSongName_W, lbSongName_H)];
    lbSongName.text = musicWorkBaseInfo.stSongInfo.sSongName;
    lbSongName.textAlignment = NSTextAlignmentCenter;
    lbSongName.font = [UIFont systemFontOfSize:12.0];
    lbSongName.textColor = [UIColor rgbFromHexString:@"#FF0053" alpaa:1.0];
    [self.sendSongView addSubview:lbSongName];
    
    //歌曲作者的头像
    CGFloat avatarsImgView_W = 64;
    CGFloat avatarsImgView_H = 64;
    CGFloat avatarsImgView_X = (sendSongBgView2.width - avatarsImgView_W) * 0.5;
    CGFloat avatarsImgView_Y = lbSongName.y + lbSongName.height + 29;
    
    UIImageView *avatarsImgView = [[UIImageView alloc]initWithFrame:CGRectMake(avatarsImgView_X, avatarsImgView_Y, avatarsImgView_W, avatarsImgView_H)];
    [avatarsImgView sd_setImageWithURL:[NSURL URLWithString:musicWorkBaseInfo.stUserBaseInfoNet.sCovver] placeholderImage:[UIImage imageNamed:@"icon.png"]];
    avatarsImgView.layer.masksToBounds = YES;
    avatarsImgView.layer.cornerRadius = avatarsImgView_W * 0.5;
    [self.sendSongView addSubview:avatarsImgView];
    
    UIButton *btnAvatars = [[UIButton alloc]initWithFrame:CGRectMake(avatarsImgView_X, avatarsImgView_Y, avatarsImgView_W, avatarsImgView_H)];
    btnAvatars.backgroundColor = [UIColor clearColor];
   
    
    //点击头像跳转到他人主页
    [btnAvatars addTarget:self action:@selector(gotoPerHomePage) forControlEvents:UIControlEventTouchUpInside];
    [self.sendSongView addSubview:btnAvatars];
    
    //播放按键
    CGFloat btnPlaySong_X = (sendSongBgView2.width - 23) * 0.5;
    CGFloat btnPlaySong_Y = btnAvatars.y + btnAvatars.height + 20;
    CGFloat btnPlaySong_W = 23;
    CGFloat btnPlaySong_H = 23;
    
    UIButton *btnPlaySong = [[UIButton alloc]initWithFrame:CGRectMake(btnPlaySong_X, btnPlaySong_Y, btnPlaySong_W, btnPlaySong_H)];
    [btnPlaySong setImage:[UIImage imageNamed:@"歌曲展开播放.png"] forState:UIControlStateNormal];
    [btnPlaySong setImage:[UIImage imageNamed:@"歌曲展开暂停.png"] forState:UIControlStateSelected];
    
    //默认,自动播放
    btnPlaySong.selected = YES;
    
    //改变歌曲播放状态,暂停,继续
    [btnPlaySong addTarget:self action:@selector(changeSongPlayState) forControlEvents:UIControlEventTouchUpInside];
    [self.sendSongView addSubview:btnPlaySong];
    
    //分割线
    
    UIImageView *lineImgView = [[UIImageView alloc]initWithFrame:CGRectMake(0, btnPlaySong.y + btnPlaySong.height + 19, sendSongBgView2.width, 1)];
    lineImgView.backgroundColor = [UIColor rgbFromHexString:@"#9B9B9B" alpaa:0.8];
    [self.sendSongView addSubview:lineImgView];
    
    
    
    //歌曲进度图
    //进度背景图
    CGFloat playProgressBgView_X = (sendSongBgView2.width - 171) * 0.5;
    CGFloat playProgressBgView_Y = lineImgView.y + lineImgView.height + 5;
    CGFloat playProgressBgView_W = 171;
    CGFloat playProgressBgView_H = 15;
    
    self.playProgressBgImgView = [[UIImageView alloc]initWithFrame:CGRectMake(playProgressBgView_X, playProgressBgView_Y, playProgressBgView_W, playProgressBgView_H)];
    self.playProgressBgImgView.clipsToBounds = YES;
    self.playProgressBgImgView.backgroundColor = [UIColor clearColor];
    self.playProgressBgImgView.image = [UIImage imageNamed:@"灰色01.png"];
    
    [self.sendSongView addSubview:self.playProgressBgImgView];
    
    //进度前景图
    self.playProgressPerView = [[UIView alloc]initWithFrame:CGRectMake(0, 0,  0, self.playProgressBgImgView.height)];
    self.playProgressPerView.backgroundColor = [UIColor clearColor];
    self.playProgressPerView.clipsToBounds = YES;
    
    UIImageView *progressImgView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, self.playProgressBgImgView.width, self.playProgressBgImgView.height)];
    progressImgView.backgroundColor = [UIColor clearColor];
    progressImgView.image =[UIImage imageNamed:@"红色03.png"];
    progressImgView.clipsToBounds = YES;
    [self.playProgressPerView addSubview:progressImgView];
    
    //将播放进度的前景图放置在背景图之上
    [self.playProgressBgImgView addSubview:self.playProgressPerView];
    
    
    //歌播放剩余时长
    //歌曲时长
    CGFloat lbSongLength_W = sendSongBgView2.width;
    CGFloat lbSongLength_H = 20;
    CGFloat lbSongLength_X = 0;
    CGFloat lbSongLength_Y = self.playProgressBgImgView.y + self.playProgressBgImgView.height + 5;
    
    self.lbSongLength = [[UILabel alloc]initWithFrame:CGRectMake(lbSongLength_X,lbSongLength_Y ,lbSongLength_W ,lbSongLength_H)];
    [self.lbSongLength setText:@"04:20"];
    [self.lbSongLength setFont:[UIFont systemFontOfSize:10.0]];
    [self.lbSongLength setTextColor:[UIColor rgbFromHexString:@"#9B9B9B" alpaa:1.0]];
    [self.lbSongLength setTextAlignment:NSTextAlignmentCenter];
    
    [self.sendSongView addSubview:self.lbSongLength];
    
    
    
    //判断当前音乐的播放状态
    if (musicWorkBaseInfo) {
        
        if (!self.progressUpdateTimer) {
            self.progressUpdateTimer = [NSTimer scheduledTimerWithTimeInterval:1.0
                                                                        target:self
                                                                      selector:@selector(updatePlaybackProgress)
                                                                      userInfo:nil
                                                                       repeats:YES];
            
            //解决定时器冲突的问题
            NSRunLoop *mainLoop = [NSRunLoop currentRunLoop];
            [mainLoop addTimer:self.progressUpdateTimer forMode:NSRunLoopCommonModes];
        }
        
        NSURL *url = [NSURL URLWithString:musicWorkBaseInfo.stSongInfo.sSongUrl];
        [audioPlayers playURL:url];
        
    }
    
}


#pragma mark - 更新播放进度
-(void)updatePlaybackProgress{
    //添加一个控制播放的进度的slider
    
    if (audioPlayers.state == STKAudioPlayerStatePlaying) {
        
        if (audioPlayers.duration > 0) {
            long totalTime = (long)(audioPlayers.duration - audioPlayers.progress);
            long minute = totalTime / 60;
            long second = totalTime % 60;
            if(second <10){
                self.lbSongLength.text = [NSString stringWithFormat:@"-%ld:0%ld",minute,second];
            }else{
                self.lbSongLength.text = [NSString stringWithFormat:@"-%ld:%ld",minute,second];
            }
            
            //设置进度条显示的
            self.playProgressPerView.frame = CGRectMake(0, 0, (audioPlayers.progress / audioPlayers.duration) * self.playProgressBgImgView.width, self.playProgressBgImgView.height);
        }
        
    }else{
        
    }
}

#pragma mark - 点击试听的歌曲礼盒其他区域跳转到歌曲播放详情界面
-(void)currentMusicPlay{
    if (self.sendSongView) {
        [self backToView:nil];
    }
   
    MusicWorkBaseInfo *musicWorkBaseInfo = self.listenToMeData.musicWorkBaseInfo;
    self.listenToMeData.currentMusicAudition = musicWorkBaseInfo;
    HWMusicPlayVC *musicPlayVC = [HWMusicPlayVC shareHWMusicPlayVC];
    musicPlayVC.navigationItem.title = musicWorkBaseInfo.stSongInfo.sSongName;
    musicPlayVC.musicWorkBaseInfo = musicWorkBaseInfo;
    musicPlayVC.lWorkID = musicWorkBaseInfo.lMusicWorkId;
    [musicPlayVC playMusicwork:musicWorkBaseInfo];
    [self.navigationController pushViewController:musicPlayVC animated:YES];

}

#pragma mark - 改变歌曲播放状态,暂停播放,继续播放
-(void)changeSongPlayState{

    YDLog(@"改变歌曲播放状态");
}

#pragma mark 滚动的时候，注销输入
-(void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    [self.view endEditing:YES];
}

#pragma mark  -点击事件
#pragma mark 点击return键
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{

    if(textField.text.length > 0){
        
        if (self.sendFriendMsgModel) {
            self.sendFriendMsgModel = nil;
        }
        
        self.sendFriendMsgModel = [[FreindMsgModel alloc] init];
        self.sendFriendMsgModel.fromUserId = [NSString stringWithFormat:@"%lld",[ListenToMeDBManager getUuid]];
        self.sendFriendMsgModel.toUserId = [NSString stringWithFormat:@"%lld",self.friendUserBaseInfoNet.uuid];
        self.sendFriendMsgModel.content = textField.text;
//        NSDate *date = [NSDate date];
//        NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
//        formatter.dateFormat = @"aa hh:mm";
//        NSTimeZone *zone = [NSTimeZone systemTimeZone];
//        NSInteger interval = [zone secondsFromGMTForDate:date];
//        self.sendFriendMsgModel.timeSend = [date dateByAddingTimeInterval:interval];
        
        self.sendFriendMsgModel.type = FreindMsgModelTypeMe;
        
        self.sendFriendMsgModel.isSend = [NSNumber numberWithBool:YES];
        
        self.recentlyFriendMsgModel = (FreindMsgModel *)[[_arrayMessages lastObject] message];
        
        
        
        self.sendFriendMsgModel.hiddenTime = [[NSString stringWithFormat:@"%@",self.sendFriendMsgModel.messageId] isEqualToString:[NSString stringWithFormat:@"%@",self.recentlyFriendMsgModel.messageId]];
        
        //发送一条聊天数据请求
        [[NetReqManager getInstance] sendMsg:[ListenToMeDBManager getUuid] LTalkWith:self.friendUserBaseInfoNet.uuid SMsg:textField.text LMsgId:[[NSDate date] timeIntervalSince1970] * 1000.0 EMessageType:MESSAGE_TYPEMessageTypePrivate];
        
        
        textField.text = nil;
        
        
    
    }
    
    [self.mTableView reloadData];
    
    if (_arrayMessages.count > 0) {
        [self.mTableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:[_arrayMessages count] - 1 inSection:0] atScrollPosition:UITableViewScrollPositionBottom animated:YES];
    }
    
    
//    [self.view endEditing:YES];
    return YES;
}


#pragma mark - 其他
#pragma mark 键盘变化
- (void)keyboardWillChange:(NSNotification  *)notification
{
       // 1.获取键盘的Y值
    NSDictionary *dict  = notification.userInfo;
    CGRect keyboardFrame = [dict[UIKeyboardFrameEndUserInfoKey] CGRectValue];
    CGFloat keyboardY = keyboardFrame.origin.y;
    // 获取动画执行时间
    CGFloat duration = [dict[UIKeyboardAnimationDurationUserInfoKey]doubleValue];
    // 2.计算需要移动的距离
    CGFloat translationY = keyboardY - self.view.frame.size.height;

    [UIView animateWithDuration:duration delay:0.0 options:7 << 16 animations:^{
        // 需要执行动画的代码
        self.view.transform = CGAffineTransformMakeTranslation(0, translationY);
    } completion:^(BOOL finished) {
        // 动画执行完毕执行的代码
    }];
    
}

//解决办法,添加一个点击手势
- (void)addAGesutreRecognizerForYourView

{
    
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapGesturedDetected:)]; // 手势类型随你喜欢。
    
    tapGesture.delegate = self;
    
    [self.mTableView addGestureRecognizer:tapGesture];
    
}

- (void)tapGesturedDetected:(UITapGestureRecognizer *)recognizer

{
    [self.textFInput resignFirstResponder];
    [self.view endEditing:YES];
    // do something
    
}

#pragma mark - 弹出送礼物的视图
-(void)pushGiftView{
    YDLog(@"送礼物");
    [self sendFlower];
  
    //弹出遮盖视图
    [[[UIApplication sharedApplication]keyWindow] addSubview:self.coverView];
   /*
    //布局子视图
    CGFloat giftViewX = 0;
    CGFloat giftViewY = self.alertForGift.height - 164;
    CGFloat giftViewW = screenWidth;
    CGFloat giftViewH = 164;
    self.giftView = [[UIView alloc]initWithFrame:CGRectMake(giftViewX , giftViewY, giftViewW, giftViewH)];
    self.giftView.backgroundColor = [UIColor whiteColor];
    [self.coverView addSubview:self.giftView];
    
    //鲜花
    CGFloat frontX = 15;
    CGFloat cellHeight = 82;
    CGFloat btnW = self.giftView.width - frontX * 2;
    
    UIImage *flowerImg = [UIImage imageNamed:@"送花01.png"];
    CGFloat flowerW = flowerImg.size.width * 0.5;
    CGFloat flowerH = flowerImg.size.height * 0.5;
    CGFloat flowerY = (cellHeight - flowerH) * 0.5;
    UIImageView *flowerImgView = [[UIImageView alloc]initWithFrame:CGRectMake(frontX, flowerY, flowerW, flowerH)];
    [flowerImgView setImage:flowerImg];
    [self.giftView addSubview:flowerImgView];
    
    CGFloat lbFX = flowerImgView.x + flowerImgView.width + 55;
    CGFloat lbFY = 0;
    CGFloat lbFW = 100;
    UILabel *lbFlower = [[UILabel alloc]initWithFrame:CGRectMake(lbFX, lbFY, lbFW, cellHeight)];
    lbFlower.text = @"鲜花";
    [lbFlower setTextColor:[UIColor rgbFromHexString:@"#FF0053" alpaa:1.0]];
    [lbFlower setFont: [UIFont systemFontOfSize:15]];
    [self.giftView addSubview:lbFlower];
    
    UIImage *openImg = [UIImage imageNamed:@"送花展开.png"];
    UIImageView *openView = [[UIImageView alloc]initWithFrame:CGRectMake(self.giftView.width - frontX - openImg.size.width * 0.5, (cellHeight - openImg.size.height * 0.5) * 0.5, openImg.size.width * 0.5, openImg.size.height * 0.5)];
    [openView setImage:openImg];
    [self.giftView addSubview:openView];
    
    UIButton *btnFlower = [[UIButton alloc]initWithFrame:CGRectMake(frontX, 0, btnW, cellHeight)];
    btnFlower.backgroundColor = [UIColor clearColor];
    [btnFlower addTarget:self action:@selector(sendFlower) forControlEvents:UIControlEventTouchUpInside];
    [self.giftView addSubview:btnFlower];
    
    UIImageView *line = [[UIImageView alloc]initWithFrame:CGRectMake(frontX, cellHeight - 1, self.giftView.width - frontX * 2, 1)];
    [self.giftView addSubview:line];
    [line setBackgroundColor:[UIColor rgbFromHexString:@"#AC56FF" alpaa:0.12]];
    
    
    //优惠券
    
    
    UIImage *couponsImg = [UIImage imageNamed:@"优惠券.png"];
    CGFloat couponsW = couponsImg.size.width * 0.5;
    CGFloat couponsH = couponsImg.size.height * 0.5;
    CGFloat couponsY = (cellHeight - couponsH) * 0.5 + cellHeight;
    UIImageView *couponsImgView = [[UIImageView alloc]initWithFrame:CGRectMake(frontX, couponsY, couponsW, couponsH)];
    [couponsImgView setImage:couponsImg];
    [self.giftView addSubview:couponsImgView];
    
    CGFloat lbCouponsX = flowerImgView.x + flowerImgView.width + 55;
    CGFloat lbCouponsY = cellHeight;
    CGFloat lbCouponsW = 100;
    UILabel *lbCoupons = [[UILabel alloc]initWithFrame:CGRectMake(lbCouponsX, lbCouponsY, lbCouponsW, cellHeight)];
    lbCoupons.text = @"优惠券";
    [lbCoupons setTextColor:[UIColor rgbFromHexString:@"#FF0053" alpaa:1.0]];
    [lbCoupons setFont: [UIFont systemFontOfSize:15]];
    [self.giftView addSubview:lbCoupons];
    
    UIImage *openCouponsImg = [UIImage imageNamed:@"优惠券展开.png"];
    UIImageView *openCouponsView = [[UIImageView alloc]initWithFrame:CGRectMake(self.giftView.width - frontX - openCouponsImg.size.width * 0.5, (cellHeight - openCouponsImg.size.height * 0.5) * 0.5 + cellHeight, openCouponsImg.size.width * 0.5, openCouponsImg.size.height * 0.5)];
    [openCouponsView setImage:openCouponsImg];
    [self.giftView addSubview:openCouponsView];
    
    UIButton *btnCoupons = [[UIButton alloc]initWithFrame:CGRectMake(frontX, cellHeight, btnW, cellHeight)];
    btnCoupons.backgroundColor = [UIColor clearColor];
    [btnCoupons addTarget:self action:@selector(sendCoupons) forControlEvents:UIControlEventTouchUpInside];
    [self.giftView addSubview:btnCoupons];
  
    */
}
-(void)pushSongView{
    YDLog(@"送歌");
    if ([ListenToMeDBManager getUuid] > 0) {
        MyWorksVC *myWorksVC = [[MyWorksVC alloc]init];
        myWorksVC.navigationItem.title = @"送歌";
        myWorksVC.isPushFromPerCenter = NO;
        myWorksVC.uuid = self.listenToMeData.stUserBaseInfoNet.uuid;
        myWorksVC.iOffset = 0;
        myWorksVC.iNum = 10;
        myWorksVC.lWatchUserId = 0;
        [self.navigationController pushViewController:myWorksVC animated:YES];
    }else{
    
        YDLog(@"还没有登录,请先登录,再送歌");
    }
   
    
}
-(void)pushBlackRoomView{
    
    if (self.listenToMeData.bMute == 0) {
        [[NetReqManager getInstance] sendSetBlackRoomState:self.listenToMeData.stUserBaseInfoNet.uuid LToUserid:self.friendUserBaseInfoNet.uuid BMute:1];
        YDLog(@"关进小黑屋");
    }else{
        [[NetReqManager getInstance] sendSetBlackRoomState:self.listenToMeData.stUserBaseInfoNet.uuid LToUserid:self.friendUserBaseInfoNet.uuid BMute:0];
        YDLog(@"放出小黑屋");
    }
}

#pragma mark - 弹出送花 送礼券界面
#pragma mark - 送花
-(void)sendFlower{
    YDLog(@"送多少花");
//    [self.giftView removeFromSuperview];

    CGFloat sendFW = self.coverView.width - 30;
    CGFloat sendFH = 285;
    CGFloat sendFX = 15;
    CGFloat sendFY = 190;
    
    //设置临时数据
    self.sendFlowerNum = 0;
    self.haveFlowerNum = self.listenToMeData.stUserBaseInfoNet.iFlowerNum;
    
    self.sendFlowerView = [[GivingFlowerView alloc]init];
    self.sendFlowerView.frame = CGRectMake(sendFX, sendFY, sendFW, sendFH);
    self.sendFlowerView.receiveIcon = self.friendUserBaseInfoNet.sCovver;
    self.sendFlowerView.sendFlowerNum = self.sendFlowerNum;
//    [self.sendFlowerView addFlower:self.sendFlowerNum];
    [self.sendFlowerView.btnGiveFlower addTarget:self action:@selector(sendFlowerHandle) forControlEvents:UIControlEventTouchUpInside];
    [self.sendFlowerView.btnSendFNum setTitle:[NSString stringWithFormat:@"%d",self.sendFlowerNum] forState:UIControlStateNormal];

    //设置颜色
    [self.sendFlowerView setLbTextForDifferentColor:self.sendFlowerView.lbRemain text:[NSString stringWithFormat:@"剩余%ld朵",(self.haveFlowerNum - self.sendFlowerNum)] rangeString:[NSString stringWithFormat:@"%ld",(self.haveFlowerNum - self.sendFlowerNum)] color:[UIColor rgbFromHexString:@"#FF0053" alpaa:1.0]];
    //减一
    [self.sendFlowerView.btnSubFNum addTarget:self action:@selector(subSendNum) forControlEvents:UIControlEventTouchUpInside];
    //加一
    [self.sendFlowerView.btnAddFNum addTarget:self action:@selector(addSendNum) forControlEvents:UIControlEventTouchUpInside];
    [self.coverView addSubview:self.sendFlowerView];

    
}
#pragma mark - 送优惠券
-(void)sendCoupons{
    
    YDLog(@"送优惠券");
    [self.giftView removeFromSuperview];
    [self backToView:nil];
    MyGiftCertificateVC *myGiftCertificateVC = [[MyGiftCertificateVC alloc]init];
    //从其他界面进入我的礼券
    myGiftCertificateVC.isPushFromPerCenter = NO;
    [self.navigationController pushViewController:myGiftCertificateVC animated:YES];
    
    
}

#pragma mark - 关闭弹出的视图
-(void)backToView:button{
   
    [self.sendFlowerView removeFromSuperview];
    [self.sendSongView removeFromSuperview];
    [self.coverView removeFromSuperview];
    
}

#pragma mark - 改变送花数
//减少
-(void)subSendNum{
    if (self.sendFlowerNum >= 1) {
        self.sendFlowerNum --;
        [self.sendFlowerView subFlower:self.sendFlowerNum];
        [self.sendFlowerView.btnSendFNum setTitle:[NSString stringWithFormat:@"%d",self.sendFlowerNum] forState:UIControlStateNormal];
      
        [self.sendFlowerView setLbTextForDifferentColor:self.sendFlowerView.lbRemain text:[NSString stringWithFormat:@"剩余%ld朵",(self.haveFlowerNum - self.sendFlowerNum)] rangeString:[NSString stringWithFormat:@"%ld",(self.haveFlowerNum - self.sendFlowerNum)] color:[UIColor rgbFromHexString:@"#FF0053" alpaa:1.0]];
    }
    
    
}
//增加
-(void)addSendNum{
    if (self.haveFlowerNum - self.sendFlowerNum >= 1) {
        self.sendFlowerNum ++;
        [self.sendFlowerView addFlower:self.sendFlowerNum];
        [self.sendFlowerView.btnSendFNum setTitle:[NSString stringWithFormat:@"%d",self.sendFlowerNum] forState:UIControlStateNormal];
        [self.sendFlowerView setLbTextForDifferentColor:self.sendFlowerView.lbRemain text:[NSString stringWithFormat:@"剩余%ld朵",(self.haveFlowerNum - self.sendFlowerNum)] rangeString:[NSString stringWithFormat:@"%ld",(self.haveFlowerNum - self.sendFlowerNum)] color:[UIColor rgbFromHexString:@"#FF0053" alpaa:1.0]];
    }
    
}


#pragma mark - sendFlowerHandle 确定送花
-(void)sendFlowerHandle{
    //发送送花请求
    if (self.sendFlowerNum >= 1) {
        [[NetReqManager getInstance] sendGetSendUserFlower:[ListenToMeDBManager getUuid] LUserId:self.friendUserBaseInfoNet.uuid IFlowerNum:self.sendFlowerNum];
        
    }
    [self.coverView removeFromSuperview];
//    [self.sendFlowerView.superview removeFromSuperview];
    [self.sendFlowerView removeFromSuperview];
}



#pragma mark - 当多条会话记录之间的间隔在一分钟之内,则不显示聊天的时间,否则显示聊天的时间
-(BOOL)showOrHiddednTime:(NSDate *)nowDate recentyDate:(NSDate *)recentyDate{
    int64_t nowTime = [nowDate timeIntervalSince1970] * 1000;
    int64_t recentyTime = [recentyDate timeIntervalSince1970] * 1000;
    if ( fabsl((nowTime - recentyTime)) > 60000) {
        return NO;
    }else{
        return YES;
    }
}

#pragma mark - SKTAudioPlayerDelegate
-(void)audioPlayer:(STKAudioPlayer *)audioPlayer stateChanged:(STKAudioPlayerState)state previousState:(STKAudioPlayerState)previousState{
    
    switch (state) {
        case STKAudioPlayerStateReady:
            
            break;
        case STKAudioPlayerStateBuffering:
            
            
            break;
        case STKAudioPlayerStatePaused:
            
            break;
        case STKAudioPlayerStatePlaying:
//            if (self.listenToMeData.currentMusicAudition) {
//#warning 进入后台,锁屏播放
//                [self showInfoInLockedScreen:self.listenToMeData.currentMusicAudition];
//            }
            break;
        case STKAudioPlayerStateStopped:
            if (self.progressUpdateTimer) {
                [self.progressUpdateTimer invalidate];
                self.progressUpdateTimer = nil;
            }
            
            [ListenToMeData getInstance].currentMusicAudition = nil;
//            self.btnSongPlay.selected = NO;
            
            break;
        case STKAudioPlayerStateRunning:
            
            break;
        case STKAudioPlayerStateDisposed:
            
            break;
        case STKAudioPlayerStateError:
            
            break;
            
        default:
            break;
    }
    
}
-(void)audioPlayer:(STKAudioPlayer *)audioPlayer didStartPlayingQueueItemId:(NSObject *)queueItemId{
    
}
-(void)audioPlayer:(STKAudioPlayer *)audioPlayer didFinishBufferingSourceWithQueueItemId:(NSObject *)queueItemId{
    
}

-(void)audioPlayer:(STKAudioPlayer *)audioPlayer didFinishPlayingQueueItemId:(NSObject *)queueItemId withReason:(STKAudioPlayerStopReason)stopReason andProgress:(double)progress andDuration:(double)duration{
    
}

-(void)audioPlayer:(STKAudioPlayer *)audioPlayer unexpectedError:(STKAudioPlayerErrorCode)errorCode{
    
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
