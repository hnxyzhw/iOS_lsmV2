//
//  FriendMsgCell.m
//  ListenToMe
//
//  Created by yadong on 2/11/15.
//  Copyright (c) 2015 listentome. All rights reserved.
//

#import "FriendMsgCell.h"
#import "FreindMsgFrameModel.h"
#import "FreindMsgModel.h"
#import "UIImage+Extension.h"
#import "NSDate+ZHW.h"

@interface FriendMsgCell ()
/**
 * 时间
 */
@property(strong,nonatomic) UILabel *lbTime;

/**
 * 头像
 */
@property(strong,nonatomic) UIImageView *imgAvatar;
/**
 *  指示箭头
 */
@property(strong,nonatomic) UIImageView *arrowView;
/**
 *  发送的歌曲,显示歌曲的名字
 */
@property(strong,nonatomic) UILabel *lbSongName;

@end

@implementation FriendMsgCell

+(instancetype)cellWithTableView:(UITableView *)tableView
{
    static NSString *identifier = @"message";
    FriendMsgCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil) {
        cell = [[FriendMsgCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    
    return cell;
}


/**
 * 重写init方法，让类一创建出来就拥有某些属性
 */
-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{

    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
        // 添加将来可能会用到的子控件
        // 1.添加-时间label
        UILabel *timeLabel = [[UILabel alloc]init];
        timeLabel.font = [UIFont systemFontOfSize:13.0];
        timeLabel.textAlignment = NSTextAlignmentCenter;
        timeLabel.textColor = [UIColor grayColor];
        timeLabel.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:timeLabel]; // 把timeLable添加到cell的内容视图 self.contentView
        _lbTime = timeLabel;
        
        // 2.添加-消息内容
        UIButton *contentBtn = [[UIButton alloc]init];
        contentBtn.backgroundColor = [UIColor clearColor];
        contentBtn.titleLabel.font = NJTextFont;
        [contentBtn setTitleColor:[UIColor purpleColor] forState:UIControlStateNormal];
        contentBtn.titleLabel.numberOfLines = 0;
        contentBtn.layer.masksToBounds = YES;
        contentBtn.layer.cornerRadius = 5;
        contentBtn.userInteractionEnabled = YES;
//        contentBtn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;//设置为您做位置,先设置未居左,默认居中
//        contentBtn.titleLabel.textAlignment = NSTextAlignmentLeft;
//        contentBtn.contentEdgeInsets = UIEdgeInsetsMake(5, 5, 0, 0);
        [self.contentView addSubview:contentBtn];
        _btnContent = contentBtn;
        
        // 3.添加头像
        UIImageView *avatarImg = [[UIImageView alloc]init];
        [self.contentView addSubview:avatarImg];
        _imgAvatar = avatarImg;
        
        // 4.清空cell的背景色
        self.backgroundColor = [UIColor clearColor];
        
        // 5.设置按钮的内边框
        _btnContent.contentEdgeInsets = UIEdgeInsetsMake(NJEdgeInsetsWidth, NJEdgeInsetsWidth, NJEdgeInsetsWidth, NJEdgeInsetsWidth);
        
        UIImageView *arrowImgView = [[UIImageView alloc]init];
        arrowImgView.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:arrowImgView];
        _arrowView= arrowImgView;
    
    }
    
    return self;
}


/**
 *  FreindMsgFrameModel的属性 messageFrame，使其一加载就做某些操作
 */
-(void)setMessageFrame:(FreindMsgFrameModel *)messageFrame
{
    _messageFrame = messageFrame;
    
    // 0.获取数据模型---一初始化msg的frame时，就会初始化msgmodel的对象
    FreindMsgModel *msgModel = _messageFrame.message;
    
    // 1.设置时间
    long long time = [msgModel.messageId longLongValue];
    
//    NSDate *dateTime =[[NSDate alloc]initWithTimeIntervalSince1970:time/1000.0];
//    
//    NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
//    formatter.dateFormat = @"MM-dd HH:mm:ss";
//    self.lbTime.text = [formatter stringFromDate:dateTime];
    self.lbTime.text = [self getCreatedTime:time];
    
//    self.lbTime.text = msgModel.time;
    self.lbTime.frame = _messageFrame.timeF;
    
    // 2.设置头像
    if (FreindMsgModelTypeMe == msgModel.type) {
        //自己发的
        [self.imgAvatar sd_setImageWithURL:[NSURL URLWithString:[ListenToMeData getInstance].stUserBaseInfoNet.sCovver] placeholderImage:[UIImage imageNamed:@"icon.png"]];
    }else{
        [self.imgAvatar sd_setImageWithURL:[NSURL URLWithString:self.thePerosnCover] placeholderImage:[UIImage imageNamed:@"icon.png"]];
    }
    
    self.imgAvatar.frame = _messageFrame.iconF;
    self.imgAvatar.layer.masksToBounds = YES;
    self.imgAvatar.layer.cornerRadius = self.imgAvatar.width * 0.5;
    
    // 3.设置正文
    
    if ([msgModel.messageType intValue] == MESSAGE_TYPEMessageTypePrivate) {
        
        
        [self.btnContent setTitle:msgModel.content forState:UIControlStateNormal];
        self.btnContent.frame = _messageFrame.textF;
        
        //    self.btnContent.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        //    self.btnContent.titleLabel.textAlignment = NSTextAlignmentLeft;
        //    self.btnContent.contentEdgeInsets = UIEdgeInsetsMake(0, 5, 0, 5);
        self.btnContent.titleEdgeInsets = UIEdgeInsetsMake(0, - 5, 0, - 5);
        self.btnContent.size = CGSizeMake(_messageFrame.textF.size.width, _messageFrame.textF.size.height - 10);
        
        // 4.设置背景图片
        //    UIImage *newImg = nil;
        UIImage *arrowImg = nil; //指示剪头图标
        UIColor *bgColor = nil; //聊天内容显示区域的背景色
        
        if (FreindMsgModelTypeMe == msgModel.type) {
            // 自己发的
            //        newImg = [UIImage resizableImageWithName:@"chat_send_nor"];
            
            arrowImg = [UIImage resizableImageWithName:@"三角指示（紫色）.png"];
            [self.btnContent setTitleColor:[UIColor rgbFromHexString:@"#FFFFFF" alpaa:1.0] forState:UIControlStateNormal];
            bgColor = [UIColor rgbFromHexString:@"#AC56FF" alpaa:0.8];
            self.arrowView.frame = CGRectMake(self.btnContent.x + self.btnContent.width, self.imgAvatar.center.y - 4.5, 9, 16);
            _arrowView.image = arrowImg;
            
        } else{
            // 别人发的
            //        newImg = [UIImage resizableImageWithName:@"chat_recive_nor"];
            arrowImg = [UIImage resizableImageWithName:@"三角指示.png"];
            [self.btnContent setTitleColor:[UIColor rgbFromHexString:@"#4A4A4A" alpaa:1.0] forState:UIControlStateNormal];
            bgColor = [UIColor rgbFromHexString:@"#D8D8D8" alpaa:0.8];
            self.arrowView.frame = CGRectMake(self.btnContent.x - 9,self.imgAvatar.center.y - 4.5, 9, 16);
            self.arrowView.image = arrowImg;
        }
        
        self.btnContent.backgroundColor = bgColor;
        
    }else if ([msgModel.messageType intValue] == MESSAGE_TYPEMessageTypeSongs){
        
        NSArray *arrContent = [msgModel.content componentsSeparatedByString:@"-"];
        
        if (FreindMsgModelTypeMe == msgModel.type) {
        
            self.btnContent.frame = _messageFrame.textF;
            self.btnContent.size = CGSizeMake(87, 56);
            UIImageView *sendSongMsgView =[[UIImageView alloc]initWithFrame:self.btnContent.bounds];
            [sendSongMsgView setImage:[UIImage imageNamed:@"歌曲.png"]];
            sendSongMsgView.userInteractionEnabled = YES;
            [self.btnContent addSubview:sendSongMsgView];
            
        }
        
        if (FreindMsgModelTypeOther == msgModel.type) {
            self.btnContent.frame = _messageFrame.textF;
            self.btnContent.size = CGSizeMake(87, 56);
            UIImageView *sendSongMsgView =[[UIImageView alloc]initWithFrame:self.btnContent.bounds];
            [sendSongMsgView setImage:[UIImage imageNamed:@"歌曲.png"]];
            sendSongMsgView.userInteractionEnabled = YES;
            [self.btnContent addSubview:sendSongMsgView];
        }
        
        
        _lbSongName = [[UILabel alloc]initWithFrame:CGRectMake(10, (self.btnContent.height - 10) * 0.5  , self.btnContent.width - 20, 20)];
        _lbSongName.textColor = [UIColor whiteColor];
        _lbSongName.textAlignment = NSTextAlignmentLeft;
        _lbSongName.font = [UIFont systemFontOfSize:12.0];
        _lbSongName.text = arrContent.lastObject;
        [self.btnContent addSubview:_lbSongName];
        
        
        
//        [[NetReqManager getInstance]sendGetMusicWorkByID:[ListenToMeDBManager getUuid] LWorkID:[msgModel.content longLongValue]];
        
//        [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(setSendMusicWorkName) name:NOTIFY_GET_MUSICWOKRBSAEINFO_PAGE_RESP object:nil];
        
        
    }
    
    
    
}


#pragma mark - 根据消息类型(送歌时)获取要显示的歌曲的名字setSendMusicWorkName
-(void)setSendMusicWorkName{
//    MusicWorkBaseInfo *sendMusicWorkBaseInfo =[ListenToMeData getInstance].musicWorkBaseInfo;
//    _lbSongName.text = sendMusicWorkBaseInfo.stSongInfo.sSongName;
    
}

-(void)dealloc{
//    [[NSNotificationCenter defaultCenter] removeObserver:self name:NOTIFY_GET_MUSICWOKRBSAEINFO_PAGE_RESP object:nil];
}

#pragma mark - 计算时间间隔
-(NSString *)getCreatedTime:(int64_t)lCreateTime{
    
    int64_t time = lCreateTime;
    NSDate *createdDate = [[NSDate alloc]initWithTimeIntervalSince1970:time/1000.0];
    
    NSDateFormatter *fmt = [[NSDateFormatter alloc] init];
    fmt.dateFormat = @"EEE MMM dd hh:mm:ss Z yyyy";
    
    //获取聊天记录的小时,判断是上午还是下午
    NSCalendar *cal = [NSCalendar currentCalendar];
    NSDateComponents *components = [cal components:NSCalendarUnitHour fromDate:createdDate];
    
#warning 真机调试下, 必须加上这段
    fmt.locale = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US"];
    
    // 2..判断创建时间 和 现在时间 的差距
    if (createdDate.isToday) { // 今天
        if (createdDate.deltaWithNow.hour >= 1) {
            
            if (components.hour<= 12) {
                fmt.dateFormat = @"上午 hh:mm";
            }else{
                fmt.dateFormat = @"下午 hh:mm";
            }
            
            return [fmt stringFromDate:createdDate];
//            return [NSString stringWithFormat:@"%ld小时前", createdDate.deltaWithNow.hour];
        } else if (createdDate.deltaWithNow.minute >= 1) {
            return [NSString stringWithFormat:@"%ld分钟前", createdDate.deltaWithNow.minute];
        } else {
            return @"刚刚";
        }
    } else if (createdDate.isYesterday) { // 昨天
    
        if (components.hour <= 12) {
            fmt.dateFormat = @"昨天 上午 hh:mm";
        }else{
            fmt.dateFormat = @"昨天 下午 hh:mm";
        }
//        fmt.dateFormat = @"昨天 HH:mm";
        return [fmt stringFromDate:createdDate];
    } else if (createdDate.isThisYear) { // 今年(至少是前天)
        
        if (components.hour <= 12) {
            fmt.dateFormat = @"MM-dd 上午 hh:mm";
        }else{
            fmt.dateFormat = @"MM-dd 下午 hh:mm";
        }
//        fmt.dateFormat = @"MM-dd";
        return [fmt stringFromDate:createdDate];
    } else { // 非今年
        if (components.hour <= 12) {
            fmt.dateFormat = @"yyyy-MM-dd 上午 hh:mm";
        }else{
            fmt.dateFormat = @"yyyy-MM-dd 下午 hh:mm";
        }
        
//        fmt.dateFormat = @"yyyy-MM-dd";
        return [fmt stringFromDate:createdDate];
    }
    
}

#pragma mark - 其他
- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
