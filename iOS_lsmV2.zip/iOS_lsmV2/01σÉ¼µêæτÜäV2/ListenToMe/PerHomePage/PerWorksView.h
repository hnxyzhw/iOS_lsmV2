//
//  PerWorksView.h
//  ListenToMe
//
//  Created by zhw on 15/4/4.
//  Copyright (c) 2015年 listentome. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol PerWorksViewDelegate <NSObject>

@optional
/**
 *  歌曲播放
 *
 *  @param musicWorkBaseInfo 要播放的歌曲信息
 */
-(void)musicPlay:(MusicWorkBaseInfo *)musicWorkBaseInfo;
/**
 *  私聊
 *
 *  @param userBaseInfoNet
 */
-(void)musicWorkChatWithUser:(MusicWorkBaseInfo *)musicWorkBaseInfo;
/**
 *  送花
 *
 *  @param musicWorkBaseInfo 
 */
-(void)musicWorkSendFlower:(MusicWorkBaseInfo *)musicWorkBaseInfo;
@end

@interface PerWorksView : UIView<UITableViewDataSource,UITableViewDelegate>
@property(strong,nonatomic) UITableView *mTableView;
@property(nonatomic,assign) id<PerWorksViewDelegate>delegate;
@end
