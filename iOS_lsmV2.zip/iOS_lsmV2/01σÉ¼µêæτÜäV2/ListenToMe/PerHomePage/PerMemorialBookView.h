//
//  PerMemorialBookView.h
//  ListenToMe
//
//  Created by zhw on 15/4/4.
//  Copyright (c) 2015年 listentome. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol PerMemorialBookViewDelegate <NSObject>

@optional
/**
 *  聊天
 *
 *  @param commemorateBaseInfo 
 */
-(void)memorialWorkSendFlower:(CommemorateBaseInfo *)commemorateBaseInfo;

@end



@interface PerMemorialBookView : UIView<UITableViewDataSource,UITableViewDelegate>
@property(nonatomic,strong)UITableView *mTableView;
@property(nonatomic,assign)id<PerMemorialBookViewDelegate>delegate;
@end
