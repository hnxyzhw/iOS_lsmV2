//
//  PerMemorialBookView.m
//  ListenToMe
//
//  Created by zhw on 15/4/4.
//  Copyright (c) 2015年 listentome. All rights reserved.
//

#import "PerMemorialBookView.h"
#import "YDKMemmoryCell.h"
#import "HWShareAlertVC.h"
@interface PerMemorialBookView ()
@property(nonatomic,strong) ListenToMeData *listenToMeData;
/**
 *  用户纪念册数组
 */
@property(nonatomic,strong) NSMutableArray *arrCommemorateInfoByUserId;
///**
// *  纪念册信息
// */
//@property(nonatomic,strong) CommemorateBaseInfo *commemorateBaseInfo;
/**
 *  分享弹窗
 */
@property(nonatomic,strong) HWShareAlertVC *shareVC;
@end

@implementation PerMemorialBookView

-(instancetype)initWithFrame:(CGRect)frame{
    
    if (self = [super initWithFrame:frame]) {
        self.backgroundColor = [UIColor clearColor];
        [self setTableView];
        [self initData];
    }
    return self;
    
}

-(void)setTableView{
    
    self.mTableView = [[UITableView alloc]initWithFrame:self.bounds];
    self.mTableView.delegate = self;
    self.mTableView.dataSource = self;
    [self addSubview:self.mTableView];
    
    
}

-(void)initData{
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshTableView) name:NOTIFY_GET_COMMEMORATEINFO_BYUSERID_PAGE_RESP object:nil];
    
    self.listenToMeData = [ListenToMeData getInstance];
}

-(void)refreshTableView{
    self.arrCommemorateInfoByUserId = self.listenToMeData.arrCommemorateInfoByUserId;
    [self.mTableView reloadData];
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:NOTIFY_GET_COMMEMORATEINFO_BYUSERID_PAGE_RESP object:nil];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *ID = @"myWorkscell";
    YDKMemmoryCell *cell = [tableView dequeueReusableCellWithIdentifier:ID];
    if (cell == nil) {
        cell = [[YDKMemmoryCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:ID];
    }
    
    CommemorateBaseInfo *commemorateBaseInfo = self.arrCommemorateInfoByUserId[indexPath.section];
    
    cell.arrUserBaseInfoNet = commemorateBaseInfo.stUserBaseInfoNet;

    
    if ([commemorateBaseInfo.sCommIcon isEqualToString:@""] || commemorateBaseInfo == nil) {
        
        cell.imgCover.image = [UIImage imageNamed:@"temp5.png"];
    }else{
    
        [cell.imgCover sd_setImageWithURL:[NSURL URLWithString:commemorateBaseInfo.sCommIcon]];
    }
    
    cell.lbTheme.text = @"闺蜜秀";
    
    if ([commemorateBaseInfo.sCommName isEqualToString:@""] || commemorateBaseInfo.sCommName == nil) {
        cell.lbPartyName.text = @"咸蛋超人的生日趴";
    }else{
        
        cell.lbPartyName.text = commemorateBaseInfo.sCommName;
    }
    
    
    if (commemorateBaseInfo.stLabelInfo) {
        switch (commemorateBaseInfo.stLabelInfo.count) {
            case 1:
                [cell.btnMemoryLabel_01 setTitle:((LabelInfo *)commemorateBaseInfo.stLabelInfo[0]).label forState:UIControlStateNormal];
                cell.btnMemoryLabel_02.hidden = YES;
                cell.btnMemoryLabel_03.hidden = YES;
                break;
            case 2:
                [cell.btnMemoryLabel_01 setTitle:((LabelInfo *)commemorateBaseInfo.stLabelInfo[0]).label forState:UIControlStateNormal];
                [cell.btnMemoryLabel_02 setTitle:((LabelInfo *)commemorateBaseInfo.stLabelInfo[1]).label forState:UIControlStateNormal];
                cell.btnMemoryLabel_03.hidden = YES;
                break;
            case 3:
                [cell.btnMemoryLabel_01 setTitle:((LabelInfo *)commemorateBaseInfo.stLabelInfo[0]).label forState:UIControlStateNormal];
                [cell.btnMemoryLabel_02 setTitle:((LabelInfo *)commemorateBaseInfo.stLabelInfo[1]).label forState:UIControlStateNormal];
                [cell.btnMemoryLabel_03 setTitle:((LabelInfo *)commemorateBaseInfo.stLabelInfo[2]).label forState:UIControlStateNormal];
                
                break;
                
            default:
                cell.btnMemoryLabel_01.hidden = YES;
                cell.btnMemoryLabel_02.hidden = YES;
                cell.btnMemoryLabel_03.hidden = YES;
                break;
        }
        
        
    }

    
    cell.imgTheme.image = [UIImage imageNamed:@"memoryTopShow.png"];
    
    cell.btnNumSongs.number = [NSString stringWithFormat:@"%d",commemorateBaseInfo.iMusicNum];
    cell.btnNumAlbums.number =[NSString stringWithFormat:@"%d",commemorateBaseInfo.iPictureNum];
    cell.btnNumSee.number = [NSString stringWithFormat:@"%d",commemorateBaseInfo.iWatchedNum];
    cell.btnNumFlower.number = [NSString stringWithFormat:@"%d",commemorateBaseInfo.stUser.iFlowerNum];
    
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    cell.btnNumSongs.number = [NSString stringWithFormat:@"%d",commemorateBaseInfo.iMusicNum];
    cell.btnNumAlbums.number =[NSString stringWithFormat:@"%d",commemorateBaseInfo.iPictureNum];
    cell.btnNumSee.number = [NSString stringWithFormat:@"%d",commemorateBaseInfo.iWatchedNum];
    cell.btnNumFlower.number = [NSString stringWithFormat:@"%d",commemorateBaseInfo.stUser.iFlowerNum];
    
    [cell.btnActionFlowes addTarget:self action:@selector(sendingFlowers:) forControlEvents:UIControlEventTouchUpInside];
    [cell.btnActionShare addTarget:self action:@selector(alertForShare:) forControlEvents:UIControlEventTouchUpInside];

    
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 273;
    
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    return 1;
    
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    
    return self.arrCommemorateInfoByUserId.count;
    
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    
    return 15;
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 0;
}


#pragma mark - cell中点击送花弹出送花界面
-(void)sendingFlowers:(UIButton *)btnSendFlower{
    //当前点击头像获取的cell
    UITableViewCell *cell = (UITableViewCell *)[[btnSendFlower superview] superview];
    //获取cell的indexPath的值
    NSIndexPath *indexPath = [self.mTableView indexPathForCell:cell];
    CommemorateBaseInfo *commemorateBaseInfo = self.arrCommemorateInfoByUserId[indexPath.section];
    
    if ([_delegate respondsToSelector:@selector(memorialWorkSendFlower:)]) {
        [_delegate memorialWorkSendFlower:commemorateBaseInfo];
    }
}

#pragma mark - cell中点击分享提示分享平台
-(void)alertForShare:(UIButton *)btnShare{
    _shareVC = [[HWShareAlertVC alloc]init];
    //    [[[UIApplication sharedApplication]keyWindow]addSubview:shareVC.view];
    
    [self.superview addSubview:_shareVC.view];
    
    
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
