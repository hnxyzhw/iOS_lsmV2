//
//  NetReqManager.m
//  ListenToMe
//
//  Created by yadong on 1/27/15.
//  Copyright (c) 2015 listentome. All rights reserved.
//

#import "NetReqManager.h"
#import "NetRecvManager.h"
#import "TCPNetEngine.h"


@interface NetReqManager ()
@property(strong,nonatomic) ListenToMeData *mListenToMeData;
@end

@implementation NetReqManager
@synthesize mListenToMeData;

static NetReqManager *mEngine;

+(NetReqManager *)getInstance
{
    @synchronized(self)
    {
        if (mEngine == nil) {
            mEngine = [[self alloc]init];
        }
    }
    return mEngine;
}

-(id)init
{
    if (self = [super init]) {
        sendStatus = Default;
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(disconnect:) name:NOTIFY_NET_DISCONNECT object:nil];
        mListenToMeData = [ListenToMeData getInstance];
    }
    return self;
}

-(void)disconnect:(NSNotification *)nitification{
    sendStatus = Default;
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"网络断开" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
    [alert show];
}

-(BOOL)netWorkError
{
    if (!mListenToMeData.bConnected) {
        //        [self disconnect:];
        return YES;
    }
    return NO;
}


#pragma mark - 登录请求发包
-(void)sendLoginReq:(UserBaseInfoNet *)userBaseInfo{
    YDLog(@"sendLoginReq");
    
    if([self netWorkError]){
        YDLog(@"网络异常,无法登录");
        return;
    }
    CSLoginBuilder *csloginBuilder = [CSLogin builder];
    [csloginBuilder setStUserBaseInfoNet:userBaseInfo];
    [csloginBuilder setStrIosToken:@""];
    
    CSLogin *csLogin = [csloginBuilder build];
    NSData *tempData = [[TCPNetEngine getInstance]getReqLoginData:csLogin];
    [[ListenToMeData getInstance].socketIns writeData:tempData withTimeout:100 tag:STATE_CMD_REQ_LOGIN];
}

#pragma mark - 快速登录发包
-(void)sendQuickLoginReq:(long long)uuid{
    CSQuickLoginBuilder *csQuickLoginBuilder = [CSQuickLogin builder];
    [csQuickLoginBuilder setUuid:uuid];
    [csQuickLoginBuilder setStrIosToken:@""];
    
    CSQuickLogin *csQuickLogin = [csQuickLoginBuilder build];
    NSData *tempData = [[TCPNetEngine getInstance] getReqQuickLoginData:csQuickLogin];
    [[ListenToMeData getInstance].socketIns writeData:tempData withTimeout:100 tag:STATE_CMD_REQ_QUICKLOGIN];
}

#pragma mark - 退出登录发包
-(void)sendLogoutReq:(int64_t)uuid{
    CSLogoutBuilder *csLogoutBuilder = [CSLogout builder];
    csLogoutBuilder.uuid = uuid;
    
    CSLogout *csLogout = [csLogoutBuilder build];
    NSData *tempData = [[TCPNetEngine getInstance] getReqLogoutData:csLogout];
    [[ListenToMeData getInstance].socketIns writeData:tempData withTimeout:100 tag:STATE_CMD_REQ_LOGOUT];
}


-(void)sendFeedback:(NSString *)feedback{
    if ([self netWorkError]) {
        
        return;
    }
    CSFeedBackBuilder* csFeedBackBuilder = [CSFeedBack builder];
    
    csFeedBackBuilder.uuid = 10080;
    csFeedBackBuilder.iSysVersion = 100;
    csFeedBackBuilder.iMobleSystem = 1;
    csFeedBackBuilder.sContent = feedback;
    
    CSFeedBack* csFeedBack = [csFeedBackBuilder build];
    
    NSData* tempData = [[TCPNetEngine getInstance] getReqFeedbackData:csFeedBack];
    [[ListenToMeData getInstance].socketIns writeData:tempData withTimeout:100 tag:0];
}



-(void)sendUpdate{
    if ([self netWorkError]) {
        
        return;
    }
    CSUpdateBuilder* csUpdateBuilder = [CSUpdate builder];
    
    csUpdateBuilder.uuid = 10080;
    csUpdateBuilder.iMobleSystem = 1;
    csUpdateBuilder.iSysVersion = 101;
    csUpdateBuilder.strMobileScreen = @"IOS8";
    csUpdateBuilder.strMobileScreen = @"100";
    
    CSUpdate *csUpdate = [csUpdateBuilder build];
    
    NSData* tempData = [[TCPNetEngine getInstance] getReqUpdate:csUpdate];
    [[ListenToMeData getInstance].socketIns writeData:tempData withTimeout:100 tag:0];
}


-(void)sendUploadMusicWorkCurSeq:(long long)curSeq sendDataDic:(NSMutableDictionary *)sendDataDic desc:(NSString*) sDesc songid:(long long)lSongID musicworkid:(long long)lMusicWorkID{
    if ([self netWorkError]) {
        return;
    }
    
    CSUploadMusicWorkBuilder *stCSUploadMusicWorkBuilder = [CSUploadMusicWork builder];
    [stCSUploadMusicWorkBuilder setSDesc:sDesc];
    [stCSUploadMusicWorkBuilder setLCurrentPackageSeq:curSeq];
    [stCSUploadMusicWorkBuilder setLMaxPackageNum:sendDataDic.count];
    [stCSUploadMusicWorkBuilder setLMusicWorkId:lMusicWorkID];
    [stCSUploadMusicWorkBuilder setUuid:10080];
    [stCSUploadMusicWorkBuilder setLSongId:lSongID];
    [stCSUploadMusicWorkBuilder setVMusicDatas:[sendDataDic objectForKey:[NSString stringWithFormat:@"%lld",curSeq]]];
    NSLog(@"stCSUploadMusicWorkBuilder : %lld" , curSeq);
    
    
    CSUploadMusicWork *stCSUploadMusicWork = [stCSUploadMusicWorkBuilder build];
    NSData* tempData = [[TCPNetEngine getInstance] getReqUploadMusicWork:stCSUploadMusicWork];
    [[ListenToMeData getInstance].socketIns writeData:tempData withTimeout:100 tag:0];
}


-(void)sendAddDateWorkInfo{
    if ([self netWorkError]) {
        
        return;
    }
    CSAddDateWorkInfoBuilder* csAddDateWorkInfoBuilder = [CSAddDateWorkInfo builder];
    
    csAddDateWorkInfoBuilder.uuid = 10080;
    csAddDateWorkInfoBuilder.sTheme = @"约会1";
    csAddDateWorkInfoBuilder.partyType = PARTY_TYPEPartyTypeOne;
    csAddDateWorkInfoBuilder.costType = COST_TYPECostTypeAa;
    csAddDateWorkInfoBuilder.bringFriendType = BRINGFRIEND_TYPEBringfriendTypeYes;
    csAddDateWorkInfoBuilder.sDesc = @"ddddd";
    csAddDateWorkInfoBuilder.lStopTime = (long long)[[NSDate date] timeIntervalSince1970];
    csAddDateWorkInfoBuilder.lktvId = 111111;
    [csAddDateWorkInfoBuilder addLInUserId:124];
 
    CSAddDateWorkInfo *csAddDateWorkInfo = [csAddDateWorkInfoBuilder build];
    
    NSData* tempData = [[TCPNetEngine getInstance] getReqAddDateWorkInfo:csAddDateWorkInfo];
    [[ListenToMeData getInstance].socketIns writeData:tempData withTimeout:100 tag:0];
}

-(void)sendBindDevice:(NSString*)qrcode{
    if ([self netWorkError]) {
        
        return;
    }
    CSBindKTVRoomBuilder*  csBindKTVRoomBuilder= [CSBindKTVRoom builder];
    
    csBindKTVRoomBuilder.uuid = 10080;
    csBindKTVRoomBuilder.sKtvroomCode = qrcode;
    
    CSBindKTVRoom *csBindKTVRoom = [csBindKTVRoomBuilder build];
    
    NSData* tempData = [[TCPNetEngine getInstance] getReqBindKTVRoom:csBindKTVRoom];
    [[ListenToMeData getInstance].socketIns writeData:tempData withTimeout:100 tag:0];
}



#pragma mark - KTVListInfo请求
-(void)sendGetKtvListInfo:(int32_t)iOffset INum:(int32_t)iNum{
    CSGetKtvListInfoBuilder *csGetKtvListBuilder = [CSGetKtvListInfo builder];
    csGetKtvListBuilder.uuid = [ListenToMeDBManager getUuid];
    csGetKtvListBuilder.iOffset = iOffset;
    csGetKtvListBuilder.iNum = iNum;
    
    CSGetKtvListInfo *csGetKtvListInfo = [csGetKtvListBuilder build];
    NSData *tempData = [[TCPNetEngine getInstance] getKtvListInfo:csGetKtvListInfo];
    [[ListenToMeData getInstance].socketIns writeData:tempData withTimeout:100 tag:STATE_CMD_REQ_GET_KTVLISTINFO];
}


#pragma mark - 根据KTVId获取KTV的信息
-(void)sendGetKtvInfoById:(int64_t)lKtvid{
    
    CSGetKtvInfoByIdBuilder *csGetKtvInfoByIdBuilder = [CSGetKtvInfoById builder];
    csGetKtvInfoByIdBuilder.lKtvid = lKtvid;
    
    CSGetKtvInfoById *csGetKtvInfoById = [csGetKtvInfoByIdBuilder build];
    NSData *tempData = [[TCPNetEngine getInstance] getKtvInfoById:csGetKtvInfoById];
    [[ListenToMeData getInstance].socketIns writeData:tempData withTimeout:100 tag:STATE_CMD_REQ_GET_KTVINFO];
    
}

#pragma mark - 更换新一批用户
-(void)sendGetSwitchKtvUserList:(int32_t)iOffset INum:(int32_t)iNum LKtvId:(int64_t)lKtvId{
    
    CSGetSwitchKtvUserListBuilder *csGetSwitchKtvUserListBuilder = [CSGetSwitchKtvUserList builder];
    csGetSwitchKtvUserListBuilder.lKtvId = lKtvId;
    csGetSwitchKtvUserListBuilder.iOffset = iOffset;
    csGetSwitchKtvUserListBuilder.iNum = iNum;
    
    CSGetSwitchKtvUserList *csGetSwitchKtvUserList = [csGetSwitchKtvUserListBuilder build];
    NSData *tempData = [[TCPNetEngine getInstance] getSwitchKtvUserList:csGetSwitchKtvUserList];
    [[ListenToMeData getInstance].socketIns writeData:tempData withTimeout:100 tag:STATE_CMD_REQ_GET_SWITCHKTVUSERLIST];
}

#pragma mark - 更多KTV热歌
-(void)sendGetKtvHostMusicList:(int64_t)lKtvId IOffset:(int32_t)iOffset INum:(int32_t)iNum{
    
    CSGetKtvHostMusicListBuilder *csGetKtvHostMusicListBuilder = [CSGetKtvHostMusicList builder];
    csGetKtvHostMusicListBuilder.lKtvId = lKtvId;
    csGetKtvHostMusicListBuilder.iOffset = iOffset;
    csGetKtvHostMusicListBuilder.iNum = iNum;
    
    CSGetKtvHostMusicList *csGetKtvHostMuicList = [csGetKtvHostMusicListBuilder build];
    NSData *tempData = [[TCPNetEngine getInstance] getKtvHostMusicList:csGetKtvHostMuicList];
    [[ListenToMeData getInstance].socketIns writeData:tempData withTimeout:100 tag:STATE_CMD_REQ_GET_KTVHOSTMUSICLIST];
}

#pragma mark - 获取更多KTV纪念册
-(void)sendGetKtvCommemorativeList:(int64_t)lKtvId IOffset:(int32_t)iOffset INum:(int32_t)iNum{
    CSGetKtvCommemorativeListBuilder *csGetKtvCommemorativeListBuilder = [CSGetKtvCommemorativeList builder];
    csGetKtvCommemorativeListBuilder.lKtvId = lKtvId;
    csGetKtvCommemorativeListBuilder.iOffset = iOffset;
    csGetKtvCommemorativeListBuilder.iNum = iNum;
    
    CSGetKtvCommemorativeList *csGetKtvCommemorativeList = [csGetKtvCommemorativeListBuilder build];
    NSData *tempData =[[TCPNetEngine getInstance] getktvCommemorativateList:csGetKtvCommemorativeList];
    [[ListenToMeData getInstance].socketIns writeData:tempData withTimeout:100 tag:STATE_CMD_REQ_GET_KTVCOMMEMORATIVELIST];
}

#pragma mark - 获取用户的音乐作品,如果不需要登录uuid传入为0 (LWatchUserId)被查看者id ,如果为空就是查看用户自己的作品 ,如果不为空就是用户查看别人作品
-(void)sendGetMusicWorkWithUserId:(int64_t)uuid IOffset:(int32_t)iOffset INum:(int32_t)iNum LWatchUserId:(int64_t)lWatchUserId{
 
    CSGetMusicWorkBuilder *csGetMusicWorkBuilder = [CSGetMusicWork builder];
    csGetMusicWorkBuilder.uuid = uuid;
    csGetMusicWorkBuilder.iOffset = iOffset;
    csGetMusicWorkBuilder.iNum = iNum;
    csGetMusicWorkBuilder.lWatchUserId = lWatchUserId;
    
    CSGetMusicWork *csGetMusicWork = [csGetMusicWorkBuilder build];
    NSData *tempData = [[TCPNetEngine getInstance] getMusicWork:csGetMusicWork];
    [[ListenToMeData getInstance].socketIns writeData:tempData withTimeout:100 tag:STATE_CMD_REQ_GET_MUSICWORK];
    
    
}

#pragma mark - 根据作品id获取作品详情信息
-(void)sendGetMusicWorkByID:(int64_t)uuid LWorkID:(int64_t)lWorkID{
    CSGetMusicWorkByIDBuilder *csGetMusicWorkByIDBuilder = [CSGetMusicWorkByID builder];
    csGetMusicWorkByIDBuilder.uuid = uuid;
    csGetMusicWorkByIDBuilder.lWorkId = lWorkID;
    
    CSGetMusicWorkByID *csGetMusicWorkByID = [csGetMusicWorkByIDBuilder build];
    NSData *tempData = [[TCPNetEngine getInstance] getMusicWorkByID:csGetMusicWorkByID];
    [[ListenToMeData getInstance].socketIns writeData:tempData withTimeout:100 tag:STATE_CMD_REQ_GET_MUSICWORKBYID];
}

#pragma mark - 获取去k歌回忆纪念册信息
-(void)sendGetCommemorateInfo:(int64_t)uuid IOffset:(int32_t)iOffset INum:(int32_t)iNum{
    
    CSGetCommemorateInfoBuilder *csGetCommemorateInfoBuilder = [CSGetCommemorateInfo builder];
    csGetCommemorateInfoBuilder.uuid = uuid;
    csGetCommemorateInfoBuilder.iOffset = iOffset;
    csGetCommemorateInfoBuilder.iNum = iNum;
    
    CSGetCommemorateInfo *csGetCommemorateInfo = [csGetCommemorateInfoBuilder build];
    NSData *tempData = [[TCPNetEngine getInstance] getCommenorateInfo:csGetCommemorateInfo];
    [[ListenToMeData getInstance].socketIns writeData:tempData withTimeout:100 tag:STATE_CMD_REQ_GET_COMMEMORATEINFO];
    
}

#pragma mark - 获取用户相片列表,传入纪念册ID为空 查看的是用户自己的相册, 传入相应的纪念册ID查看纪念册里相片
-(void)sendGetPictureList:(int64_t)uuid IOffset:(int32_t)iOffset Inum:(int32_t)iNum LWatchUserId:(int64_t)lWatchUserId LCommemorateId:(int64_t)lCommenorateId{
    CSGetPictureListBuilder *csGetPictureListBuilder = [CSGetPictureList builder];
    csGetPictureListBuilder.uuid = uuid;
    csGetPictureListBuilder.iOffset = iOffset;
    csGetPictureListBuilder.iNum = iNum;
    csGetPictureListBuilder.lWatchUserId = lWatchUserId;
    csGetPictureListBuilder.lCommemorateId = lCommenorateId;
    
    CSGetPictureList *csGetPictuerList = [csGetPictureListBuilder build];
    NSData *tempData = [[TCPNetEngine getInstance] getPictureList:csGetPictuerList];
    [[ListenToMeData getInstance].socketIns writeData:tempData withTimeout:100 tag:STATE_CMD_REQ_GET_PICTURELIST];
}

#pragma mark - 获取人气榜单列表
-(void)sendGetPopularityList:(int64_t)uuid IOffset:(int32_t)iOffset INum:(int32_t)iNum{
    CSGetPopularityListBuilder *csGetPopularityBuilder = [CSGetPopularityList builder];
    csGetPopularityBuilder.uuid = uuid;
    csGetPopularityBuilder.iOffset = iOffset;
    csGetPopularityBuilder.iNum = iNum;
    
    CSGetPopularityList *csGetPopularityList = [csGetPopularityBuilder build];
    NSData *tempData = [[TCPNetEngine getInstance] getPopularityList:csGetPopularityList];
    [[ListenToMeData getInstance].socketIns writeData:tempData withTimeout:100 tag:STATE_CMD_REQ_GET_POPULARYLIST];
}

#pragma mark - 获取新歌列表 对应深情行星
-(void)sendGetNewMusicList:(int64_t)uuid IOffset:(int32_t)iOffset INum:(int32_t)iNum{
    CSGetNewMusicListBuilder *csGetNewMusicListBuilder = [CSGetNewMusicList builder];
    csGetNewMusicListBuilder.uuid = uuid;
    csGetNewMusicListBuilder.iOffset = iOffset;
    csGetNewMusicListBuilder.iNum = iNum;
    
    CSGetNewMusicList *csGetNewMusicList = [csGetNewMusicListBuilder build];
    NSData * tempData = [[TCPNetEngine getInstance] getNewMusicList:csGetNewMusicList];
    [[ListenToMeData getInstance].socketIns writeData:tempData withTimeout:100 tag:STATE_CMD_REQ_GET_NEWMUSICLIST];
    
}

#pragma mark - 获取歌曲推荐列表,每日金曲, 对应时空胶囊
-(void)sendGetRecommendList:(int64_t)uuid IOffset:(int32_t)iOffset INum:(int32_t)iNum{
    CSGetRecommendListBuilder *csGetRecommendListBuilder = [CSGetRecommendList builder];
    csGetRecommendListBuilder.uuid = uuid;
    csGetRecommendListBuilder.iOffset = iOffset;
    csGetRecommendListBuilder.iNum = iNum;
    
    CSGetRecommendList *csGetRecommendList = [csGetRecommendListBuilder build];
    NSData *tempData  = [[TCPNetEngine getInstance] getRecommendList:csGetRecommendList];
    [[ListenToMeData getInstance].socketIns writeData:tempData withTimeout:100 tag:STATE_CMD_REQ_GET_RECOMMENDLIST];
    
}

#pragma mark - 上传照片
-(void)sendGetUploadPicture:(int64_t)uuid BPictures:(NSData *)bPictures LCommenorateId:(int64_t)lCommenorateId{
    
    CSUploadPictureBuilder *csUploadPictureBuilder = [CSUploadPicture builder];
    csUploadPictureBuilder.uuid = uuid;
    csUploadPictureBuilder.bPictures = bPictures;
    csUploadPictureBuilder.lCommemorateId = lCommenorateId;
    
    CSUploadPicture *csUploadPicture = [csUploadPictureBuilder build];
    NSData *tempData = [[TCPNetEngine getInstance] getUpLoadPicture:csUploadPicture];
    [[ListenToMeData getInstance].socketIns writeData:tempData withTimeout:100 tag:STATE_CMD_REQ_UPLOAD_PICTURE];
}

#pragma mark - 删除照片
-(void)sendGetDeletePicture:(int64_t)uuid LPhotoId:(int64_t)lPhotoId LCommemorateId:(int64_t)lCommemorateId{
    CSDeletePictureBuilder *csDeletePictureBuilder = [CSDeletePicture builder];
    csDeletePictureBuilder.uuid = uuid;
    csDeletePictureBuilder.lPhotoId = lPhotoId;
    csDeletePictureBuilder.lCommemorateId = lCommemorateId;
    
    CSDeletePicture *csDeletePicture = [csDeletePictureBuilder build];
    NSData *tempData = [[TCPNetEngine getInstance] getDeletePicture:csDeletePicture];
    [[ListenToMeData getInstance].socketIns  writeData:tempData withTimeout:100 tag:STATE_CMD_REQ_GET_DELETE_PICTURE];
}

#pragma mark - 上传头像
-(void)sendgetUploadIcon:(int64_t)uuid VIconDatas:(NSData *)vIconDatas SPictureUrl:(NSString *)sPictureUrl{
    CSUploadIconBuilder *csUploadIconBuilder = [CSUploadIcon builder];
    csUploadIconBuilder.uuid = uuid;
    csUploadIconBuilder.vIconDatas = vIconDatas;
    csUploadIconBuilder.sPictureUrl = sPictureUrl;
    
    CSUploadIcon *csUploadIcon = [csUploadIconBuilder build];
    NSData *tempData = [[TCPNetEngine getInstance] getUploadIcon:csUploadIcon];
    [[ListenToMeData getInstance].socketIns  writeData:tempData withTimeout:100 tag:STATE_CMD_REQ_UPLOAD_ICON];
}

#pragma mark - 设置个人信息
-(void)sendGetSetUserInfo:(int64_t)uuid SNickName:(NSString *)sNickName IGender:(int32_t)iGender SBirthday:(NSString *)sBirthday SSignature:(NSString *)sSignature IAge:(int32_t)iAge IPrivataSwitch:(int32_t)iPrivateSwitch Address:(NSString *)address{
    CSSetUserInfoBuilder *csSetUserInfoBuilder = [CSSetUserInfo builder];
    csSetUserInfoBuilder.uuid = uuid;
    csSetUserInfoBuilder.sNickName = sNickName;
    csSetUserInfoBuilder.iGender = iGender;
    csSetUserInfoBuilder.sBirthday = sBirthday;
    csSetUserInfoBuilder.sSignature = sSignature;
    csSetUserInfoBuilder.iAge = iAge;
    csSetUserInfoBuilder.iPrivateSwitch = iPrivateSwitch;
    csSetUserInfoBuilder.address = address;
    
    CSSetUserInfo *csSetUserInfo = [csSetUserInfoBuilder build];
    NSData *tempData = [[TCPNetEngine getInstance] getSetUserInfo:csSetUserInfo];
    [[ListenToMeData getInstance].socketIns writeData:tempData withTimeout:100 tag:STATE_CMD_REQ_SET_USERINFO];
}
#pragma mark - 获取用户基本信息
-(void)sendGetUserInfo:(int64_t)uuid{
    CSGetUserInfoBuilder *csGetUserInfoBuilder = [CSGetUserInfo builder];
    csGetUserInfoBuilder.lUserId = uuid;
    
    CSGetUserInfo *csGetUserInfo = [csGetUserInfoBuilder build];
    NSData *tempData = [[TCPNetEngine getInstance] getUserInfo:csGetUserInfo];
    [[ListenToMeData getInstance].socketIns writeData:tempData withTimeout:100 tag:STATE_CMD_REQ_USERINFO];
}
#pragma mark - 搜索ktv
-(void)sendSearchKtv:(int64_t)uuid SKeyWord:(NSString *)sKeyWord IOffset:(int32_t)iOffset INum:(int32_t)iNum{
    CSSearchKtvBuilder *csSearchKtvBuilder = [CSSearchKtv builder];
    csSearchKtvBuilder.uuid = uuid;
    csSearchKtvBuilder.sKeyWord = sKeyWord;
    csSearchKtvBuilder.iOffset = iOffset;
    csSearchKtvBuilder.iNum = iNum;
    
    CSSearchKtv *csSearchKtv = [csSearchKtvBuilder build];
    NSData *tempData = [[TCPNetEngine getInstance] getSearchKtv:csSearchKtv];
    [[ListenToMeData getInstance].socketIns writeData:tempData withTimeout:100 tag:STATE_CMD_REQ_SEARCH_KTV];
}
#pragma mark - 搜索音乐
-(void)sendSearchMusics:(int64_t)uuid SKeyWord:(NSString *)sKeyWord IOffset:(int32_t)iOffset INum:(int32_t)iNum{
    CSSearchMusicsBuilder *csSearchMusicBuilder = [CSSearchMusics builder];
    csSearchMusicBuilder.uuid = uuid;
    csSearchMusicBuilder.sKeyWord = sKeyWord;
    csSearchMusicBuilder.iOffset = iOffset;
    csSearchMusicBuilder.iNum = iNum;
    
    CSSearchMusics *csSearchMusics = [csSearchMusicBuilder build];
    NSData *tempData = [[TCPNetEngine getInstance] getSearchMusics:csSearchMusics];
    [[ListenToMeData getInstance].socketIns writeData:tempData withTimeout:100 tag:STATE_CMD_REQ_SEARCH_MUSICS];
}
#pragma mark - 搜索纪念册
-(void)sendSearchCommemorate:(int64_t)uuid SKeyWord:(NSString *)sKeyWord IOffset:(int32_t)iOffset INum:(int32_t)iNum{
    CSSearchCommemorateBuilder *csSearchCommemorateBuilder = [CSSearchCommemorate builder];
    csSearchCommemorateBuilder.uuid = uuid;
    csSearchCommemorateBuilder.sKeyWord = sKeyWord;
    csSearchCommemorateBuilder.iOffset = iOffset;
    csSearchCommemorateBuilder.iNum = iNum;
    
    CSSearchCommemorate *csSearchCommemorate = [csSearchCommemorateBuilder build];
    NSData *tempData = [[TCPNetEngine getInstance] getSearchCommemorate:csSearchCommemorate];
    [[ListenToMeData getInstance].socketIns writeData:tempData withTimeout:100 tag:STATE_CMD_REQ_SEARCH_COMMEMORATE];
}
#pragma mark - 收藏
-(void)sendCollectWork:(int64_t)uuid LMusicId:(int64_t)lMusicId LCommemorateId:(int64_t)lCommemorateId{
    CSCollectWorkBuilder *csCollectWorkBuilder = [CSCollectWork builder];
    csCollectWorkBuilder.uuid = uuid;
    csCollectWorkBuilder.lMusicId = lMusicId;
    csCollectWorkBuilder.lCommemorateId = lCommemorateId;
    
    CSCollectWork *csCollectWork  = [csCollectWorkBuilder build];
    NSData *tempData = [[TCPNetEngine getInstance] getCollectWork:csCollectWork];
    [[ListenToMeData getInstance].socketIns writeData:tempData withTimeout:100 tag:STATE_CMD_REQ_COLLECTWORK];
}

#pragma mark - 取消收藏
-(void)sendUnCollectWork:(int64_t)uuid LMusicId:(int64_t)lMusicId LCommemorateId:(int64_t)lCommemorateId{
    CSUnCollectWorkBuilder *csUnCollectWorkBuilder = [CSUnCollectWork builder];
    csUnCollectWorkBuilder.uuid = uuid;
    csUnCollectWorkBuilder.lMusicId = lMusicId;
    csUnCollectWorkBuilder.lCommemorateId = lCommemorateId;
    
    CSUnCollectWork *csUncollectWork = [csUnCollectWorkBuilder build];
    NSData *tempData = [[TCPNetEngine getInstance]getUnCollectWork:csUncollectWork];
    [[ListenToMeData getInstance].socketIns writeData:tempData withTimeout:100 tag:STATE_CMD_REQ_UN_COLLECTWORK];
}

#pragma mark - 获取我的收藏列表
-(void)sendGetCollectWorkList:(int64_t)uuid IOffset:(int32_t)iOffset INum:(int32_t)iNum{
    CSGetCollectWorkListBuilder *csGetCollectWorkListBuilder = [CSGetCollectWorkList builder];
    csGetCollectWorkListBuilder.uuid = uuid;
    csGetCollectWorkListBuilder.iOffset = iOffset;
    csGetCollectWorkListBuilder.iNum = iNum;
    
    CSGetCollectWorkList *csGetCollectWorkList = [csGetCollectWorkListBuilder build];
    NSData *tempData = [[TCPNetEngine getInstance] getCollectWorkList:csGetCollectWorkList];
    [[ListenToMeData getInstance].socketIns writeData:tempData withTimeout:100 tag:STATE_CMD_REQ_GET_COLLECTWORKLIST];
}

#pragma mark - 获取用户的礼券信息列表
-(void)sendGetUserCouponList:(int64_t)uuid IOffset:(int32_t)iOffset INum:(int32_t)iNum{
    CSGetUserCouponListBuilder *csGetUserCouponListBuilder = [CSGetUserCouponList builder];
    csGetUserCouponListBuilder.uuid = uuid;
    csGetUserCouponListBuilder.iOffset = iOffset;
    csGetUserCouponListBuilder.iNum = iNum;
    
    CSGetUserCouponList *csGetUserCouponList = [csGetUserCouponListBuilder build];
    NSData *tempData = [[TCPNetEngine getInstance] getUserCouponList:csGetUserCouponList];
    [[ListenToMeData getInstance].socketIns writeData:tempData withTimeout:100 tag:STATE_CMD_REQ_GET_USER_COUPONLIST];
}

#pragma mark - 上传用户手机号
-(void)sendUploadPhoneNumber:(int64_t)uuid SPhoneNumber:(NSString *)sPhoneNumber{
    CSUploadPhoneNumberBuilder *csUploadPhoneNumberBuilder = [CSUploadPhoneNumber builder];
    csUploadPhoneNumberBuilder.uuid = uuid;
    csUploadPhoneNumberBuilder.sPhoneNumber = sPhoneNumber;
    
    CSUploadPhoneNumber *csUploadPhoneNumber = [csUploadPhoneNumberBuilder build];
    NSData *tempData = [[TCPNetEngine getInstance] getUploadPhoneNumber:csUploadPhoneNumber];
    [[ListenToMeData getInstance].socketIns writeData:tempData withTimeout:100 tag:STATE_CMD_REQ_UPLOAD_PHONENUMBER_ICON];
}

#pragma mark - 上传需要验证的验证码
-(void)sendUploadVerifyCode:(int64_t)uuid SVerifyCode:(NSString *)sVerfyCode{
    CSUploadVerifyCodeBuilder *csUploadVerifyCodeBuilder = [CSUploadVerifyCode builder];
    csUploadVerifyCodeBuilder.uuid = uuid;
    csUploadVerifyCodeBuilder.sVerifyCode = sVerfyCode;
    
    CSUploadVerifyCode *csUploadVerifyCode = [csUploadVerifyCodeBuilder build];
    NSData *tempData = [[TCPNetEngine getInstance] getUploadVerifyCode:csUploadVerifyCode];
    [[ListenToMeData getInstance].socketIns writeData:tempData withTimeout:100 tag:STATE_CMD_REQ_UPLOAD_VERIFY_CODE_ICON];
}

#pragma mark - 删除纪念册
-(void)sendDeleteCommemorateInfo:(int64_t)uuid LCommemorateId:(int64_t)lCommemorateId{
    CSDeleteCommemorateInfoBuilder *csDeleteCommemorateInfoBuilder = [CSDeleteCommemorateInfo builder];
    csDeleteCommemorateInfoBuilder.uuid = uuid;
    csDeleteCommemorateInfoBuilder.lCommemorateId = lCommemorateId;
    
    CSDeleteCommemorateInfo *csDeleteCommemorateInfo = [csDeleteCommemorateInfoBuilder build];
    NSData *tempData = [[TCPNetEngine getInstance] getDeleteCommemorate:csDeleteCommemorateInfo];
    [[ListenToMeData getInstance].socketIns writeData:tempData withTimeout:100 tag:STATE_CMD_REQ_DELETE_COMMEMORATEINFO];
}

#pragma mark - 删除我的音乐作品
-(void)sendDeleteMyMusicWork:(int64_t)uuid LMusicid:(int64_t)lMusicid{
    CSDeleteMyMusicWorkBuilder *csDeleteMyMusicWorkBuilder = [CSDeleteMyMusicWork builder];
    csDeleteMyMusicWorkBuilder.uuid = uuid;
    csDeleteMyMusicWorkBuilder.lMusicid = lMusicid;
    
    CSDeleteMyMusicWork *csDeleteMyMusicWork = [csDeleteMyMusicWorkBuilder build];
    NSData *tempData = [[TCPNetEngine getInstance] getDeleteMyMusicWork:csDeleteMyMusicWork];
    [[ListenToMeData getInstance].socketIns writeData:tempData withTimeout:100 tag:STATE_CMD_REQ_DELETE_MYMUSICWORK];
}

#pragma mark - 根据id获取纪念册信息 被查看人的id 如果为空就是查看用户自己的纪念册  如果不为空就是用户查看别人纪念册
-(void)sendGetCommemorateInfoByUserId:(int64_t)uuid LWatchUserId:(int64_t)lWatchUserId IOffset:(int32_t)iOffset INum:(int32_t)iNum{
    CSGetCommemorateInfoByUserIdBuilder *csGetCommemorateInfoByUserIdBuilder = [CSGetCommemorateInfoByUserId builder];
    csGetCommemorateInfoByUserIdBuilder.uuid = uuid;
    csGetCommemorateInfoByUserIdBuilder.lWatchUserId = lWatchUserId;
    csGetCommemorateInfoByUserIdBuilder.iOffset = iOffset;
    csGetCommemorateInfoByUserIdBuilder.iNum = iNum;
    
    CSGetCommemorateInfoByUserId *csGetCommemorateInfoByUserId = [csGetCommemorateInfoByUserIdBuilder build];
    NSData *tempData = [[TCPNetEngine getInstance] getCommemorateInfoByUserId:csGetCommemorateInfoByUserId];
    [[ListenToMeData getInstance].socketIns writeData:tempData withTimeout:100 tag:STATE_CMD_REQ_GET_COMMEMORATEINFO_BYUSERID];
}

#pragma mark - 试听音乐作品
-(void)sendMusicAuditon:(int64_t)uuid LMusicWorkId:(int64_t)lMusicWorkId{
    CSMusicAuditionBuilder *csMusicAuditionBuilder = [CSMusicAudition builder];
    csMusicAuditionBuilder.uuid = uuid;
    csMusicAuditionBuilder.lMusicWorkId = lMusicWorkId;
    
    CSMusicAudition *csMusicAudition = [csMusicAuditionBuilder build];
    NSData *tempData = [[TCPNetEngine getInstance] getMusicAudition:csMusicAudition];
    [[ListenToMeData getInstance].socketIns writeData:tempData withTimeout:100 tag:STATE_CMD_REQ_MUSICAUDITION];
}

#pragma mark - 评论音乐作品
-(void)sendAddCommentMusic:(int64_t)uuid LMusicWorkId:(int64_t)lMusicWorkId SContent:(NSString *)sContent{
    CSAddCommentMusicBuilder *csAddCommentMusicBuilder = [CSAddCommentMusic builder];
    csAddCommentMusicBuilder.uuid = uuid;
    csAddCommentMusicBuilder.lMusicWorkId = lMusicWorkId;
    csAddCommentMusicBuilder.sContent = sContent;
    
    CSAddCommentMusic *csAddCommentMusic = [csAddCommentMusicBuilder build];
    NSData *tempData = [[TCPNetEngine getInstance] getAddCommentMusic:csAddCommentMusic];
    [[ListenToMeData getInstance].socketIns writeData:tempData withTimeout:100 tag:STATE_CMD_REQ_ADD_COMMENTMUSIC];
}

#pragma mark - 获取音乐作品评论信息
-(void)sendGetMusicCommentList:(int64_t)lMusicId IOffset:(int32_t)iOffset INum:(int32_t)iNum{
    CSGetMusicCommentListBuilder *csGetMusicCommentListBuilder = [CSGetMusicCommentList builder];
    csGetMusicCommentListBuilder.lMusicId = lMusicId;
    csGetMusicCommentListBuilder.iOffset = iOffset;
    csGetMusicCommentListBuilder.iNum = iNum;
    
    CSGetMusicCommentList *csGetMusicCommentList = [csGetMusicCommentListBuilder build];
    NSData *tempData = [[TCPNetEngine getInstance] getMusicCommentList:csGetMusicCommentList];
    [[ListenToMeData getInstance].socketIns writeData:tempData withTimeout:100 tag:STATE_CMD_REQ_GET_MUSIC_COMMENTLIST];
}

#pragma mark - 给音乐作品送鲜花
-(void)sendGetSendMusicFlower:(int64_t)uuid LMusicId:(int64_t)lMusicId IFlowerNum:(int32_t)iFlowerNum{
    CSSendMusicFlowerBuilder *csSendMusicFlowerBuilder = [CSSendMusicFlower builder];
    csSendMusicFlowerBuilder.uuid = uuid;
    csSendMusicFlowerBuilder.lMusicId = lMusicId;
    csSendMusicFlowerBuilder.iFlowerNum = iFlowerNum;
    
    CSSendMusicFlower *csSendMusicFlower = [csSendMusicFlowerBuilder build];
    
    NSData *tempData =  [[TCPNetEngine getInstance] getSendMusicFlower:csSendMusicFlower];
    [[ListenToMeData getInstance].socketIns writeData:tempData withTimeout:100 tag:STATE_CMD_REQ_SEND_MUSIC_FLOWER];
    
}

#pragma mark - 给人送鲜花
-(void)sendGetSendUserFlower:(int64_t)uuid LUserId:(int64_t)lUserId IFlowerNum:(int32_t)iFlowerNum{
    CSSendUserFlowerBuilder *csSendUserFlowerBuilder = [CSSendUserFlower builder];
    csSendUserFlowerBuilder.uuid = uuid;
    csSendUserFlowerBuilder.lUserId = lUserId;
    csSendUserFlowerBuilder.iFlowerNum = iFlowerNum;
    
    CSSendUserFlower *csSendUserFlower = [csSendUserFlowerBuilder build];
    NSData *tempData =[[TCPNetEngine getInstance] getSendUserFlower:csSendUserFlower];
    [[ListenToMeData getInstance].socketIns writeData:tempData withTimeout:100 tag:STATE_CMD_REQ_SEND_USER_FLOWER];
}

#pragma mark - 给纪念册送花
-(void)sendGetSEndCommemorateFlower:(int64_t)uuid LCommid:(int64_t)lCommid IFlowerNum:(int32_t)iFlowerNum{
    CSSendCommemorateFlowerBuilder *csSendCommemorateFlowerBuilder = [CSSendCommemorateFlower builder];
    csSendCommemorateFlowerBuilder.uuid = uuid;
    csSendCommemorateFlowerBuilder.lCommId = lCommid;
    csSendCommemorateFlowerBuilder.iFlowerNum = iFlowerNum;
    
    CSSendCommemorateFlower *csSendCommemorateFlower = [csSendCommemorateFlowerBuilder build];
    NSData *tempData =[[TCPNetEngine getInstance] getSendCommemotateFlower:csSendCommemorateFlower];
    [[ListenToMeData getInstance].socketIns writeData:tempData withTimeout:100 tag:STATE_CMD_REQ_SEND_COMMEMORATE_FLOWER];
}

#pragma mark - 要删除的礼券
-(void)sendDeleteUserCouponList:(int64_t)uuid LCouponId:(int64_t)lCouponId{
    CSDeleteUserCouponListBuilder *csDeleteUserCouponListBuilder = [CSDeleteUserCouponList builder];
    csDeleteUserCouponListBuilder.uuid = uuid;
    csDeleteUserCouponListBuilder.lCouponId = lCouponId;
    
    CSDeleteUserCouponList *csDeleteUserCouponList = [csDeleteUserCouponListBuilder build];
    NSData *tempData = [[TCPNetEngine getInstance] getDeleteUserCouponList:csDeleteUserCouponList];
    [[ListenToMeData getInstance].socketIns writeData:tempData withTimeout:100 tag:STATE_CMD_REQ_DELETE_USERCOUPONLIST];
}
#pragma mark - 设置用户小黑屋状态
-(void)sendSetBlackRoomState:(int64_t)uuid LToUserid:(int64_t)lToUserid BMute:(int32_t)bMute{
    CSSetBlackRoomStateBuilder *csSetBlackRoomStateBuilder =[CSSetBlackRoomState builder];
    csSetBlackRoomStateBuilder.uuid = uuid;
    csSetBlackRoomStateBuilder.lToUserid = lToUserid;
    csSetBlackRoomStateBuilder.bMute = bMute;
    
    CSSetBlackRoomState *csSetBlackRoomState = [csSetBlackRoomStateBuilder build];
    NSData *tempData = [[TCPNetEngine getInstance] getSetBlackRoomState:csSetBlackRoomState];
    [[ListenToMeData getInstance].socketIns writeData:tempData withTimeout:100 tag:STATE_CMD_REQ_SET_BLACKROOMSTATE];
}

#pragma mark - 查看用户的小黑屋状态
-(void)sendGetBlackRoomState:(int64_t)uuid LToUserId:(int64_t)lToUserId{
    CSGetBlackRoomStateBuilder *csGetBlackRoomStateBuilder =[CSGetBlackRoomState builder];
    csGetBlackRoomStateBuilder.uuid = uuid;
    csGetBlackRoomStateBuilder.lToUserId = lToUserId;
    
    CSGetBlackRoomState *csGetBlackRoomState =[csGetBlackRoomStateBuilder build];
    NSData *tempData = [[TCPNetEngine getInstance]getBlackRoomState:csGetBlackRoomState];
    [[ListenToMeData getInstance].socketIns writeData:tempData withTimeout:100 tag:STATE_CMD_REQ_GET_BLACKROOMSTATE];
}
#pragma mark - 给好友赠送礼券
-(void)sendCouponToFriend:(int64_t)uuid LToUserId:(int64_t)lToUserId LCouponId:(NSArray *)lCouponId{
    CSSendCouponToFriendBuilder *csSendCouponToFriendBuilder = [CSSendCouponToFriend builder];
    csSendCouponToFriendBuilder.uuid = uuid;
    csSendCouponToFriendBuilder.lToUserId = lToUserId;
#warning CSSendCouponToFriendBuilder的lCouponId是repeated 是一个数组
//    [csSendCouponToFriendBuilder setLCouponIdArray:lCouponId];
    [csSendCouponToFriendBuilder setLCouponIdArray:lCouponId];;
    
    
    CSSendCouponToFriend *csSendCouponToFriend = [csSendCouponToFriendBuilder build];
    NSData *tempData  =[[TCPNetEngine getInstance]getSendCouponToFriend:csSendCouponToFriend];
    [[ListenToMeData getInstance].socketIns writeData:tempData withTimeout:100 tag:STATE_CMD_REQ_SEND_COUPON_TO_FRIEND];
    
}
#pragma mark - 获取相同类型的礼券数量
-(void)sendGetTypeAllNum:(int64_t)uuid SCouponType:(NSString *)sCouponType SCouponAdress:(NSString *)sCouponAdress LEndTime:(int64_t)lEndTime{
    CSGetTypeAllNumBuilder *csGetTypeAllNumBuilder =[CSGetTypeAllNum builder];
    csGetTypeAllNumBuilder.uuid = uuid;
    csGetTypeAllNumBuilder.sCouponType = sCouponType;
    csGetTypeAllNumBuilder.sCouponAdress = sCouponAdress;
    csGetTypeAllNumBuilder.lEndTime = lEndTime;
    
    CSGetTypeAllNum *csGetTypeAllNum = [csGetTypeAllNumBuilder build];
    NSData *tempData  = [[TCPNetEngine getInstance] getTypeAllNum:csGetTypeAllNum];
    [[ListenToMeData getInstance].socketIns writeData:tempData withTimeout:100 tag:STATE_CMD_REQ_GET_TYPEALLNUM];
}

#pragma makr - 发送消息
-(void)sendMsg:(int64_t)uuid LTalkWith:(int64_t)lTalkWith SMsg:(NSString *)sMsg LMsgId:(int64_t)lMsgId EMessageType:(MESSAGE_TYPE)eMessgeType{
    CSSendMsgBuilder *csSendMsgBuilder = [CSSendMsg builder];
    csSendMsgBuilder.uuid = uuid;
    csSendMsgBuilder.lTalkwith = lTalkWith;
    csSendMsgBuilder.sMsg = sMsg;
    csSendMsgBuilder.lMsgId = lMsgId;
    csSendMsgBuilder.eMessageType = eMessgeType;
    
    CSSendMsg *csSendMsg =[csSendMsgBuilder build];
    NSData *tempData = [[TCPNetEngine getInstance] sendMsg:csSendMsg];
    [[ListenToMeData getInstance].socketIns writeData:tempData withTimeout:100 tag:STATE_CMD_REQ_SEND_MESSAGE];
}

#pragma mark - 获取ktv店内活信息
-(void)sendGetKtvAcitviytList:(int64_t)uuid LKtvId:(int64_t)lKtvId IOffset:(int32_t)iOffset INum:(int32_t)iNum{
    CSGetKtvActivityListBuilder *csGetKtvActivityBuilder =[CSGetKtvActivityList builder];
    csGetKtvActivityBuilder.uuid = uuid;
    csGetKtvActivityBuilder.lKtvId = lKtvId;
    csGetKtvActivityBuilder.iOffset = iOffset;
    csGetKtvActivityBuilder.iNum = iNum;
    
    CSGetKtvActivityList *csGetKtvActivityList = [csGetKtvActivityBuilder build];
    NSData *tempData = [[TCPNetEngine getInstance] getKtvActivityList:csGetKtvActivityList];
    [[ListenToMeData getInstance].socketIns writeData:tempData withTimeout:100 tag:STATE_CMD_REQ_GET_KTVACTIVIYTLIST];
}

#pragma mark - 获取纪念册评论列表
-(void)sendGetCommemorateCommentListByLCommemorateId:(int64_t)lCommemorateId IOffset:(int32_t)iOffset INum:(int32_t)iNum{
    CSGetCommemorateCommentListBuilder *csGetCommemorateCommentListBuilder = [CSGetCommemorateCommentList builder];
    csGetCommemorateCommentListBuilder.lCommemorateId = lCommemorateId;
    csGetCommemorateCommentListBuilder.iOffset = iOffset;
    csGetCommemorateCommentListBuilder.iNum = iNum;
    
    CSGetCommemorateCommentList *csGetCommemorateCommentList = [csGetCommemorateCommentListBuilder build];
    NSData *tempData = [[TCPNetEngine getInstance] getCommemorateCommentList:csGetCommemorateCommentList];
    [[ListenToMeData getInstance].socketIns writeData:tempData withTimeout:100 tag:STATE_CMD_REQ_GET_COMMEMORATE_COMMENTLIST];
    
}


#pragma mark - 评论纪念册列表
-(void)sendAddCommentCommemorateWithUserId:(int64_t)uuid LCommemorateId:(int64_t)lCommemorateId SContent:(NSString *)sContent{
    
    CSAddCommentCommemorateBuilder *csAddCommentCommemorateBuilder = [CSAddCommentCommemorate builder];
    csAddCommentCommemorateBuilder.uuid = uuid;
    csAddCommentCommemorateBuilder.lCommemorateId = lCommemorateId;
    csAddCommentCommemorateBuilder.sContent = sContent;
    
    CSAddCommentCommemorate *csAddCommentCommemorate = [csAddCommentCommemorateBuilder build];
    NSData *tempData = [[TCPNetEngine getInstance] getAddCommentCommemorate:csAddCommentCommemorate];
    [[ListenToMeData getInstance].socketIns writeData:tempData withTimeout:100 tag:STATE_CMD_REQ_ADD_COMMENT_COMMEMORATE];
}

@end
