//
//  YDKTVView.m
//  ListenToMe
//
//  Created by yadong on 2/9/15.
//  Copyright (c) 2015 listentome. All rights reserved.
//

#import "YDKTVView.h"
#import "EScrollerView.h"
#import "YDSquareCell.h"
@interface YDKTVView ()

@end

@implementation YDKTVView
-(instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        self.backgroundColor = [UIColor clearColor];
        
//        [self setUpKtvScrollBar];
//        
//        [self setUpKtvTableView];
//        

        
    }
    return self;
}


#pragma mark 搜索栏
//-(void)setSearchBar
//{
//    _searchKtv = [[UISearchBar alloc]initWithFrame:CGRectMake(0, 0, screenWidth, 40)];
//    [self addSubview:_searchKtv];
//    
//    _searchKtv.placeholder = @"搜索KTV...";
//}

#pragma mark banner
//-(void)setBanner
//{
//    // 初始化滚动条
//    _scrollBanner = [[UIScrollView alloc]initWithFrame:CGRectMake(0, _searchKtv.height, screenWidth, 100)];
//    _scrollBanner.backgroundColor = [UIColor clearColor];
//    [self addSubview:_scrollBanner];
//}

@end
