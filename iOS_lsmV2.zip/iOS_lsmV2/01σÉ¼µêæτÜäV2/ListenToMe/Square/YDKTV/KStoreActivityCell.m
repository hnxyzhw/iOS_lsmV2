//
//  KStoreActivityCell.m
//  ListenToMe
//
//  Created by zhw on 15/7/9.
//  Copyright (c) 2015年 listentome. All rights reserved.
//

#import "KStoreActivityCell.h"
#import "NSString+Extension.h"
@interface KStoreActivityCell ()
/**
 *  活动内容和配图
 */
@property(nonatomic,strong) UIView *activityImgAndContentView;
/**
 *  第一张活动图片
 */
@property(nonatomic,strong) UIImageView *imgFiActivityPic;
/**
 *  第一条活动内容
 */
@property(nonatomic,strong) UILabel *lbFiContent;
/**
 *  第二张活动图片
 */
@property(nonatomic,strong) UIImageView *imgSeActivityPic;
/**
 *  第二条活动内容
 */
@property(nonatomic,strong) UILabel *lbSeContent;
/**
 *  第三张活动图片
 */
@property(nonatomic,strong) UIImageView *imgThActivityPic;
/**
 *  第三条活动内容
 */
@property(nonatomic,strong) UILabel *lbThContent;
/**
 *  活动地点
 */
@property(nonatomic,strong) UILabel *lbActivityAddress;
/**
 *  活动时间
 */
@property(nonatomic,strong) UILabel *lbActivityTime;
/**
 *  活动主题
 */
@property(nonatomic,strong) UILabel *lbActivityTheme;
/**
 *  活动KTV店
 */
@property(nonatomic,strong) UILabel *lbActivityKTV;
/**
 *  该活动包房人数限制
 */
@property(nonatomic,strong) UILabel *lbKTVRoomPerNum;
/**
 *  该活动结账方式
 */
@property(nonatomic,strong) UILabel *lbActivityPayWay;
/**
 *  该活动人均费用估算
 */
@property(nonatomic,strong) UILabel *lbActiviytPerPay;
/**
 *  该活动费用包括
 */
@property(nonatomic,strong) UILabel *lbActivityCost;
/**
 *  分享
 */
@property(nonatomic,strong) UIButton *btnShareActivity;
@end


@implementation KStoreActivityCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

+(instancetype)cellWithTableView:(UITableView *)tableView{
    
    NSString *identifier = @"KStoreActivityCell";
    KStoreActivityCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil) {
        cell = [[KStoreActivityCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    
    return cell;
}

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self setUI];
        self.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    
    return self;
}


-(void)setUI{
    
    CGFloat verticalInterVal = 5; //控件上下的间隔
    CGFloat horizontalInterVal = 15; //控件左右间隔
    
    //
    CGFloat fPic_X = horizontalInterVal;
    CGFloat fPic_Y = horizontalInterVal;
    CGFloat fPic_W = screenWidth - 30;
    CGFloat fPic_H = 75;
    
//    UIImage *tempActivityImg = [UIImage imageNamed:@"album.png"];
    _imgFiActivityPic = [[UIImageView alloc]initWithFrame:CGRectMake(fPic_X, fPic_Y, fPic_W, fPic_H)];
//    _imgFiActivityPic.image = tempActivityImg;
//    [self.contentView addSubview:_imgFiActivityPic];
    
    CGFloat fContent_X = horizontalInterVal;
    CGFloat fContent_Y = _imgFiActivityPic.y + _imgFiActivityPic.height + 5;
    CGFloat fContent_W = screenWidth - 30;
    CGFloat fContent_H = 23; //临时高度
    
    _lbFiContent = [[UILabel alloc]initWithFrame:CGRectMake(fContent_X, fContent_Y, fContent_W, fContent_H)];
    _lbFiContent.text = @"1斯蒂芬森东方时尚东方时代发送的发送的发送的发送的佛挡杀佛SD发送的放松放松电风扇";
    _lbFiContent.textColor = [UIColor blackColor];
    _lbFiContent.textAlignment = NSTextAlignmentLeft;
    _lbFiContent.font = [UIFont systemFontOfSize:12.0];
    _lbFiContent.numberOfLines = 0;
//    [self.contentView addSubview:_lbFiContent];
    
    _imgSeActivityPic = [[UIImageView alloc]initWithFrame:CGRectMake(horizontalInterVal, _lbFiContent.y + _lbFiContent.height + verticalInterVal, fPic_W, fPic_H)];
//    _imgSeActivityPic.image = tempActivityImg;
    [self.contentView addSubview:_imgSeActivityPic];
    
    _lbSeContent = [[UILabel alloc]initWithFrame:CGRectMake(horizontalInterVal, _imgSeActivityPic.y + _imgSeActivityPic.height + verticalInterVal, fContent_W, fContent_H)];
    _lbSeContent.text = @"2斯蒂芬森东方时尚东方时代发送的发送的发送的发送的佛挡杀佛SD发送的放松放松电风扇";
    _lbSeContent.textColor = [UIColor blackColor];
    _lbSeContent.textAlignment = NSTextAlignmentLeft;
    _lbSeContent.font = [UIFont systemFontOfSize:12.0];
    _lbSeContent.numberOfLines = 0;
//    [self.contentView addSubview:_lbSeContent];
    
    
    _imgThActivityPic = [[UIImageView alloc]initWithFrame:CGRectMake(horizontalInterVal, _lbSeContent.y + _lbSeContent.height + verticalInterVal, fPic_W, fPic_H)];
//    _imgThActivityPic.image = tempActivityImg;
    [self.contentView addSubview:_imgThActivityPic];
    
    _lbThContent = [[UILabel alloc]initWithFrame:CGRectMake(horizontalInterVal, _imgThActivityPic.y + _imgThActivityPic.height + verticalInterVal, fContent_W, fContent_H)];
    _lbThContent.text = @"3斯蒂芬森东方时尚东方时代发送的发送的发送的发送的佛挡杀佛SD发送的放松放松电风扇";
    _lbThContent.textColor = [UIColor blackColor];
    _lbThContent.textAlignment = NSTextAlignmentLeft;
    _lbThContent.font = [UIFont systemFontOfSize:12.0];
    _lbThContent.numberOfLines = 0;
//    [self.contentView addSubview:_lbThContent];
    
    _lbActivityAddress = [[UILabel alloc]initWithFrame:CGRectMake(horizontalInterVal, _lbThContent.y + _lbThContent.height + verticalInterVal, fContent_W, 20)];
    _lbActivityAddress.text = @"地点:北京鸟巢";
    _lbActivityAddress.textColor = [UIColor blackColor];
    _lbActivityAddress.textAlignment = NSTextAlignmentLeft;
    _lbActivityAddress.font = [UIFont systemFontOfSize:12.0];
    _lbActivityAddress.numberOfLines = 0;
    [self.contentView addSubview:_lbActivityAddress];
    
    
    _lbActivityTime = [[UILabel alloc]initWithFrame:CGRectMake(horizontalInterVal, _lbActivityAddress.y + _lbActivityAddress.height + verticalInterVal, fContent_W, 20)];
    _lbActivityTime.text = @"时间:2015- 12- 2";
    _lbActivityTime.textColor = [UIColor blackColor];
    _lbActivityTime.textAlignment = NSTextAlignmentLeft;
    _lbActivityTime.font = [UIFont systemFontOfSize:12.0];
    _lbActivityTime.numberOfLines = 0;
    [self.contentView addSubview:_lbActivityTime];
    
    
    //活动主题
    
    _lbActivityTheme = [[UILabel alloc]initWithFrame:CGRectMake(horizontalInterVal, _lbActivityTime.y + _lbActivityTime.height + 10 + verticalInterVal, fContent_W, 20)];
    _lbActivityTheme.text = @"KTV歌友会直播互动活动";
    _lbActivityTheme.textColor = [UIColor blackColor];
    _lbActivityTheme.textAlignment = NSTextAlignmentLeft;
    _lbActivityTheme.font = [UIFont systemFontOfSize:12.0];
    _lbActivityTheme.numberOfLines = 0;
    [self.contentView addSubview:_lbActivityTheme];
    
    //活动KTV店
    UILabel *lbKtvTitle = [[UILabel alloc]initWithFrame:CGRectMake(horizontalInterVal, _lbActivityTheme.y + _lbActivityTheme.height + verticalInterVal, fContent_W, 20)];
    lbKtvTitle.text = @"活动KTV店:";
    lbKtvTitle.textAlignment = NSTextAlignmentLeft;
    lbKtvTitle.textColor = [UIColor blackColor];
    lbKtvTitle.font = [UIFont systemFontOfSize:12.0];
//    [self.contentView addSubview:lbKtvTitle];
    
    
    _lbActivityKTV = [[UILabel alloc]initWithFrame:CGRectMake(horizontalInterVal, lbKtvTitle.y + lbKtvTitle.height  + verticalInterVal, fContent_W, 20)];
    _lbActivityKTV.text = @"同一首歌苏州桥店";
    _lbActivityKTV.textColor = [UIColor blackColor];
    _lbActivityKTV.textAlignment = NSTextAlignmentLeft;
    _lbActivityKTV.font = [UIFont systemFontOfSize:12.0];
    _lbActivityKTV.numberOfLines = 0;
    [self.contentView addSubview:_lbActivityKTV];
    
    //人数限制
    _lbKTVRoomPerNum = [[UILabel alloc]initWithFrame:CGRectMake(horizontalInterVal, _lbActivityKTV.y + _lbActivityKTV.height  + verticalInterVal, fContent_W, 20)];
    _lbKTVRoomPerNum.text = @"每个包房人数限制 : 5人";
    _lbKTVRoomPerNum.textColor = [UIColor blackColor];
    _lbKTVRoomPerNum.textAlignment = NSTextAlignmentLeft;
    _lbKTVRoomPerNum.font = [UIFont systemFontOfSize:12.0];
    _lbKTVRoomPerNum.numberOfLines = 0;
    [self.contentView addSubview:_lbKTVRoomPerNum];
    
    //结账方式
    _lbActivityPayWay = [[UILabel alloc]initWithFrame:CGRectMake(horizontalInterVal, _lbKTVRoomPerNum.y + _lbKTVRoomPerNum.height  + verticalInterVal, fContent_W, 20)];
    _lbActivityPayWay.text = @"结账方式: 免费";
    _lbActivityPayWay.textColor = [UIColor blackColor];
    _lbActivityPayWay.textAlignment = NSTextAlignmentLeft;
    _lbActivityPayWay.font = [UIFont systemFontOfSize:12.0];
    _lbActivityPayWay.numberOfLines = 0;
    [self.contentView addSubview:_lbActivityPayWay];
    
    //人均费用预估
    _lbActiviytPerPay = [[UILabel alloc]initWithFrame:CGRectMake(horizontalInterVal, _lbActivityPayWay.y + _lbActivityPayWay.height  + verticalInterVal, fContent_W, 20)];
    _lbActiviytPerPay.text = @"人均费用预估: 80元";
    _lbActiviytPerPay.textColor = [UIColor blackColor];
    _lbActiviytPerPay.textAlignment = NSTextAlignmentLeft;
    _lbActiviytPerPay.font = [UIFont systemFontOfSize:12.0];
    _lbActiviytPerPay.numberOfLines = 0;
    [self.contentView addSubview:_lbActiviytPerPay];
    
    //费用包括
    
    _lbActivityCost = [[UILabel alloc]initWithFrame:CGRectMake(horizontalInterVal, _lbActiviytPerPay.y + _lbActiviytPerPay.height  + verticalInterVal, fContent_W, 20)];
    _lbActivityCost.text = @"费用包括: 3小时欢唱,一份晚餐,2听可乐,果盘一份";
    _lbActivityCost.textColor = [UIColor blackColor];
    _lbActivityCost.textAlignment = NSTextAlignmentLeft;
    _lbActivityCost.font = [UIFont systemFontOfSize:12.0];
    _lbActivityCost.numberOfLines = 0;
    [self.contentView addSubview:_lbActivityCost];
    
    //分享
    
    _btnShareActivity = [[UIButton alloc]initWithFrame:CGRectMake(15, _lbActivityCost.y + _lbActivityCost.height + 20, screenWidth - 30, 40)];
    
    [_btnShareActivity setImage:[UIImage imageNamed:@"UpLoadPhotoBgImg.png"] forState:UIControlStateNormal];
    [_btnShareActivity setImage:[UIImage imageNamed:@"UpLoadPhotoBgImg.png"] forState:UIControlStateHighlighted];
    [_btnShareActivity setTitle:@"分享" forState:UIControlStateNormal];
    _btnShareActivity.titleLabel.font = [UIFont systemFontOfSize:15.0];
    [_btnShareActivity setTitleShadowColor:[UIColor redColor] forState:UIControlStateNormal];
    [_btnShareActivity setTitleEdgeInsets:UIEdgeInsetsMake(0, -( _btnShareActivity.width  * 1.25), 0, 0)];
    [_btnShareActivity setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    _btnShareActivity.layer.masksToBounds = YES;
    _btnShareActivity.layer.cornerRadius = 5;
    
    [self.contentView addSubview:_btnShareActivity];
    
    
}

-(void)setKtvActivityInfo:(KtvActivityInfo *)ktvActivityInfo{
    
    if (ktvActivityInfo) {
        _ktvActivityInfo = ktvActivityInfo;
        
        NSMutableArray *arrKtvActivityInfo = [NSMutableArray arrayWithArray:ktvActivityInfo.stActivityDetail];
        
        for (int index = 0; index < arrKtvActivityInfo.count; index ++) {
            KtvActivityDetailInfo *activityDeatil = arrKtvActivityInfo[index];
            
            _activityImgAndContentView = [[UIView alloc]init];
            
            UIImageView *imgActivity = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, screenWidth - 30, 75)];
            [imgActivity sd_setImageWithURL:[NSURL URLWithString:((KtvActivityDetailInfo *)arrKtvActivityInfo[0]).imgUrl] placeholderImage:[UIImage imageNamed:@"temp5.png"]];
            UILabel *lbContent = [[UILabel alloc]initWithFrame:CGRectMake(0, imgActivity.height + 5, imgActivity.width, 20)];
            lbContent.textColor = [UIColor blackColor];
            lbContent.textAlignment = NSTextAlignmentLeft;
            lbContent.font = [UIFont systemFontOfSize:12.0];
            lbContent.numberOfLines = 0;
            lbContent.lineBreakMode = NSLineBreakByCharWrapping;
            lbContent.text =activityDeatil.content;
            
            CGSize contentSize = [lbContent.text sizeWithFont:lbContent.font maxSize:CGSizeMake(lbContent.width, MAXFLOAT)];
            lbContent.frame = CGRectMake(lbContent.x, lbContent.y, lbContent.width, contentSize.height);
            
            CGFloat imgAndContentHeitht = (imgActivity.height + 5 + lbContent.height + 5) * (index + 1) ;
            _activityImgAndContentView.frame = CGRectMake(15, 15 + imgAndContentHeitht * index, screenWidth - 30, imgAndContentHeitht);
            
            [_activityImgAndContentView addSubview:imgActivity];
            [_activityImgAndContentView addSubview:lbContent];
            
            [self.contentView addSubview:_activityImgAndContentView];
            
            
        }
        
        CGSize lbMaxSize = CGSizeMake(screenWidth - 30, MAXFLOAT);
        CGFloat lb_X = 15;
        CGFloat lb_W = screenWidth - 30;
        
        
        CGFloat lbAddress_H = [[NSString stringWithFormat:@"地点: 沈阳站-XXXX场馆"] sizeWithFont:_lbActivityAddress.font maxSize:lbMaxSize].height;
        _lbActivityAddress.text = [NSString stringWithFormat:@"地点: 沈阳站-XXXX场馆"] ;
        _lbActivityAddress.frame = CGRectMake(lb_X, _activityImgAndContentView.y + _activityImgAndContentView.height + 5, lb_W, lbAddress_H);
        
        CGFloat lbTime_H =[[NSString stringWithFormat:@"时间: %lld",ktvActivityInfo.createTime] sizeWithFont:_lbActivityTime.font maxSize:lbMaxSize].height;
        _lbActivityTime.frame = CGRectMake(lb_X, _lbActivityAddress.y + _lbActivityAddress.height + 5, lb_W, lbTime_H);
        _lbActivityTime.text = [NSString stringWithFormat:@"时间: %lld",ktvActivityInfo.createTime] ;
        
        //分割线
        UIImageView *separateLing01 = [[UIImageView alloc]initWithFrame:CGRectMake(0, _lbActivityTime.y + _lbActivityTime.height + 10, screenWidth, 1)];
        separateLing01.backgroundColor =[UIColor lightGrayColor];
        [self.contentView addSubview:separateLing01];
        
        
        CGFloat lbTheme_H = [ktvActivityInfo.theme sizeWithFont:_lbActivityTheme.font maxSize:lbMaxSize].height;
        _lbActivityTheme.frame = CGRectMake(lb_X,_lbActivityTime.y + _lbActivityTime.height + 15 , lb_W, lbTheme_H);
        _lbActivityTheme.text = ktvActivityInfo.theme;
        
        
        
        
        
        
    }
    
}

-(void)setKtvBaseInfo:(KtvBaseInfo *)ktvBaseInfo{
    if (ktvBaseInfo) {
        _ktvBaseInfo = ktvBaseInfo;
        
        CGSize lbMaxSize = CGSizeMake(screenWidth - 30, MAXFLOAT);
        CGFloat lb_X = 15;
        CGFloat lb_W = screenWidth - 30;
        //活动KTV店
        UILabel *lbKtvTitle = [[UILabel alloc]initWithFrame:CGRectMake(lb_X, _lbActivityTheme.y + _lbActivityTheme.height + 5, lb_W, 20)];
        lbKtvTitle.text = @"活动KTV店:";
        lbKtvTitle.textAlignment = NSTextAlignmentLeft;
        lbKtvTitle.textColor = [UIColor blackColor];
        lbKtvTitle.font = [UIFont systemFontOfSize:12.0];
        [self.contentView addSubview:lbKtvTitle];
        
        CGFloat lbKTVName_H = [ktvBaseInfo.vStoreName sizeWithFont:_lbActivityKTV.font maxSize:lbMaxSize].height;
        _lbActivityKTV.frame = CGRectMake(lb_X, lbKtvTitle.y + lbKtvTitle.height + 5, lb_W, lbKTVName_H);
        _lbActivityKTV.text = ktvBaseInfo.vStoreName;
        
        CGFloat lbRoomPerNum_H  = [_lbKTVRoomPerNum.text sizeWithFont:_lbKTVRoomPerNum.font maxSize:lbMaxSize].height;
        _lbKTVRoomPerNum.frame = CGRectMake(lb_X, _lbActivityKTV.y + _lbActivityKTV.height + 5, lb_W, lbRoomPerNum_H);
        
        CGFloat lbPayWay_H = [_lbActivityPayWay.text sizeWithFont:_lbActivityPayWay.font maxSize:lbMaxSize].height;
        _lbActivityPayWay.frame = CGRectMake(lb_X, _lbKTVRoomPerNum.y + _lbKTVRoomPerNum.height + 5, lb_W, lbPayWay_H);
        
        CGFloat lbPerPay_H = [_lbActiviytPerPay.text sizeWithFont:_lbActiviytPerPay.font maxSize:lbMaxSize].height;
        _lbActiviytPerPay.frame = CGRectMake(lb_X, _lbActivityPayWay.y + _lbActivityPayWay.height + 5, lb_W, lbPerPay_H);
        
        CGFloat lbCost_H = [_lbActivityCost.text sizeWithFont:_lbActivityCost.font maxSize:lbMaxSize].height;
        _lbActivityCost.frame = CGRectMake(lb_X, _lbActiviytPerPay.y + _lbActiviytPerPay.height + 5, lb_W, lbCost_H);
        
        _btnShareActivity.frame = CGRectMake(lb_X, _lbActivityCost.y + _lbActivityCost.height + 20, lb_W, 40);
        
        NSLog(@"cell height is ----%f----",_btnShareActivity.y + _btnShareActivity.height + 5);
        
    }
}

@end
