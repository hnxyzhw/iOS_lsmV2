//
//  HWKTVTrendsVC.m
//  ListenToMe
//
//  Created by zhw on 15/3/30.
//  Copyright (c) 2015年 listentome. All rights reserved.
//

#import "HWKTVTrendsVC.h"
#import "HWKTVInformationCell.h"
#import "HWKTVOnGoingCell.h"
#import "HWKTVHotSongCell.h"
#import "HWKTVChatRecordCell.h"
#import "YDRoomMsgCell.h"
#import "MoreNavigationMenView.h"
#import "HMPopMenu.h"
#import "HWPerHomePageVC.h"
#import "YDLaunchPartyVC.h"
#import "FriendsMsgVC.h"
//#import <MediaPlayer/MPNowPlayingInfoCenter.h>
#import <MediaPlayer/MediaPlayer.h>
#import "KStoreMemoryVC.h"
#import "LoadDataView.h"
#import "KStoreActivityVC.h"

@interface HWKTVTrendsVC ()<UITableViewDataSource,UITableViewDelegate,HWKTVOnGoingCellDelegate,HWKTVHotSongCellDelegate,STKAudioPlayerDelegate>
{
    STKAudioPlayer *audioPlayer;
    KStoreMemoryVC *kStoreMemoryVC;
}
@property(strong,nonatomic)UITableView *mTableView;
/**
 *  数据加载过渡动画
 */
@property(nonatomic,strong) LoadDataView *loadDataView;
/**
 *  跟多导航菜单
 */
@property(strong,nonatomic)MoreNavigationMenView *moreMenuView;

@property(nonatomic,strong) ListenToMeData *listenToMeData;
/**
 *  正在KTV中的用户
 */
@property(nonatomic,strong) NSArray *arrKtvUserList;
/**
 *  更换一批
 */
@property(nonatomic,assign) NSInteger countForKtvUserList;
/**
 *  KTV热歌
 */
@property(nonatomic,strong) NSArray *arrKtvHotSongList;
/**
 *  向右侧滑手势
 */
@property(nonatomic,strong) UISwipeGestureRecognizer *rightSwipeGestureRecognizer;

@end

@implementation HWKTVTrendsVC
@synthesize countForKtvUserList;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    //自定义顶部导航栏
    [self customizedBarItem];
    
    //添加一个向右的侧滑的手势
    [self addRightSwipeGestures];
    
    [self setUI];
    
    //数据加载过渡动画
    [self setLoaddataGif];
    
    self.listenToMeData = [ListenToMeData getInstance];
    
    if (!audioPlayer) {
        audioPlayer = self.listenToMeData.audioPlayer;
        //设置代理,监听播放的状态,通过播放器状态来切歌
        audioPlayer.delegate = self;

    }
    
    //获取KTV的相关信息
     [[NetReqManager getInstance] sendGetKtvInfoById:self.ktvBaseInfo.lKtvId];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshData) name:NOTIFY_GET_KTVINFO_PAGE_RESP object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshKtvUserList) name:NOTIFY_GET_SWITCHKTVUSERLIST_PAGE_RESP object:nil];
    //在线试听音乐回包的通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshHotSongList) name:NOTIFY_GET_MUSIC_AUDITION_PAGE_RESP object:nil];
}

#pragma mark - setLoaddataGif
-(void)setLoaddataGif{
    if (!self.loadDataView) {
        CGRect loadDataFrame = CGRectMake(0, naviAndStatusH, screenWidth, screenHeight - naviAndStatusH);
        self.loadDataView =[[LoadDataView alloc]initWithFrame:loadDataFrame];
    }
    
    //    [[[UIApplication sharedApplication]keyWindow] addSubview:self.loadDataView];
    [self.view addSubview:self.loadDataView];
}

//动画消失
-(void)dismissLoadDataView{
    [self.loadDataView removeFromSuperview];
}


-(void)refreshData{
    self.arrKtvUserList = self.listenToMeData.ktvBaseInfo.stUserBaseInfoNet;
    self.arrKtvHotSongList = self.listenToMeData.ktvBaseInfo.stMyMusicWorkInfo;
    
    [self.mTableView reloadData];
    [self dismissLoadDataView];
}
-(void)refreshKtvUserList{
    if (self.arrKtvUserList) {
        self.arrKtvUserList = nil;
    }
    self.arrKtvUserList = self.listenToMeData.arrUserBaseInfoNet;
    [self.mTableView reloadData];
}

-(void)refreshHotSongList{
    [self.mTableView reloadData];
}

-(void)dealloc{
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:NOTIFY_GET_KTVINFO_PAGE_RESP object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:NOTIFY_GET_SWITCHKTVUSERLIST_PAGE_RESP object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:NOTIFY_GET_MUSIC_AUDITION_PAGE_RESP object:nil];
    
    for (UIView *view in self.view.subviews) {
        [view removeFromSuperview];
    }
    self.ktvBaseInfo = nil;
    self.arrKtvHotSongList = nil;
    self.arrKtvUserList = nil;
    audioPlayer = nil;
}



-(void)viewWillAppear:(BOOL)animated{

    [super viewWillAppear:animated];
    [self.mTableView reloadData];
    
    //远程控制时间接收与处理
    [[UIApplication sharedApplication] beginReceivingRemoteControlEvents];
    [self becomeFirstResponder];
}
-(void)viewDidDisappear:(BOOL)animated{
    [super viewWillDisappear:YES];
    
    [[UIApplication sharedApplication] endReceivingRemoteControlEvents];
    [self resignFirstResponder];
}

#pragma mark -customNavigationBar
-(void)customizedBarItem{

    [self setLeftBtnItem];
    [self setRightBtnItem];
    

}
#pragma mark - 设置左边的BarItem
-(void)setLeftBtnItem{

    UIButton *customButton = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, 100, 41)];
    customButton.backgroundColor = [UIColor clearColor];
    [customButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    customButton.titleLabel.font = [UIFont systemFontOfSize:16.5];
    customButton.titleLabel.textAlignment = NSTextAlignmentCenter;
    [customButton setTitle:@"K店动态" forState:UIControlStateNormal];
    self.navigationItem.titleView = customButton;
    
    UIButton *leftBtn = [[UIButton alloc]init];
    UIImage *leftBtnImg = [UIImage imageNamed:@"whiteBack.png"];
    leftBtn.frame = CGRectMake(0, 0, leftBtnImg.size.width, leftBtnImg.size.height);
    [leftBtn setImage:leftBtnImg forState:UIControlStateNormal];
    [leftBtn addTarget:self action:@selector(clickLeftBarBtnItem:) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *customLeftBtnItem = [[UIBarButtonItem alloc]initWithCustomView:leftBtn];
    self.navigationItem.leftBarButtonItem = customLeftBtnItem;
}

#pragma mark - 设置右边的BarItem
-(void)setRightBtnItem{

    UIButton *rightBtn = [[UIButton alloc]init];
    UIImage *imgMore = [UIImage imageNamed:@"more.png"];
    rightBtn.frame = CGRectMake(0, 0, imgMore.size.width, imgMore.size.height);
    [rightBtn setImage:imgMore forState:UIControlStateNormal];
    [rightBtn addTarget:self action:@selector(clickRightBarBtnItem:) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *customRightBtnItem = [[UIBarButtonItem alloc]initWithCustomView:rightBtn];
    self.navigationItem.rightBarButtonItem = customRightBtnItem;
}

#pragma mark - BarItem的点击事件处理
-(void)clickLeftBarBtnItem:(UIButton *)backBtn
{
    [self.navigationController popViewControllerAnimated:YES];
    YDLog(@"点击了导航栏左边的Btn");
}

-(void)clickRightBarBtnItem:(UIButton *)moreBtn{
   
    UIImage *popImg = [UIImage imageNamed:@"popMenuBg.png"];
    CGFloat popMenuW = popImg.size.width;
    CGFloat popMenuH = popImg.size.height;
    
    self.moreMenuView = [[MoreNavigationMenView alloc]initWithFrame:CGRectMake(0, 0, popMenuW, popMenuH)];
    HMPopMenu *menu = [HMPopMenu popMenuWithContentView:self.moreMenuView];
    CGFloat menuW = popMenuW;
    CGFloat menuH = popMenuH;
    CGFloat menuY = 55;
    CGFloat menuX = self.view.width - menuW - 20;
    menu.dimBackground = YES;
    menu.arrowPosition = HMPopMenuArrowPositionRight;
    [menu showInRect:CGRectMake(menuX, menuY, menuW, menuH)];

}

#pragma mark - addRightSwipeGestures添加向右侧滑手势
-(void)addRightSwipeGestures{
    self.rightSwipeGestureRecognizer = [[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(handleSwipes:)];
    self.rightSwipeGestureRecognizer.direction = UISwipeGestureRecognizerDirectionRight;
    [self.view addGestureRecognizer:self.rightSwipeGestureRecognizer];
}

-(void)handleSwipes:(UISwipeGestureRecognizer *)sender{
    if (UISwipeGestureRecognizerDirectionRight == sender.direction) {
        [self.navigationController popViewControllerAnimated:YES];
    }
}

#pragma mark - setUI 设置UI
-(void)setUI{

    self.mTableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, screenWidth, screenHeight) style:UITableViewStylePlain];
    
    _mTableView.backgroundColor = [UIColor rgbFromHexString:@"#F1F1F1" alpaa:1.0];
    _mTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    _mTableView.dataSource = self;
    _mTableView.delegate = self;
    _mTableView.showsVerticalScrollIndicator = NO;
    _mTableView.bounces = YES;
    
    
    [_mTableView registerClass:[HWKTVInformationCell class] forCellReuseIdentifier:@"KTVInfoCell"];
    [_mTableView registerClass:[HWKTVOnGoingCell class] forCellReuseIdentifier:@"KTVOnGoingCell"];
    [_mTableView registerClass:[HWKTVHotSongCell class] forCellReuseIdentifier:@"KTVHotSongCell"];
//    [_mTableView registerClass:[HWKTVChatRecordCell class] forCellReuseIdentifier:@"KTVChatRecordCell"];
//    [_mTableView registerClass:[YDRoomMsgCell class] forCellReuseIdentifier:@"RoomMsgCell"];
    
    [self.view addSubview:_mTableView];

}



#pragma mark - UITableViewDataSource

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{

    return 1;
    
//    if (4 == section) {
//        return 15;
//    }else{
//        return 1;
//    }
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

    
    NSString *identifier = nil;
    
    switch (indexPath.section) {
        case 0:{
            identifier = @"KTVInfoCell";
        }
            break;
        case 1:{
            identifier = @"KTVOnGoingCell";
        }
            break;
        case 2:{
            identifier = @"KTVHotSongCell";
        }
            break;
//        case 3:{
//            identifier = @"KTVChatRecordCell";
//        }
//            break;
//        case 4:{
//            identifier = @"RoomMsgCell";
//        }
//            break;
            
        default:
            break;
    }

    //利用多态
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    
    if (!cell) {
        cell = [[[NSBundle mainBundle]loadNibNamed:identifier owner:self options:nil] lastObject];
    }
    
    
    if (0 == indexPath.section) {
        HWKTVInformationCell *ktvInfoCell = (HWKTVInformationCell *)cell;
        ktvInfoCell.lbSellerName.text = self.ktvBaseInfo.vStoreName;
        ktvInfoCell.directLongitude = [self.ktvBaseInfo.stLocationCoordinate.sLongitude floatValue];
        ktvInfoCell.directLatitude = [self.ktvBaseInfo.stLocationCoordinate.sLatitude floatValue];
        ktvInfoCell.lbSellerAddress.text = self.ktvBaseInfo.address;
        [ktvInfoCell.btnKtvActivity addTarget:self action:@selector(ktvActivity:) forControlEvents:UIControlEventTouchUpInside];
        
    }else if(1 == indexPath.section){
        
        //正在KTV
        HWKTVOnGoingCell *ktvOnGoing = (HWKTVOnGoingCell *)cell;
        ktvOnGoing.delegate = self;
        [ktvOnGoing.btnRepAnotherGroup addTarget:self action:@selector(switchKtvUserListArr) forControlEvents:UIControlEventTouchUpInside];
//        ktvOnGoing.ktvBaseInfo = self.listenToMeData.ktvBaseInfo;
        ktvOnGoing.arrStUserBaseInfoNet = [NSMutableArray arrayWithArray:self.arrKtvUserList ];
        
    }else if(2 == indexPath.section){
        //KTV热歌
        HWKTVHotSongCell *ktvHotSongCell = (HWKTVHotSongCell *)cell;
        ktvHotSongCell.arrStMyMusicWorkInfo = self.arrKtvHotSongList;
        ktvHotSongCell.delegate = self;
        
        //歌曲播放
        for (NSInteger btnTag = 0; btnTag < 6 ; btnTag++) {
            //在HWKTVHotSongCell,播放按键的tag值是从300开始的
            UIButton *playBtn = (UIButton *)[ktvHotSongCell viewWithTag:300 + btnTag];
            
            [playBtn addTarget:self action:@selector(playMusic:) forControlEvents:UIControlEventTouchUpInside];
            playBtn.selected = NO;
        }
        
        [ktvHotSongCell.btnMore addTarget:self action:@selector(checkMoreMemory) forControlEvents:UIControlEventTouchUpInside];
        
        
        
        //判断当前是否有音乐在播放,该音乐是否在当前页面,若果在,那么就将改音乐的播放按键状态设置为选中状态
        if ([ListenToMeData getInstance].currentMusicAudition) {
            NSArray *musicWorkInfoArr = self.arrKtvHotSongList;
            for (int index = 0; index < musicWorkInfoArr.count; index ++) {
                MusicWorkBaseInfo *musicWorkBaseInfo = musicWorkInfoArr[index];
                UIButton *playBtn = (UIButton *)[ktvHotSongCell viewWithTag:300 + index];
                if (musicWorkBaseInfo.lMusicWorkId == [ListenToMeData getInstance].currentMusicAudition.lMusicWorkId) {
                    YDLog(@"当前处于播放的cell是:%ld-%ld",indexPath.section,indexPath.row);
                    if (STKAudioPlayerStatePlaying == audioPlayer.state || STKAudioPlayerStateBuffering == audioPlayer.state) {
                        playBtn.selected = YES;
                    }else{
                        playBtn.selected = NO;
                    }
                }
            }
        }
        
        
        
    
    }
   
    //已移除该功能
    
//    else if(3 == indexPath.section){
//        //K友聊一聊 单独用一个cell,显示本KTV内一些聊天条数
////        HWKTVChatRecordCell *ktvChatCount = (HWKTVChatRecordCell *)cell;
//
//    
//    
//    }
    
    
//    else if(4 == indexPath.section){
//        
//        //给聊天的记录单独创建一个类型的cell
//        YDRoomMsgCell *msgCell = (YDRoomMsgCell *)cell;
//        msgCell.contentView.backgroundColor =[UIColor rgbFromHexString:@"#F1F1F1" alpaa:1.0];
//        msgCell.selectionStyle = UITableViewCellSelectionStyleNone;
//    
//    }
    
    
    return cell;
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{

    return 3;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    if (0 ==section || 1 == section) {
        return 0;
    }else{
        return 15;
    }
   
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
//    if (4 == section) {
//        return 49;
//    }else{
//        return 0;
//    }
    
    return 0;
}

//-(UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
//
//    //该模块已经被砍掉
//    UIView *footView = nil;
//
//    if (4 == section) {
//       footView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, screenWidth, 50)];
//        footView.backgroundColor = [UIColor whiteColor];
//        
//        UIButton *btnYueGe = [[UIButton alloc]initWithFrame:CGRectMake( 0 , 0, footView.width / 2 - 5, footView.height)];
//        [btnYueGe setTitle:@"在本店约歌" forState:UIControlStateNormal];
//        [btnYueGe setTitleColor:[UIColor rgbFromHexString:@"#AC56FF" alpaa:1.0] forState:UIControlStateNormal];
//        [btnYueGe.titleLabel setFont:[UIFont systemFontOfSize:14.0]];
//        [btnYueGe addTarget:self action:@selector(yuegeHandle:) forControlEvents:UIControlEventTouchUpInside];
//        [footView addSubview:btnYueGe];
//        
//        UIButton *haveAChat = [[UIButton alloc]initWithFrame:CGRectMake( screenWidth - footView.width /2 - 5, 0, footView.width / 2 - 5, footView.height)];
//        [haveAChat setTitle:@"聊一聊" forState:UIControlStateNormal];
//        [haveAChat setTitleColor:[UIColor rgbFromHexString:@"#AC56FF" alpaa:1.0] forState:UIControlStateNormal];
//        [haveAChat.titleLabel setFont:[UIFont systemFontOfSize:14.0]];
//        [haveAChat addTarget:self action:@selector(haveAChatHandle:) forControlEvents:UIControlEventTouchUpInside];
//        [footView addSubview:haveAChat];
//        
//        //竖线
//        UIImageView *lineView = [[UIImageView alloc]initWithFrame:CGRectMake(footView.width / 2 - 1, (footView.height - 25) / 2 , 1, 25)];
//        lineView.backgroundColor = [UIColor rgbFromHexString:@"AC56FF" alpaa:1.0];
//        [footView addSubview:lineView];
//    }
//    
//    return footView;
//}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{

    CGFloat cellHeight = 0;
    switch (indexPath.section) {
        case 0:{
            cellHeight = 80 + 32;
        }
            break;
        case 1:{
            cellHeight = 208;
        }
            break;
        case 2:{
            cellHeight = 275 + 190 + 30 + 190;
        }
            break;
//        case 3:{
//            cellHeight = 34;
//        }
//            break;
//        case 4:{
//        
//            cellHeight = 130;
//        }
//            break;
            
        default:
            break;
    }
    return cellHeight;
}


#pragma mark - 播放按键的点击事件
-(void)playMusic:(UIButton *)playButton{
    
    
    NSInteger playTag = playButton.tag - 300;
    
    
    
    MusicWorkBaseInfo *musicWorkInfo = self.arrKtvHotSongList[playTag];
    
    if (musicWorkInfo.lMusicWorkId != [ListenToMeData getInstance].currentMusicAudition.lMusicWorkId) {
        [[NetReqManager getInstance]sendMusicAuditon:[ListenToMeDBManager getUuid] LMusicWorkId:musicWorkInfo.lMusicWorkId];
    }else{
    
        if (STKAudioPlayerStateStopped == audioPlayer.state) {
            //如果歌曲播放完以后,播放器的状态会被置为stop,在次点击播放时,要改变播放按钮的选中状态
            playButton.selected = YES;
        }else if(STKAudioPlayerStatePlaying == audioPlayer.state){
            //当处于正在播放时,再次点击将会变为暂停,改变播放按键的状态
            playButton.selected = NO;
        }else if (STKAudioPlayerStatePaused == audioPlayer.state){
            //当处于播放暂停时,再次点击播放,改变播放按键的状态
            playButton.selected = YES;
        }else{
        //刷新列表
//            [self.mTableView reloadData];
        }
    }
    
    [self playMusicWork:musicWorkInfo];
    
    
}

#pragma mark - 播放音乐处理
-(void)playMusicWork:(MusicWorkBaseInfo *)musicWorkBaseInfo{
    
    if (nil == musicWorkBaseInfo) {
        return;
    }
    NSURL *url = [NSURL URLWithString:musicWorkBaseInfo.stSongInfo.sSongUrl];
    if ((STKAudioPlayerStateReady == audioPlayer.state) || (STKAudioPlayerStateStopped == audioPlayer.state)) {
        
        [audioPlayer playURL:url];
        
        
    }else if(STKAudioPlayerStatePlaying == audioPlayer.state){
        if (musicWorkBaseInfo.lMusicWorkId == [ListenToMeData getInstance].currentMusicAudition.lMusicWorkId) {
            [audioPlayer pause];
        }else{
            
            [audioPlayer playURL:url];
        }
        
        
    }else if(STKAudioPlayerStatePaused == audioPlayer.state){
        if (musicWorkBaseInfo.lMusicWorkId == [ListenToMeData getInstance].currentMusicAudition.lMusicWorkId) {
            [audioPlayer resume];
        }else{
            
            [audioPlayer playURL:url];
        }
        
    }
    
    
    
}


#pragma mark - SKTAudioPlayerDelegate
-(void)audioPlayer:(STKAudioPlayer *)audioPlayer stateChanged:(STKAudioPlayerState)state previousState:(STKAudioPlayerState)previousState{
    
    
    switch (state) {
        case STKAudioPlayerStateReady:
            
            break;
        case STKAudioPlayerStateBuffering:
            
            break;
        case STKAudioPlayerStatePaused:
            
            break;
        case STKAudioPlayerStatePlaying:
            if (self.listenToMeData.currentMusicAudition) {
#warning 进入后台,锁屏播放
                [self showInfoInLockedScreen:self.listenToMeData.currentMusicAudition];
            }
            break;
        case STKAudioPlayerStateStopped:
            
            [ListenToMeData getInstance].currentMusicAudition = nil;
            [self.mTableView reloadData];
            break;
        case STKAudioPlayerStateRunning:
            
            break;
        case STKAudioPlayerStateDisposed:
            
            break;
        case STKAudioPlayerStateError:
            
            break;
            
        default:
            break;
    }
    
}
-(void)audioPlayer:(STKAudioPlayer *)audioPlayer didStartPlayingQueueItemId:(NSObject *)queueItemId{
    
}
-(void)audioPlayer:(STKAudioPlayer *)audioPlayer didFinishBufferingSourceWithQueueItemId:(NSObject *)queueItemId{
    
}

-(void)audioPlayer:(STKAudioPlayer *)audioPlayer didFinishPlayingQueueItemId:(NSObject *)queueItemId withReason:(STKAudioPlayerStopReason)stopReason andProgress:(double)progress andDuration:(double)duration{
    
}

-(void)audioPlayer:(STKAudioPlayer *)audioPlayer unexpectedError:(STKAudioPlayerErrorCode)errorCode{
    
}


#pragma mark - 锁屏后显示播放歌曲的名字
-(void)showInfoInLockedScreen:(MusicWorkBaseInfo *)musicWorkBaseInfo{
    if (!musicWorkBaseInfo) {
        return;
    }
    
    if (NSClassFromString(@"MPNowPlayingInfoCenter")) {
        NSMutableDictionary *info = [NSMutableDictionary dictionary];
        
        //音乐歌曲名
        info[MPMediaItemPropertyTitle] = musicWorkBaseInfo.stSongInfo.sSongName;
        
        //音乐艺术家
        info[MPMediaItemPropertyArtist] = musicWorkBaseInfo.stSongInfo.sSongSinger;
        
        //专辑名称
        info[MPMediaItemPropertyAlbumTitle] = musicWorkBaseInfo.stSongInfo.sSongSinger;
        
        //图片
        info[MPMediaItemPropertyArtwork] = [[MPMediaItemArtwork alloc]initWithImage:[UIImage imageNamed:@"icon.png"]];
        
        //音乐当前已经播放的时间
        info[MPNowPlayingInfoPropertyElapsedPlaybackTime] = [NSNumber numberWithDouble:[ListenToMeData getInstance].audioPlayer.progress];
        
        //进度光标的速度,(可以自己调整播放速率,默认是原速度播放)
        info[MPNowPlayingInfoPropertyPlaybackRate] = [NSNumber numberWithFloat:1.0];
        
        //歌曲总时间的设置
        info[MPMediaItemPropertyPlaybackDuration] = [NSNumber numberWithDouble:[ListenToMeData getInstance].audioPlayer.duration];
        
        //唯一的API,单例,nowPlayingInfo字典
        [MPNowPlayingInfoCenter defaultCenter].nowPlayingInfo = info;
        
    }
}

#pragma mark 接收进入后台锁屏等状态是,执行操作如:暂停,播放,下一曲,上一曲
- (void)remoteControlReceivedWithEvent:(UIEvent *)event {
    //if it is a remote control event handle it correctly
    NSLog(@"%li,%li",event.type,event.subtype);
    if(event.type==UIEventTypeRemoteControl){
        switch (event.subtype) {
            case UIEventSubtypeRemoteControlPlay:
                if (STKAudioPlayerStatePlaying == audioPlayer.state) {
                    [audioPlayer pause];
                }else{
                    [audioPlayer resume];
                }
                NSLog(@"play");
                break;
            case UIEventSubtypeRemoteControlPause:
                [audioPlayer pause];
                NSLog(@"pause");
                
                break;
            case UIEventSubtypeRemoteControlStop:
                NSLog(@"stop");
                break;
            case UIEventSubtypeRemoteControlTogglePlayPause:
                //使用耳机时也可暂定音乐播放
                if (STKAudioPlayerStatePlaying == audioPlayer.state) {
                    [audioPlayer pause];
                }else{
                    [audioPlayer resume];
                }
                NSLog(@"toggle");
                break;
            case UIEventSubtypeRemoteControlNextTrack:
                NSLog(@"Next...");
                break;
            case UIEventSubtypeRemoteControlPreviousTrack:
                NSLog(@"Previous...");
                break;
            case UIEventSubtypeRemoteControlBeginSeekingForward:
                NSLog(@"Begin seek forward...");
                break;
            case UIEventSubtypeRemoteControlEndSeekingForward:
                NSLog(@"End seek forward...");
                break;
            case UIEventSubtypeRemoteControlBeginSeekingBackward:
                NSLog(@"Begin seek backward...");
                break;
            case UIEventSubtypeRemoteControlEndSeekingBackward:
                NSLog(@"End seek backward...");
                break;
            default:
                break;
        }
        //其他操作
        //        [self changeUIState];
        [self.mTableView reloadData];
    }
}




#pragma mark - 查看更多的K店回忆
-(void)checkMoreMemory{
//    KStoreMemoryVC *kStoreMemoryListVC = [[KStoreMemoryVC alloc] init];
    
    if (kStoreMemoryVC) {
        kStoreMemoryVC = nil;
    }
   
    kStoreMemoryVC = [[KStoreMemoryVC alloc]init];
    kStoreMemoryVC.navigationItem.title = @"K店回忆";
//    kStoreMemoryListVC.kStoreMemoryDataArr = [NSMutableArray arrayWithArray:self.arrKtvHotSongList];
    kStoreMemoryVC.lKtvId = self.listenToMeData.ktvBaseInfo.lKtvId;
    [self.navigationController pushViewController:kStoreMemoryVC animated:YES];
}

#pragma mark - HWKTVOnGoingCellDelegate
#pragma mark - 进入他人主页
-(void)browsePerHmePage:(UserBaseInfoNet *)userBaseInfoNet{
    //点击他人头像进入他人主页,该功能去除,跟换为点击他人头像进入私聊界面;
    
//    FriendsMsgVC *chatWithFriend = [[FriendsMsgVC alloc]init];
//    chatWithFriend.navigationItem.title = userBaseInfoNet.sNick ;;
//    chatWithFriend.friendUserBaseInfoNet = userBaseInfoNet;;
//    [ListenToMeData getInstance].privateChatUser = userBaseInfoNet;
//    [self.navigationController pushViewController:chatWithFriend animated:YES];
    
    HWPerHomePageVC *personHomePageVC = [[HWPerHomePageVC alloc]init];
    personHomePageVC.userBaseInfoNet = userBaseInfoNet;
    [self.navigationController pushViewController:personHomePageVC animated:YES];
}

-(void)viewOthersHomePage:(UserBaseInfoNet *)userBaseInfoNet{
    //点击他人头像进入他人主页,该功能去除,跟换为点击他人头像进入私聊界面;
    
//    FriendsMsgVC *chatWithFriend = [[FriendsMsgVC alloc]init];
//    chatWithFriend.navigationItem.title = userBaseInfoNet.sNick;
//    chatWithFriend.friendUserBaseInfoNet = userBaseInfoNet;
//    [ListenToMeData getInstance].privateChatUser = userBaseInfoNet;
//    [self.navigationController pushViewController:chatWithFriend animated:YES];
    
    HWPerHomePageVC *personHomePageVC = [[HWPerHomePageVC alloc]init];
    personHomePageVC.userBaseInfoNet = userBaseInfoNet;
    [self.navigationController pushViewController:personHomePageVC animated:YES];
}

#pragma mark - 换一批数据
-(void)switchKtvUserListArr{
    
    [[NetReqManager getInstance] sendGetSwitchKtvUserList:(int32_t)(++countForKtvUserList) INum:(int32_t)(self.arrKtvUserList.count) LKtvId:self.listenToMeData.ktvBaseInfo.lKtvId];
    
}

#pragma mark - ktvActivity店内活动
-(void)ktvActivity:(UIButton *)btnKtvActivity{
    KStoreActivityVC *kStoreActivityVC = [[KStoreActivityVC alloc]init];
    kStoreActivityVC.ktvBaseInfo = self.ktvBaseInfo;
    [self.navigationController pushViewController:kStoreActivityVC animated:YES];
}

//#pragma mark - 在本店约歌
//-(void)yuegeHandle:(UIButton *)btnYueGe{
//    
//    YDLaunchPartyVC *lancuhPatyVC = [[YDLaunchPartyVC alloc]init];
//    [self.navigationController pushViewController:lancuhPatyVC animated:YES];
//}
//
//#pragma mark - 聊一聊
//-(void)haveAChatHandle:(UIButton *)btHaveAChat{
//
//    YDLog(@"聊一聊");
//}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
