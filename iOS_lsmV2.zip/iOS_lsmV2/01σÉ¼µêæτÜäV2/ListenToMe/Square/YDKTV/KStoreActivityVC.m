//
//  KStoreActivityVC.m
//  ListenToMe
//
//  Created by zhw on 15/7/8.
//  Copyright (c) 2015年 listentome. All rights reserved.
//

#import "KStoreActivityVC.h"
#import "LoadDataView.h"
#import "NSString+Extension.h"
#import "KStoreActivityCell.h"
@interface KStoreActivityVC ()<UITableViewDataSource,UITableViewDelegate>
/**
 *  tableView
 */
@property(nonatomic,strong) UITableView *tableView;
/**
 *  加载数据的动画
 */
@property(nonatomic,strong) LoadDataView *loadDataView;
/**
 *  数据
 */
@property(nonatomic,strong) ListenToMeData *listenToMeData;
@end

@implementation KStoreActivityVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.navigationItem.title = @"店内活动";
    
    //自定义顶部导航栏
    [self customizedBarItem];
    
    //UI设置
    [self setUI];
    
    //添加一个向右的侧滑的手势
    [self addRightSwipeGestures];
    
    //数据加载过渡动画
    [self setLoaddataGif];
    
    [self initData];
    
}


#pragma mark -customNavigationBar
-(void)customizedBarItem{
    
    [self setLeftBtnItem];
    
    
}
#pragma mark - 设置左边的BarItem
-(void)setLeftBtnItem{
    
    UIButton *customButton = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, 100, 41)];
    customButton.backgroundColor = [UIColor clearColor];
    [customButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    customButton.titleLabel.font = [UIFont systemFontOfSize:16.5];
    customButton.titleLabel.textAlignment = NSTextAlignmentCenter;
    [customButton setTitle:@"K店回忆" forState:UIControlStateNormal];
    self.navigationItem.titleView = customButton;
    
    UIButton *leftBtn = [[UIButton alloc]init];
    UIImage *leftBtnImg = [UIImage imageNamed:@"whiteBack.png"];
    leftBtn.frame = CGRectMake(0, 0, leftBtnImg.size.width, leftBtnImg.size.height);
    [leftBtn setImage:leftBtnImg forState:UIControlStateNormal];
    [leftBtn addTarget:self action:@selector(clickLeftBarBtnItem:) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *customLeftBtnItem = [[UIBarButtonItem alloc]initWithCustomView:leftBtn];
    self.navigationItem.leftBarButtonItem = customLeftBtnItem;
}

#pragma mark - BarItem的点击事件处理
-(void)clickLeftBarBtnItem:(UIButton *)backBtn
{
    [self.navigationController popViewControllerAnimated:YES];
    
}


#pragma mark - addRightSwipeGestures添加向右侧滑手势
-(void)addRightSwipeGestures{
    UISwipeGestureRecognizer *rightSwipeGestureRecognizer = [[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(handleSwipes:)];
    rightSwipeGestureRecognizer.direction = UISwipeGestureRecognizerDirectionRight;
    [self.view addGestureRecognizer:rightSwipeGestureRecognizer];
}

-(void)handleSwipes:(UISwipeGestureRecognizer *)sender{
    if (UISwipeGestureRecognizerDirectionRight == sender.direction) {
        [self.navigationController popViewControllerAnimated:YES];
    }
}

#pragma mark - setLoaddataGif
-(void)setLoaddataGif{
    if (!self.loadDataView) {
        CGRect loadDataFrame = CGRectMake(0, naviAndStatusH, screenWidth, screenHeight - naviAndStatusH);
        self.loadDataView =[[LoadDataView alloc]initWithFrame:loadDataFrame];
    }
    
    //    [[[UIApplication sharedApplication]keyWindow] addSubview:self.loadDataView];
    [self.view addSubview:self.loadDataView];
}

//动画消失
-(void)dismissLoadDataView{
    [self.loadDataView removeFromSuperview];
}

#pragma mark - setUI
-(void)setUI{
    //设置导航栏
    
    
    //设置TableView
    self.tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, screenWidth, self.view.frame.size.height) style:UITableViewStylePlain];
    self.tableView.backgroundColor = [UIColor rgbFromHexString:@"#F1F1F1" alpaa:1.0];
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    self.tableView.showsVerticalScrollIndicator = NO;
    self.tableView.bounces = YES;
    [self.view addSubview:self.tableView];
    
    
}

#pragma mark - initData 初始化数据
-(void)initData{
    self.listenToMeData = [ListenToMeData getInstance];
    
    [[NetReqManager getInstance] sendGetKtvAcitviytList:[ListenToMeDBManager getUuid] LKtvId:self.ktvBaseInfo.lKtvId IOffset:0 INum:2];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshTable) name:NOTIFY_GET_KTVACTIVITYLIST_PAGE_RESP object:nil];
    
    
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:NOTIFY_GET_KTVACTIVITYLIST_PAGE_RESP object:nil];
}

-(void)refreshTable{
    
    [self dismissLoadDataView];
    [self.tableView reloadData];
}

#pragma mark - UITableViewDelegate,UITableViewDataSource

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return self.listenToMeData.arrKtvActivityList.count;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 1;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    //目前获得数据不够完整,只能将cell的高度设置为固定高度,后期数据完整后,在动态计算cell的高度
    return 370;
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    if (section == 0) {
        return 0;
    }else{
        return  15;
    }
    
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    KStoreActivityCell *cell = [KStoreActivityCell cellWithTableView:tableView];
    
    cell.ktvActivityInfo = self.listenToMeData.arrKtvActivityList[indexPath.section];
    cell.ktvBaseInfo = self.ktvBaseInfo;
    
    
    
    return cell;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
