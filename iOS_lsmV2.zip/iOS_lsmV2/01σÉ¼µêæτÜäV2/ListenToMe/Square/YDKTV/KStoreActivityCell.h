//
//  KStoreActivityCell.h
//  ListenToMe
//
//  Created by zhw on 15/7/9.
//  Copyright (c) 2015年 listentome. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KStoreActivityCell : UITableViewCell
+(instancetype)cellWithTableView:(UITableView *)tableView;
@property(nonatomic,strong)KtvActivityInfo *ktvActivityInfo;
@property(nonatomic,strong)KtvBaseInfo *ktvBaseInfo;
@end
