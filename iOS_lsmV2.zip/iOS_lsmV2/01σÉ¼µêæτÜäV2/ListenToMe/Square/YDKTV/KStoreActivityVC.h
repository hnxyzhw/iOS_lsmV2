//
//  KStoreActivityVC.h
//  ListenToMe
//
//  Created by zhw on 15/7/8.
//  Copyright (c) 2015年 listentome. All rights reserved.
//

#import "YDBaseVC.h"

@interface KStoreActivityVC : YDBaseVC
/**
 *  ktv店内基本信息
 */
@property(nonatomic,strong) KtvBaseInfo *ktvBaseInfo;
@end
