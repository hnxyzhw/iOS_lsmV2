//
//  HWImageAndLabel.m
//  ListenToMe
//
//  Created by zhw on 15/6/17.
//  Copyright (c) 2015年 listentome. All rights reserved.
//

#import "HWImageAndLabel.h"

@interface HWImageAndLabel ()
/**
 *  左侧显示图标的视图
 */
@property(nonatomic,strong) UIImageView *showImageView;
/**
 *  右侧显示数量的视图
 */
@property(nonatomic,strong) UILabel *showNumberLabel;

@end


@implementation HWImageAndLabel
@synthesize showImageView;
@synthesize showNumberLabel;


-(id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [self setUI];
    }
    return self;
}

-(void)setUI{
    //左侧视图为要显示图标的ImageView
//    showImageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 15, 15)];
    showImageView = [[UIImageView alloc]init];
    showImageView.backgroundColor = [UIColor clearColor];
    [self addSubview:showImageView];
    
    //右侧视图是要显示数字的Label
//    showNumberLabel = [[UILabel alloc]initWithFrame:CGRectMake(15 + 5, 0,25, 15)];
//    showNumberLabel.textColor = [UIColor rgbFromHexString:@"#A8AEAE" alpaa:1.0];
    showNumberLabel = [[UILabel alloc]init];
    showNumberLabel.font = [UIFont systemFontOfSize:12.0];
    showNumberLabel.textAlignment = NSTextAlignmentCenter;
    [self addSubview:showNumberLabel];
    
}

-(void)setImgName:(NSString *)imgName{
    [showImageView setImage:[UIImage imageNamed:imgName]];
}

-(void)setNumber:(NSString *)number{
    [showNumberLabel setText:number];
}

-(void)setNumberColor:(UIColor *)numberColor{
    showNumberLabel.textColor = numberColor;
}

-(void)setLeftIconFrame:(CGRect)leftIconFrame{
    showImageView.frame = CGRectMake(leftIconFrame.origin.x, (self.height - leftIconFrame.size.height) * 0.5, leftIconFrame.size.width, leftIconFrame.size.height);
    
}

-(void)setRightLabFrame:(CGRect)rightLabFrame{
    showNumberLabel.frame = CGRectMake(rightLabFrame.origin.x, (self.height - rightLabFrame.size.height) * 0.5, rightLabFrame.size.width, rightLabFrame.size.height);;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
