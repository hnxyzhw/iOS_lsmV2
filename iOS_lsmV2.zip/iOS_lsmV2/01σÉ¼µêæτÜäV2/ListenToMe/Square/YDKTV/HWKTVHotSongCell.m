//
//  HWKTVHotSongCell.m
//  ListenToMe
//
//  Created by zhw on 15/4/2.
//  Copyright (c) 2015年 listentome. All rights reserved.
//

#import "HWKTVHotSongCell.h"
#import "AudioStreamer.h"
#import "HWImageAndLabel.h"
#import "HWSimpleRecallAlbum.h"
@interface HWKTVHotSongCell ()
/**
 *  在线音乐播放
 */
@property(nonatomic,strong) AudioStreamer *audioStreamer;
/**
 *  是否在播放
 */
@property(nonatomic,assign) BOOL isPlay;
/**
 *  记录上一次点击的button的tag
 */
@property(nonatomic,assign) NSInteger oldTag;
/**
 *  三期纪念册封面
 */
@property(strong,nonatomic) UIImageView *imgCover;
/**
 * 聚会名
 */
@property(strong,nonatomic) UILabel *lbPartyName;

/**
 * 歌曲名
 */
@property(strong,nonatomic) UILabel *lbMusicName;
/**
 * 聚会主题
 */
@property(strong,nonatomic) UILabel *lbTheme;
/**
 * 聚会主题图片标识
 */
@property(strong,nonatomic) UIImageView *imgTheme;
/**
 * 歌曲数目
 */
@property(strong,nonatomic) UIButton *btnNumSongs;
/**
 * 聚会照片数目
 */
@property(strong,nonatomic) UIButton *btnNumAlbums;
/**
 * 聚会查看数目
 */
@property(strong,nonatomic) UIButton *btnNumSee;
/**
 * 聚会送花数目
 */
@property(strong,nonatomic) UIButton *btnNumFlower;
/**
 *  纪念册的制作者的头像
 */
@property(strong,nonatomic) UIImageView *imgMemoryMaker;
/**
 *  纪念册的标签01
 */
@property(strong,nonatomic) UIButton *btnMemoryLabel_01;
/**
 *  纪念册的标签02
 */
@property(strong,nonatomic) UIButton *btnMemoryLabel_02;
/**
 *  纪念册的标签03
 */
@property(strong,nonatomic) UIButton *btnMemoryLabel_03;

@end

@implementation HWKTVHotSongCell
@synthesize audioStreamer;
@synthesize isPlay;

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

+(instancetype)cellWithTableView:(UITableView *)tableView{
    
    NSString *identifier = @"KTVHotSongCell";
    HWKTVHotSongCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    
    if (!cell) {
        cell = [[HWKTVHotSongCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];

    }
    
    return cell;

}

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{

    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    
    if (self) {
        [self setUI];
        self.selectionStyle = UITableViewCellSelectionStyleNone;

    }
    
    return self;
}


#pragma mark - setUI

-(void)setUI{


    // 添加子控件
    CGFloat frontX = 15; // cell前排子控件开始的x坐标 & 右侧控件距离screen右侧的距离
    CGFloat cellHeight = 39; // cell中每个cell的高度
    CGFloat lineHeight = 1; // 分割线的高度
    
    //竖线
    CGFloat imgLineW = 2; //竖线的宽度
    UIImageView *imgLineView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, imgLineW, cellHeight)];
    imgLineView.backgroundColor = [UIColor rgbFromHexString:@"#FF0053" alpaa:1.0];
    [self.contentView addSubview:imgLineView];
    
    
    // 1热歌榜
    
    UIImage *hotSongimg = [UIImage imageNamed:@"ktv热歌.png"];
    UIImageView *hotSongView = [[UIImageView alloc]initWithFrame:CGRectMake(frontX , 0, hotSongimg.size.width * 0.5, hotSongimg.size.height * 0.5)];
    hotSongView.image = hotSongimg;
    [self.contentView addSubview:hotSongView];
    
    UILabel *hotMusicLb = [[UILabel alloc]initWithFrame:CGRectMake(frontX * 3, 0, 60, cellHeight)];
    hotMusicLb.font = [UIFont systemFontOfSize:12.0];
    hotMusicLb.textColor = [UIColor rgbFromHexString:@"FF0053" alpaa:1.0];
    hotMusicLb.text = @"K店回忆";
    hotMusicLb.textAlignment = NSTextAlignmentLeft;
    [self.contentView addSubview:hotMusicLb];
    
//    UIImageView *imgLine_1 = [[UIImageView alloc]initWithFrame:CGRectMake(frontX , cellHeight, screenWidth - 2 * frontX, lineHeight)];
//    imgLine_1.backgroundColor = [UIColor rgbFromHexString:@"#AC56FF" alpaa:.12];
//    [self.contentView addSubview:imgLine_1];
    
    //更多
    CGFloat moreLbW = 24; //跟多label的宽
    CGFloat moreBtnW = 10; //更多button的宽
    
    self.btnMore = [[UIButton alloc]initWithFrame:CGRectMake(screenWidth - frontX - moreBtnW - moreLbW, 0, moreBtnW + moreLbW, cellHeight)];
    
    UILabel *lbMore = [[UILabel alloc]initWithFrame:CGRectMake(0, (self.btnMore.height - 13) * 0.5, moreLbW, 13)];
    lbMore.text = @"更多";
    [lbMore setTextColor:[UIColor rgbFromHexString:@"#9B9B9B" alpaa:1.0]];
    [lbMore setFont:[UIFont systemFontOfSize:12.0]];
    [self.btnMore addSubview:lbMore];
    
    UIImage *moreImg = [UIImage imageNamed:@"查看更多热歌.png"];
    UIImageView *moreView = [[UIImageView alloc]initWithFrame:CGRectMake(moreLbW, (self.btnMore.height - moreImg.size.height *0.5 ) * 0.5, moreImg.size.width * 0.5, moreImg.size.height * 0.5)];
    moreView.image =moreImg;
    [self.btnMore addSubview:moreView];
    
    [self.contentView addSubview:self.btnMore];
    
    
    
    UIImage *playBtnImg = [UIImage imageNamed:@"play.png"];
    UIImage *stopBtnImg = [UIImage imageNamed:@"stop.png"];
    CGFloat avatarWh = 25;
    CGFloat fFlowerW = 65;
//    CGFloat fFloweMargin = 25;
    CGFloat songNameWidth = 105;
    CGFloat btnSingerX = frontX;
    CGFloat btnSingerY;
    //固定值,6条音乐作品数据,2条纪念册数据
    for (int index = 0; index < 6; index ++) {
        
        UIImageView *imgLine_1 = [[UIImageView alloc]init];
        if (index >= 3) {
            imgLine_1.frame = CGRectMake(frontX , cellHeight * (index + 1) - lineHeight + 190 + 15, screenWidth - 2 * frontX, lineHeight);
        }else{
            imgLine_1.frame = CGRectMake(frontX , cellHeight * (index + 1) - lineHeight, screenWidth - 2 * frontX, lineHeight);
        }
        imgLine_1.backgroundColor = [UIColor rgbFromHexString:@"#AC56FF" alpaa:.12];
        [self.contentView addSubview:imgLine_1];
        
        btnSingerY = imgLine_1.y + imgLine_1.height + (cellHeight - avatarWh) * 0.5;
        
        
        UIButton *singerBtn = [[UIButton alloc]initWithFrame:CGRectMake(btnSingerX, btnSingerY , avatarWh, avatarWh)];
        
        [singerBtn addTarget:self action:@selector(jumpToPerHomePage:) forControlEvents:UIControlEventTouchUpInside];
        
        singerBtn.tag = 100 + index;
        
        UIImageView *singerImgView = [[UIImageView alloc]initWithFrame:singerBtn.frame];
        singerImgView.userInteractionEnabled = YES;
        singerImgView.layer.masksToBounds = YES;
        singerImgView.layer.cornerRadius = avatarWh * 0.5;
        singerImgView.tag = 200 + index;
        [self.contentView addSubview:singerImgView];
        
        [self.contentView addSubview:singerBtn];
        
        // 播放按钮
        CGFloat btnPlayX = singerBtn.x + singerBtn.width + frontX;
        CGFloat btnPlayY = imgLine_1.y + imgLine_1.height + (cellHeight - playBtnImg.size.height * 0.5) * 0.5 ;
        CGFloat btnPlayW = playBtnImg.size.width * 0.5;
        CGFloat btnPlayH = playBtnImg.size.height * 0.5;
        UIButton *playBtn = [[UIButton alloc]initWithFrame:CGRectMake(btnPlayX,btnPlayY ,btnPlayW,btnPlayH)];
        
        [playBtn setImage:playBtnImg forState:UIControlStateNormal];
        [playBtn setImage:stopBtnImg forState:UIControlStateSelected];
        
        playBtn.tag = 300 + index;
        
//        [playBtn addTarget:self action:@selector(playMusic:) forControlEvents:UIControlEventTouchUpInside];
       
        [self.contentView addSubview:playBtn];
        
        // 歌曲名
        
        CGFloat lbSongNameX = playBtn.x + playBtn.width + 10;
        CGFloat lbSongNameY = imgLine_1.y + imgLine_1.height;
        CGFloat lbSongNameW = songNameWidth;
        CGFloat lbSongNameH = cellHeight;
        
        UILabel *lbSongName = [[UILabel alloc]initWithFrame:CGRectMake(lbSongNameX, lbSongNameY , lbSongNameW, lbSongNameH)];
        lbSongName.font = [UIFont systemFontOfSize:12.0];
        lbSongName.textColor = [UIColor rgbFromHexString:@"#4A4A4A" alpaa:1.0];
        lbSongName.textAlignment = NSTextAlignmentLeft;
        
        lbSongName.tag = 400 + index;
        
        [self.contentView addSubview:lbSongName];
        
        // 鲜花数
        
        CGFloat btnFlowerX = screenWidth - frontX -fFlowerW;
        CGFloat btnFlowerY = imgLine_1.y + imgLine_1.height ;
        CGFloat btnFlowerW = fFlowerW;
        CGFloat btnFlowerH = cellHeight;
        HWImageAndLabel *btnFlower = [[HWImageAndLabel alloc]initWithFrame:CGRectMake(btnFlowerX,btnFlowerY ,btnFlowerW ,btnFlowerH)];
        
//        [btnFlower setImage:[UIImage imageNamed:@"flowerSquareKtv.png"] forState:UIControlStateNormal];
//        [btnFlower setTitle:@"114" forState:UIControlStateNormal];
//        btnFlower.titleLabel.font = [UIFont systemFontOfSize:10.0];
//        [btnFlower setTitleColor:[UIColor rgbFromHexString:@"#AC56FF" alpaa:1.0] forState:UIControlStateNormal];
//        btnFlower.titleLabel.textAlignment = NSTextAlignmentRight;
//        [btnFlower setTitleEdgeInsets:UIEdgeInsetsMake(0, fFloweMargin, 0, 0)];
        btnFlower.leftIconFrame = CGRectMake(0, 0, 10, 15);
        btnFlower.imgName = @"送花数量.png";
        btnFlower.rightLabFrame = CGRectMake(10, 0, btnFlower.width - 10, 15);
        btnFlower.numberColor = [UIColor rgbFromHexString:@"#FF0053" alpaa:1.0];

        
        btnFlower.tag = 500 + index;
        
        [self.contentView addSubview:btnFlower];
        
        
        // 听众数
        CGFloat btnListenNumX = btnFlower.x - fFlowerW;
        CGFloat btnListenNumY = imgLine_1.y + imgLine_1.height;
        CGFloat btnListenNumW = fFlowerW;
        CGFloat btnListenNumH = cellHeight;
        HWImageAndLabel *btnListenNum = [[HWImageAndLabel alloc]initWithFrame:CGRectMake(btnListenNumX, btnListenNumY, btnListenNumW,btnListenNumH )];
//        [btnListenNum setImage:[UIImage imageNamed:@"listenersCount.png"] forState:UIControlStateNormal];
//        [btnListenNum setTitle:@"12306" forState:UIControlStateNormal];
//        btnListenNum.titleLabel.font = [UIFont systemFontOfSize:10.0];
//        [btnListenNum setTitleColor:[UIColor rgbFromHexString:@"#FF0053" alpaa:1.0] forState:UIControlStateNormal];
//        btnListenNum.titleLabel.textAlignment = NSTextAlignmentRight;
//        [btnListenNum setTitleEdgeInsets:UIEdgeInsetsMake(0, fFloweMargin, 0, 0)];
        
        btnListenNum.leftIconFrame = CGRectMake(0, 0, 10, 8);
        btnListenNum.imgName = @"收听数.png";
        btnListenNum.rightLabFrame = CGRectMake(10, 0, btnListenNum.width - 10, 15);
        btnListenNum.numberColor = [UIColor rgbFromHexString:@"#FF0053" alpaa:1.0];;
        
        btnListenNum.tag = 600 + index;
        
        [self.contentView addSubview:btnListenNum];
        
        
        if (index == 2) {
            
            CGFloat recallAlbum_X = frontX;
            CGFloat recallAlbum_Y = imgLine_1.y + imgLine_1.height + cellHeight + 15;
            CGFloat recallAlbum_W = screenWidth - frontX * 2;
            CGFloat recallAlbum_H = 190 ;
            //分割线
            UIImageView *firstRecallAlbumLine = [[UIImageView alloc]initWithFrame:CGRectMake(frontX, imgLine_1.y + imgLine_1.height + cellHeight, recallAlbum_W, lineHeight)];
            firstRecallAlbumLine.backgroundColor = [UIColor rgbFromHexString:@"#AC56FF" alpaa:0.12];
            [self.contentView addSubview:firstRecallAlbumLine];
            
            HWSimpleRecallAlbum *firstRecallAlbum = [[HWSimpleRecallAlbum alloc]initWithFrame:CGRectMake(recallAlbum_X, recallAlbum_Y, recallAlbum_W, recallAlbum_H)];
            [self.contentView addSubview:firstRecallAlbum];
    
        }
        
        if (index == 5) {
            CGFloat recallAlbum_X = frontX;
            CGFloat recallAlbum_Y = imgLine_1.y + imgLine_1.height + cellHeight + 15;
            CGFloat recallAlbum_W = screenWidth - frontX * 2;
            CGFloat recallAlbum_H = 190;
            //分割线
            UIImageView *secondRecallAlbumLine = [[UIImageView alloc]initWithFrame:CGRectMake(frontX, imgLine_1.y + imgLine_1.height + cellHeight, recallAlbum_W, lineHeight)];
            secondRecallAlbumLine.backgroundColor = [UIColor rgbFromHexString:@"#AC56FF" alpaa:0.12];
            [self.contentView addSubview:secondRecallAlbumLine];
            
            HWSimpleRecallAlbum *secondRecallAlbum = [[HWSimpleRecallAlbum alloc]initWithFrame:CGRectMake(recallAlbum_X, recallAlbum_Y, recallAlbum_W, recallAlbum_H)];
            [self.contentView addSubview:secondRecallAlbum];
        }
    }

}

#pragma mark - 浏览他人主页
-(void)jumpToPerHomePage:(UIButton *)button{
    
    NSInteger index = button.tag - 100;
    
    MusicWorkBaseInfo *musicWorkBaseInfo = _arrStMyMusicWorkInfo[index];
    UserBaseInfoNet *userBaseInfoNet = musicWorkBaseInfo.stUserBaseInfoNet;
        
    //使用协议代理到control中实现个人主页的页面跳转
    
    if ([self.delegate respondsToSelector:@selector(viewOthersHomePage:)]) {
        //        [self.delegate performSelector:@selector(browsePerHmePage) withObject:self];
        [self.delegate viewOthersHomePage:userBaseInfoNet];
    }

    
    
}

#pragma mark - 音乐播放
-(void)playMusic:(UIButton *)button{

    for (int index = 0 ; index < _arrStMyMusicWorkInfo.count; index ++) {
        UIButton *playButton = (UIButton *)[self viewWithTag:index + 300];
        if (button.tag == index + 300) {
            
            
            if (!isPlay) {
                
                [self playWithTag:button.tag];
                playButton.selected = YES;
                isPlay = YES;
                _oldTag = button.tag;
                
            }else{
                
                if (_oldTag != button.tag) {
                    
                    if (audioStreamer) {
                        [self destroyStreamer];
                    }
                    [self playWithTag:button.tag];
                    isPlay = YES;
                    playButton.selected = YES;
                    _oldTag = button.tag;
                }else{
                    
                    if (audioStreamer) {
                        [self destroyStreamer];
                    }
                    playButton.selected = NO;
                    _oldTag = button.tag;
                    isPlay = NO;
                }
                
                
               
            }
            
        }else{
            playButton.selected = NO;
            
            
        }
    }
    
    
}


#pragma mark -播放
-(void)playWithTag:(NSInteger)tag{
    
    if (audioStreamer) {
        return;
    }
    
    
    [self destroyStreamer];
    MusicWorkBaseInfo *musicWorkBaseInfo = self.arrStMyMusicWorkInfo[tag - 300];
    //发送当前试听音乐的请求
    [[NetReqManager getInstance]sendMusicAuditon:[ListenToMeDBManager getUuid] LMusicWorkId:musicWorkBaseInfo.lMusicWorkId];
    
    NSURL *onLineMusicUrl = [NSURL URLWithString:((MusicWorkBaseInfo *)self.arrStMyMusicWorkInfo[tag - 300]).stSongInfo.sSongUrl];
    audioStreamer = [[AudioStreamer alloc]initWithURL:onLineMusicUrl];
    
    
    [[NSNotificationCenter defaultCenter]
     addObserver:self
     selector:@selector(playbackStateChanged:)
     name:ASStatusChangedNotification
     object:audioStreamer];
    
    [audioStreamer start];
    
    
}
#pragma mark 播放状态改变
- (void)playbackStateChanged:(NSNotification *)aNotification
{
    
    if ([audioStreamer isWaiting])
    {
        //正在等待播放
    }
    else if ([audioStreamer isPlaying])
    {
        //正在播放
    }
    else if ([audioStreamer isIdle])
    {
        
        [self destroyStreamer];
        for (int index = 0; index < self.arrStMyMusicWorkInfo.count; index ++) {
            UIButton *button =(UIButton *)[self viewWithTag:300 + index];
            button.selected = NO;
            
        }
        
        
    }
}
#pragma mark - 销毁播放器
- (void)destroyStreamer
{
    if (audioStreamer)
    {
        [audioStreamer stop];
        audioStreamer = nil;
        [ListenToMeData getInstance].currentMusicAudition = nil;
    }
}





#pragma mark -暂停
-(void)pause{
    [audioStreamer pause];
    
}

#pragma mark -停止
-(void)stop{
    [audioStreamer stop];
    audioStreamer = nil;
}

#pragma mark - 数据处理
-(void)setArrStMyMusicWorkInfo:(NSArray *)arrStMyMusicWorkInfo{
    
    if (arrStMyMusicWorkInfo != nil) {
        _arrStMyMusicWorkInfo = arrStMyMusicWorkInfo;
        
        
        for (int index = 0; index < _arrStMyMusicWorkInfo.count; index ++) {
            MusicWorkBaseInfo *musicWorkBaseInfo = _arrStMyMusicWorkInfo[index];
            UserBaseInfoNet *userBaseInfoNet = musicWorkBaseInfo.stUserBaseInfoNet;
            SongInfo *songInfo = musicWorkBaseInfo.stSongInfo;
//            CommentInfo *commentInfo = musicWorkBaseInfo.stCommentInfo;
            
            
//            UIButton *singerBtn = (UIButton *)[self viewWithTag:100 + index];
            UIImageView *singerImgView = (UIImageView *)[self viewWithTag:200 + index];
//            UIButton *playBtn = (UIButton *)[self viewWithTag:300 + index];
            UILabel *lbSongName = (UILabel *)[self viewWithTag:400 + index];
            HWImageAndLabel *btnFlower = (HWImageAndLabel *)[self viewWithTag:500 + index];
            HWImageAndLabel *btnListenNum = (HWImageAndLabel *)[self viewWithTag:600 + index];
            
            [singerImgView sd_setImageWithURL:[NSURL URLWithString:userBaseInfoNet.sCovver]];
            lbSongName.text = songInfo.sSongName;

            btnFlower.number = [NSString stringWithFormat:@"%d",musicWorkBaseInfo.stUserBaseInfoNet.iFlowerNum ];
            btnListenNum.number =[NSString stringWithFormat:@"%d",musicWorkBaseInfo.iListenNum];
            
//            //判断当前是否有音乐在播放,该音乐是否在当前页面,若果在,那么就将改音乐的播放按键状态设置为选中状态
//            UIButton *playBtn = (UIButton *)[self viewWithTag:index + 300];
//            if (musicWorkBaseInfo.lMusicWorkId == [ListenToMeData getInstance].currentMusicAudition.lMusicWorkId) {
//                playBtn.selected = YES;
//            }else{
//                playBtn.selected = NO;
//            }
//            
        }
        
        
    }
    
}
-(void)dealloc{
    
    [[NSNotificationCenter defaultCenter]
     removeObserver:self
     name:ASStatusChangedNotification
     object:audioStreamer];
    [self destroyStreamer];
    
    
}
@end
