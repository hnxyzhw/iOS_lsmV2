//
//  HWKTVHotSongCell.h
//  ListenToMe
//
//  Created by yadong on 15/4/2.
//  Copyright (c) 2015年 listentome. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol HWKTVHotSongCellDelegate <NSObject>
/**
 *  进入他人主页
 */
-(void)viewOthersHomePage:(UserBaseInfoNet *)userBaseInfoNet;

@end

@interface HWKTVHotSongCell : UITableViewCell
@property(nonatomic,assign)id<HWKTVHotSongCellDelegate>delegate;
/**
 *  初始化
 */
+(instancetype)cellWithTableView:(UITableView *)tableView;
/**
 *  更多KTV热歌
 */
@property(strong,nonatomic) UIButton * btnMore;

/**
 *  定义一个数组用来存放单曲正在K歌的人
 */
@property(strong,nonatomic)NSMutableArray *arrHotSong;
/**
 *  KTV热歌数据
 */
@property(strong,nonatomic)NSArray *arrStMyMusicWorkInfo;
@end
