//
//  KStoreMemoryVC.h
//  ListenToMe
//
//  Created by zhw on 15/7/1.
//  Copyright (c) 2015年 listentome. All rights reserved.
//

#import "YDBaseVC.h"

@interface KStoreMemoryVC : YDBaseVC
/**
 *  K店回忆,数据源数组
 */
@property(nonatomic,strong) NSMutableArray *kStoreMemoryDataArr;
/**
 *  KTV的ID
 */
@property(nonatomic,assign) int64_t lKtvId;
@end
