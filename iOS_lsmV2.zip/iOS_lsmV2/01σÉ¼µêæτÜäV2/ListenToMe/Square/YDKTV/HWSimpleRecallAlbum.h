//
//  HWSimpleRecallAlbum.h
//  ListenToMe
//
//  Created by zhw on 15/6/19.
//  Copyright (c) 2015年 listentome. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HWImageAndLabel.h"
@interface HWSimpleRecallAlbum : UIView
/**
 * 封面,三期增加的纪念册
 */
@property(strong,nonatomic) UIImageView *imgCover;
/**
 * 聚会名
 */
@property(strong,nonatomic) UILabel *lbPartyName;

/**
 * 歌曲名
 */
@property(strong,nonatomic) UILabel *lbMusicName;
/**
 * 聚会主题
 */
@property(strong,nonatomic) UILabel *lbTheme;
/**
 * 聚会主题图片标识
 */
@property(strong,nonatomic) UIImageView *imgTheme;
/**
 * 歌曲数目
 */
@property(strong,nonatomic) UIButton *btnNumSongs;
/**
 * 聚会照片数目
 */
@property(strong,nonatomic) UIButton *btnNumAlbums;
/**
 * 聚会查看数目
 */
@property(strong,nonatomic) UIButton *btnNumSee;
/**
 * 聚会送花数目
 */
@property(strong,nonatomic) UIButton *btnNumFlower;
/**
 *  纪念册的制作者的头像
 */
@property(strong,nonatomic) UIImageView *imgMemoryMaker;
/**
 *  纪念册的标签01
 */
@property(strong,nonatomic) UIButton *btnMemoryLabel_01;
/**
 *  纪念册的标签02
 */
@property(strong,nonatomic) UIButton *btnMemoryLabel_02;
/**
 *  纪念册的标签03
 */
@property(strong,nonatomic) UIButton *btnMemoryLabel_03;
/**
 *  纪念册收录歌曲数
 */
@property(strong,nonatomic) HWImageAndLabel *numSongs;
/**
 *  纪念册收录照片数
 */
@property(strong,nonatomic) HWImageAndLabel *numAlbums;
/**
 *  纪念册查看数
 */
@property(strong,nonatomic) HWImageAndLabel *numSee;
/**
 *  送花数
 */
@property(strong,nonatomic) HWImageAndLabel *numFlowers;
@end
