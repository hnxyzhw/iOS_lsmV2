//
//  HWImageAndLabel.h
//  ListenToMe
//
//  Created by zhw on 15/6/17.
//  Copyright (c) 2015年 listentome. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HWImageAndLabel : UIView
/**
 *  要显示的图片的名字
 */
@property(nonatomic,strong)NSString *imgName;
/**
 *  要显示的数字
 */
@property(nonatomic,strong)NSString *number;
/**
 *  要显示的文本的颜色
 */
@property(nonatomic,strong)UIColor *numberColor;
/**
 *  左侧图标的frame
 */
@property(nonatomic,assign) CGRect leftIconFrame;
/**
 *  右侧label的frame
 */
@property(nonatomic,assign) CGRect rightLabFrame;
@end
