//
//  HWSimpleRecallAlbum.m
//  ListenToMe
//
//  Created by zhw on 15/6/19.
//  Copyright (c) 2015年 listentome. All rights reserved.
//

#import "HWSimpleRecallAlbum.h"

@implementation HWSimpleRecallAlbum

-(id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [self setUI];
    }
    return self;
}

-(void)setUI{
    
    self.backgroundColor = [UIColor whiteColor];
    
    CGFloat frontX = 15;
    // 聚会封面图片
    CGFloat imgCover_X = 0;
    CGFloat imgCover_Y = 0;
    CGFloat imgCover_W = screenWidth - frontX * 2;
    CGFloat imgCover_H = 150;
    _imgCover = [[UIImageView alloc]initWithFrame:CGRectMake(imgCover_X, imgCover_Y, imgCover_W, imgCover_H)];
    _imgCover.contentMode = UIViewContentModeScaleToFill;
    _imgCover.image = [UIImage imageNamed:@"temp5.png"];
    [self addSubview:_imgCover];
    
    // 聚会主题lb
    CGFloat lbTheme_X = _imgCover.width - frontX - 50;
    CGFloat lbTheme_Y = 10;
    CGFloat lbTheme_W = 50;
    CGFloat lbTheme_H = 25;
    _lbTheme = [[UILabel alloc]initWithFrame:CGRectMake(lbTheme_X, lbTheme_Y, lbTheme_W, lbTheme_H)];
    _lbTheme.font = [UIFont systemFontOfSize:12.0];
    _lbTheme.textColor = [UIColor whiteColor];
    _lbTheme.textAlignment = NSTextAlignmentRight;
    _lbTheme.text = @"闺密秀";
    [_imgCover addSubview:_lbTheme];
    
    
    // 聚会主题img
    CGFloat imgTheme_W = 21;
    CGFloat imgTheme_H = 22;
    CGFloat imgTheme_X = _lbTheme.x - imgTheme_W - 6;
    CGFloat imgTheme_Y = _lbTheme.y + 5;
    _imgTheme = [[UIImageView alloc]initWithFrame:CGRectMake(imgTheme_X, imgTheme_Y, imgTheme_W, imgTheme_H)];
    _imgTheme.image = [UIImage imageNamed:@"memoryTopShow.png"];
    [_imgCover addSubview:_imgTheme];
    
    // 白色横线
    UIImageView *whiteLineImg = [[UIImageView alloc]initWithFrame:CGRectMake(_lbTheme.x, _lbTheme.y + _lbTheme.height, _lbTheme.width, 1)];
    whiteLineImg.backgroundColor = [UIColor whiteColor];
    [_imgCover addSubview:whiteLineImg];
    
    //纪念册的标签,标签一,标签二,标签三
    CGFloat btnMemoryLabel_W = 50 + frontX;
    CGFloat btnMemoryLabel_H = 20;
    CGFloat btnMemoryLabel_X = _imgCover.width - btnMemoryLabel_W;
    CGFloat btnMemoryLabel_Y = whiteLineImg.y + whiteLineImg.height + 10;
    
    //标签一
    _btnMemoryLabel_01 =[[UIButton alloc]initWithFrame:CGRectMake(btnMemoryLabel_X, btnMemoryLabel_Y, btnMemoryLabel_W, btnMemoryLabel_H)];
    _btnMemoryLabel_01.backgroundColor = [UIColor whiteColor];
    _btnMemoryLabel_01.layer.masksToBounds = YES;
    _btnMemoryLabel_01.layer.cornerRadius = 8;
    [_btnMemoryLabel_01 setTitle:@"标签一" forState:UIControlStateNormal];
    [_btnMemoryLabel_01 setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnMemoryLabel_01.titleLabel setFont:[UIFont systemFontOfSize:8.0]];
    [_imgCover addSubview:_btnMemoryLabel_01];
    
    
    //标签二
    
    _btnMemoryLabel_02 =[[UIButton alloc]initWithFrame:CGRectMake(btnMemoryLabel_X, btnMemoryLabel_Y + 20 + 10, btnMemoryLabel_W, btnMemoryLabel_H)];
    _btnMemoryLabel_02.backgroundColor = [UIColor whiteColor];
    _btnMemoryLabel_02.layer.masksToBounds = YES;
    _btnMemoryLabel_02.layer.cornerRadius = 8;
    [_btnMemoryLabel_02 setTitle:@"标签二" forState:UIControlStateNormal];
    [_btnMemoryLabel_02 setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnMemoryLabel_02.titleLabel setFont:[UIFont systemFontOfSize:8.0]];
    [_imgCover addSubview:_btnMemoryLabel_02];
    
    //标签三
    _btnMemoryLabel_03 =[[UIButton alloc]initWithFrame:CGRectMake(btnMemoryLabel_X, btnMemoryLabel_Y + ( 20 + 10) * 2, btnMemoryLabel_W, btnMemoryLabel_H)];
    _btnMemoryLabel_03.backgroundColor = [UIColor whiteColor];
    _btnMemoryLabel_03.layer.masksToBounds = YES;
    _btnMemoryLabel_03.layer.cornerRadius = 8;
    [_btnMemoryLabel_03 setTitle:@"标签三" forState:UIControlStateNormal];
    [_btnMemoryLabel_03 setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnMemoryLabel_03.titleLabel setFont:[UIFont systemFontOfSize:8.0]];
    [_imgCover addSubview:_btnMemoryLabel_03];
    
    // 聚会名字
    CGFloat lbPartyName_H = 17;
    CGFloat lbPartyName_W = _imgCover.width;
    CGFloat lbPartyName_X = 0;
    CGFloat lbPartyName_Y = (_imgCover.height - lbPartyName_H) * 0.5;
    
    _lbPartyName = [[UILabel alloc]initWithFrame:CGRectMake(lbPartyName_X, lbPartyName_Y, lbPartyName_W, lbPartyName_H)];
    _lbPartyName.font = [UIFont systemFontOfSize:15.0];
    _lbPartyName.textColor = [UIColor whiteColor];
    _lbPartyName.textAlignment = NSTextAlignmentCenter;
    _lbPartyName.text = @"咸蛋超人的生日趴";
    [_imgCover addSubview:_lbPartyName];
    
    //纪念册制作者的头像
    CGFloat imgMemeoryMaker_W_H = 30;
    CGFloat imgMemoryMaker_X = 0;
    CGFloat imgMemoryMaker_Y = _imgCover.height - imgMemeoryMaker_W_H;
    _imgMemoryMaker = [[UIImageView alloc]initWithFrame:CGRectMake(imgMemoryMaker_X, imgMemoryMaker_Y, imgMemeoryMaker_W_H, imgMemeoryMaker_W_H)];
    _imgMemoryMaker.image = [UIImage imageNamed:@"temp2.png"];
    [_imgCover addSubview:_imgMemoryMaker];
    
    //歌曲数 相片数 查看数 送花
    // 多个数目btn
    CGFloat btnsH = 30; // 这一行btn视图的高度
    CGFloat btnsW = 57;
    
    //歌曲数
    //        UIImage *btnNumSongsImg = [UIImage imageNamed:@"作品2.png"];
    CGFloat btnNumSongs_X = frontX;
    CGFloat btnNumSongs_Y = _imgCover.y + _imgCover.height + 0.5 * (btnsH - 15);
    //        CGFloat btnNumSongs_W = btnsW;
    //        CGFloat btnNumSongS_H = 15;//btnNumSongsImg.size.height * 0.5;
    
    
    _numSongs = [[HWImageAndLabel alloc]initWithFrame:CGRectMake(btnNumSongs_X, btnNumSongs_Y, 45, 15)];
    _numSongs.leftIconFrame = CGRectMake(0, 0, 15, 15);
    _numSongs.imgName = @"作品2.png";
    _numSongs.rightLabFrame = CGRectMake(15, 0, 30, 15);
    _numSongs.number = @"128";
    _numSongs.numberColor = [UIColor rgbFromHexString:@"#A8AEAE" alpaa:1.0];
    [self addSubview:_numSongs];
    
    _numAlbums = [[HWImageAndLabel alloc]initWithFrame:CGRectMake(btnNumSongs_X + btnsW, btnNumSongs_Y, 45, 15)];
    _numAlbums.leftIconFrame = CGRectMake(0, 0, 15, 15);
    _numAlbums.imgName = @"btnMemoryAlbum.png";
    _numAlbums.rightLabFrame = CGRectMake(15, 0, 30, 15);
    _numAlbums.number = @"24";
    _numAlbums.numberColor = [UIColor rgbFromHexString:@"#A8AEAE" alpaa:1.0];
    [self addSubview:_numAlbums];
    
    _numSee = [[HWImageAndLabel alloc]initWithFrame:CGRectMake(btnNumSongs_X + btnsW * 2, btnNumSongs_Y, 45, 15)];
    _numSee.leftIconFrame = CGRectMake(0, 0, 15, 15);
    _numSee.imgName = @"btnMemorySee.png";
    _numSee.rightLabFrame = CGRectMake(15, 0, 30, 15);
    _numSee.number = @"20";
    _numSee.numberColor = [UIColor rgbFromHexString:@"#A8AEAE" alpaa:1.0];
    [self addSubview:_numSee];
    
    _numFlowers = [[HWImageAndLabel alloc]initWithFrame:CGRectMake(btnNumSongs_X + btnsW * 3, btnNumSongs_Y, 45, 15)];
    _numFlowers.leftIconFrame = CGRectMake(0, 0, 10, 15);
    _numFlowers.imgName = @"送花数量.png";
    _numFlowers.rightLabFrame = CGRectMake(10, 0, _numFlowers.width - 10, 15);
    _numFlowers.number = @"114";
    _numFlowers.numberColor = [UIColor rgbFromHexString:@"#FF0053" alpaa:1.0];
    [self addSubview:_numFlowers];
    
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
