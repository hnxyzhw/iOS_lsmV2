//
//  ZHWProgressImageView.m
//  ListenToMe
//
//  Created by zhw on 15/6/16.
//  Copyright (c) 2015年 listentome. All rights reserved.
//

#import "ZHWProgressImageView.h"


/**
 *  添加一个UIImage的类目
 */
@interface UIImage (Grayscale)
/**
 *  创建一个显示图像
 *
 *  @param percentage 定义了要显示图像的起始位置
 *  @param vertical      如果是yes,图像将会从下向上显示,如果为no,那么图像将会从左向右显示
 *  @param grayscaleRest 如果是yes,那么未未绘制的部分将会显示为灰色,如果为no,就不会显示未绘制的那一部分
 *
 *  @return 返回一个初始化好的UIImage
 */
-(UIImage *) partialImageWithPercentage:(float)percentage vertical:(BOOL)vertical grayscaleRest:(BOOL)grayscaleRest;
@end

@implementation UIImage (Grayscale)
/**
 *  代码参考来源: http://stackoverflow.com/questions/1298867/convert-image-to-grayscale
 */
-(UIImage *)partialImageWithPercentage:(float)percentage vertical:(BOOL)vertical grayscaleRest:(BOOL)grayscaleRest{

    const int ALPHA = 0; //透明度
    const int RED = 1; //红色
    const int GREEN = 2; //绿色
    const int BLUE = 3; //蓝色
    
    //创建 Image 的frame
    
    CGRect imageRect = CGRectMake(0, 0, self.size.width * self.scale, self.size.height * self.scale);
    
    int width = imageRect.size.width;
    int height = imageRect.size.height;
    
    //绘图是的像素点将会绘一组数据
    
    uint32_t *pixels = (uint32_t *) malloc(width  * height * sizeof(uint32_t));
    
    //清除像素点,所以就会变成透明的效果
    memset(pixels, 0, width * height * sizeof(uint32_t));
    
    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
    
    //创建一个上下文context 用来存放 像素点
    CGContextRef context = CGBitmapContextCreate(pixels, width, height, 8, width * sizeof(uint32_t), colorSpace, kCGBitmapByteOrder32Little | kCGImageAlphaPremultipliedLast);
    
    //绘制这些像素点到上上下文中,这些像素将会填充到视图上
    CGContextDrawImage(context, CGRectMake(0, 0, width, height), [self CGImage]);
    
    int x_origin = vertical ? 0 : width * percentage; //X方向起点
    int y_to = vertical ? height * (1.f - percentage) : height; //Y方向的终点
    
    for (int y = 0; y < y_to;y++ ) {
        for (int x = x_origin; x < width; x++) {
            uint8_t *rgbaPixel = (uint8_t *) &pixels[y * width + x];
            
            if (grayscaleRest) {
                //参考绘制灰色背景的来源和方法 :  http://en.wikipedia.org/wiki/Grayscale#Converting_color_to_grayscale
                uint32_t gray = 0.3 * rgbaPixel[RED] + 0.59 * rgbaPixel[GREEN] + 0.11 * rgbaPixel[BLUE];
                
                //设置像素点到数组中
                rgbaPixel[RED] = gray;
                rgbaPixel[GREEN] = gray;
                rgbaPixel[BLUE] = gray;
            }else{
                rgbaPixel[ALPHA] = 0;
                rgbaPixel[RED] = 0;
                rgbaPixel[GREEN] = 0;
                rgbaPixel[BLUE] = 0;
            
            }
        }
    }
    
    
    //创建一个新的 CGImageRef 根据我们的上下文取得的颜色值
    CGImageRef image = CGBitmapContextCreateImage(context);
    
    //处理
    CGContextRelease(context);
    CGColorSpaceRelease(colorSpace);
    free(pixels);
    
    //创建一个新的UIImage,并返回
    UIImage *resultUIImage = [UIImage imageWithCGImage:image
                                                 scale:self.scale
                                           orientation:UIImageOrientationUp];
    
    //处理
    CGImageRelease(image);
    return resultUIImage;
    
    
    
//    const int ALPHA = 0;
//    const int RED = 1;
//    const int GREEN = 2;
//    const int BLUE = 3;
//    
//    // Create image rectangle with current image width/height
//    CGRect imageRect = CGRectMake(0, 0, self.size.width * self.scale, self.size.height * self.scale);
//    
//    int width = imageRect.size.width;
//    int height = imageRect.size.height;
//    
//    // the pixels will be painted to this array
//    uint32_t *pixels = (uint32_t *) malloc(width * height * sizeof(uint32_t));
//    
//    // clear the pixels so any transparency is preserved
//    memset(pixels, 0, width * height * sizeof(uint32_t));
//    
//    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
//    
//    // create a context with RGBA pixels
//    CGContextRef context = CGBitmapContextCreate(pixels, width, height, 8, width * sizeof(uint32_t), colorSpace,
//                                                 kCGBitmapByteOrder32Little | kCGImageAlphaPremultipliedLast);
//    
//    // paint the bitmap to our context which will fill in the pixels array
//    CGContextDrawImage(context, CGRectMake(0, 0, width, height), [self CGImage]);
//    
//    int x_origin = vertical ? 0 : width * percentage;
//    int y_to = vertical ? height * (1.f -percentage) : height;
//    
//    for(int y = 0; y < y_to; y++) {
//        for(int x = x_origin; x < width; x++) {
//            uint8_t *rgbaPixel = (uint8_t *) &pixels[y * width + x];
//            
//            if (grayscaleRest) {
//                // convert to grayscale using recommended method: http://en.wikipedia.org/wiki/Grayscale#Converting_color_to_grayscale
//                uint32_t gray = 0.3 * rgbaPixel[RED] + 0.59 * rgbaPixel[GREEN] + 0.11 * rgbaPixel[BLUE];
//                
//                // set the pixels to gray
//                rgbaPixel[RED] = gray;
//                rgbaPixel[GREEN] = gray;
//                rgbaPixel[BLUE] = gray;
//            }
//            else {
//                rgbaPixel[ALPHA] = 0;
//                rgbaPixel[RED] = 0;
//                rgbaPixel[GREEN] = 0;
//                rgbaPixel[BLUE] = 0;
//            }
//        }
//    }
//    
//    // create a new CGImageRef from our context with the modified pixels
//    CGImageRef image = CGBitmapContextCreateImage(context);
//    
//    // we're done with the context, color space, and pixels
//    CGContextRelease(context);
//    CGColorSpaceRelease(colorSpace);
//    free(pixels);
//    
//    // make a new UIImage to return
//    UIImage *resultUIImage = [UIImage imageWithCGImage:image
//                                                 scale:self.scale
//                                           orientation:UIImageOrientationUp];
//    
//    // we're done with image now too
//    CGImageRelease(image);
//    
//    return resultUIImage;
}


@end


/**
 *  自定义的进度条
 */
@interface ZHWProgressImageView ()
/**
 *  自定义初始化UI
 */
-(void)commonInit;
/**
 *  实时更新绘制图片
 */
-(void)updateDrawing;
@end

@implementation ZHWProgressImageView
@synthesize progress = _progress;
@synthesize hasGrayscaleBackground = _hasGrayscaleBackground;
@synthesize verticalProgress = _verticalProgress;


#pragma mark - UIView lifecycle,视图的生命周期

-(void)dealloc{
    //消除是要讲图片置为空
    _origineImage = nil;
}

-(id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    
    if (self) {
        [self commonInit];
    }
    return self;
}

-(id)initWithCoder:(NSCoder *)aDecoder{
    self = [super initWithCoder:aDecoder];
    if (self) {
        [self commonInit];
    }
    return self;
}

-(void)commonInit{
    //初始化视图
    _progress = 0.f;
    //默认显示背景灰色
    _hasGrayscaleBackground = YES;
    //默认是否是垂直方向显示进度
    _verticalProgress = YES;
    
    //设置图像源
    _origineImage = self.image;
}

#pragma mark - 自定义相关属性的遍历构造器
-(void)setImage:(UIImage *)image{
    [super setImage:image];
    if (!_internalUpdating) {
        _origineImage = image;
        [self updateDrawing];
        
    }
    
    _internalUpdating = NO;
}

-(void)setProgress:(float)progress{
    _progress = MIN(MAX(0.f, progress), 1.f);
    [self updateDrawing];
}

-(void)setHasGrayscaleBackground:(BOOL)hasGrayscaleBackground{
    _hasGrayscaleBackground = hasGrayscaleBackground;
    
    [self updateDrawing];
}

-(void)setVerticalProgress:(BOOL)verticalProgress{
    _verticalProgress = verticalProgress;
    [self updateDrawing];
}

#pragma mark - 绘制图片
-(void)updateDrawing{
    _internalUpdating = YES;
    self.image = [_origineImage partialImageWithPercentage:_progress vertical:_verticalProgress grayscaleRest:_hasGrayscaleBackground];
}







/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
