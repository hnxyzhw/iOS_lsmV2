//
//  ZHWProgressImageView.h
//  ListenToMe
//
//  Created by zhw on 15/6/16.
//  Copyright (c) 2015年 listentome. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZHWProgressImageView : UIImageView
{
    UIImage *_origineImage;//进度条的背景图片
    BOOL _internalUpdating;//是否刷新图片
}
/**
 *  进度条的当前进度,默认为0.0,进度条会按照该值去绘制当前前景图
 */
@property(nonatomic,assign) float progress;
/**
 *  是否开启灰色背景,默认是yes.背景色是按照背景图片绘制,但颜色为灰色.如果为no,那么就不会有灰色的背景图片显示
 */
@property(nonatomic,assign) BOOL hasGrayscaleBackground;
/**
 *  默认为yes,绘制进度条时是从下往上绘制,如果为no,那么绘制进度条将会从左至右开始绘制
 */
@property(nonatomic,getter= isVerticalProgress) BOOL verticalProgress;
@end
