//
//  KStoreMemoryVC.m
//  ListenToMe
//
//  Created by zhw on 15/7/1.
//  Copyright (c) 2015年 listentome. All rights reserved.
//

#import "KStoreMemoryVC.h"
#import "LoadDataView.h"
#import "YDTopListCell.h"
#import "YDKMemmoryCell.h"
#import "FriendsMsgVC.h"
#import "HWShareAlertVC.h"
#import "GivingFlowerView.h"
#import "HWMusicPlayVC.h"
#import <MediaPlayer/MediaPlayer.h>


@interface KStoreMemoryVC ()<UITableViewDataSource,UITableViewDelegate,YDTopLiseCellDelegate,STKAudioPlayerDelegate>
{
    STKAudioPlayer *audioPlayer;
}
@property(nonatomic,strong) UITableView *tableView;
/**
 *  数据源
 */
@property(nonatomic,strong) ListenToMeData *listenToMeData;
/**
 *  数据加载过渡动画
 */
@property(nonatomic,strong) LoadDataView *loadDataView;
/**
 *  分享弹窗
 */
@property(nonatomic,strong) HWShareAlertVC *shareVC;
/**
 *  遮盖视图
 */
@property(strong,nonatomic) UIView *coverView;
/**
 *  送鲜花弹窗背景
 */
//@property(strong,nonatomic) UIButton *alertForGivingFlower;
/**
 *  送花
 */
@property(strong,nonatomic) GivingFlowerView *sendFlowerView;

/**
 *  默认送出鲜花数
 */
@property(assign,nonatomic) int sendFlowerNum;
/**
 *  用户拥有的鲜花数
 */
@property(assign,nonatomic) NSInteger haveFlowerNum;
/**
 *  送花给某个人
 */
@property(nonatomic,strong) UserBaseInfoNet *sendToUserBaseInfoNet;
@end

@implementation KStoreMemoryVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    //自定义顶部导航栏
    [self customizedBarItem];
    
    //UI设置
    [self setUI];
    
    //添加一个向右的侧滑的手势
    [self addRightSwipeGestures];
    
    //数据加载过渡动画
    [self setLoaddataGif];
    
    [self initData];
}

#pragma mark -customNavigationBar
-(void)customizedBarItem{
    
    [self setLeftBtnItem];
    
    
}
#pragma mark - 设置左边的BarItem
-(void)setLeftBtnItem{
    
    UIButton *customButton = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, 100, 41)];
    customButton.backgroundColor = [UIColor clearColor];
    [customButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    customButton.titleLabel.font = [UIFont systemFontOfSize:16.5];
    customButton.titleLabel.textAlignment = NSTextAlignmentCenter;
    [customButton setTitle:@"K店回忆" forState:UIControlStateNormal];
    self.navigationItem.titleView = customButton;
    
    UIButton *leftBtn = [[UIButton alloc]init];
    UIImage *leftBtnImg = [UIImage imageNamed:@"whiteBack.png"];
    leftBtn.frame = CGRectMake(0, 0, leftBtnImg.size.width, leftBtnImg.size.height);
    [leftBtn setImage:leftBtnImg forState:UIControlStateNormal];
    [leftBtn addTarget:self action:@selector(clickLeftBarBtnItem:) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *customLeftBtnItem = [[UIBarButtonItem alloc]initWithCustomView:leftBtn];
    self.navigationItem.leftBarButtonItem = customLeftBtnItem;
}

#pragma mark - BarItem的点击事件处理
-(void)clickLeftBarBtnItem:(UIButton *)backBtn
{
    [self.navigationController popViewControllerAnimated:YES];
    
}


#pragma mark - addRightSwipeGestures添加向右侧滑手势
-(void)addRightSwipeGestures{
    UISwipeGestureRecognizer *rightSwipeGestureRecognizer = [[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(handleSwipes:)];
    rightSwipeGestureRecognizer.direction = UISwipeGestureRecognizerDirectionRight;
    [self.view addGestureRecognizer:rightSwipeGestureRecognizer];
}

-(void)handleSwipes:(UISwipeGestureRecognizer *)sender{
    if (UISwipeGestureRecognizerDirectionRight == sender.direction) {
        [self.navigationController popViewControllerAnimated:YES];
    }
}

#pragma mark - setLoaddataGif
-(void)setLoaddataGif{
    if (!self.loadDataView) {
        CGRect loadDataFrame = CGRectMake(0, naviAndStatusH, screenWidth, screenHeight - naviAndStatusH);
        self.loadDataView =[[LoadDataView alloc]initWithFrame:loadDataFrame];
    }
    
    //    [[[UIApplication sharedApplication]keyWindow] addSubview:self.loadDataView];
    [self.view addSubview:self.loadDataView];
}

//动画消失
-(void)dismissLoadDataView{
    [self.loadDataView removeFromSuperview];
}

#pragma mark - setUI
-(void)setUI{
    //设置导航栏
    
    
    //设置TableView
    self.tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, screenWidth, self.view.frame.size.height) style:UITableViewStylePlain];
    self.tableView.backgroundColor = [UIColor rgbFromHexString:@"#F1F1F1" alpaa:1.0];
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    self.tableView.showsVerticalScrollIndicator = NO;
    self.tableView.bounces = YES;
    [self.view addSubview:self.tableView];
    
    [self.tableView registerClass:[YDTopListCell class] forCellReuseIdentifier:@"MuscWorkCell"];
    [self.tableView registerClass:[YDKMemmoryCell class] forCellReuseIdentifier:@"KMemoryCell"];
}

#pragma mark - initData 初始化数据
-(void)initData{
    self.listenToMeData = [ListenToMeData getInstance];
    
    if (!audioPlayer) {
        audioPlayer = self.listenToMeData.audioPlayer;
        //设置代理,监听播放的状态,通过播放器状态来切歌
        audioPlayer.delegate = self;
    }
    
    
    self.kStoreMemoryDataArr = [NSMutableArray array];
    
    //通过KTV ID,发送KTV热歌数据的请求
    [[NetReqManager getInstance] sendGetKtvHostMusicList:self.lKtvId IOffset:0 INum:6];
    
#warning  后台回包暂时没有任何数据,暂时使用之前的纪念册列表请求代替
    [[NetReqManager getInstance] sendGetKtvCommemorativeList:self.lKtvId IOffset:0 INum:2];
    //暂时使用之前的纪念册列表请求代替
//    [[NetReqManager getInstance] sendGetCommemorateInfo:0 IOffset:0 INum:2];
    
    //ktv跟多热歌
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshData) name:NOTIFY_GET_KTVHOSTMUSICLIST_PAGE_RESP object:nil];
    
    //更多ktv纪念册
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshData) name:NOTIFY_GET_KTVCOMMEMORATIVELIST_PAGE_RESP object:nil];
    
    //暂时使用,二期获取临时纪念册
//    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshData) name:NOTIFY_GET_COMMEMORATEINFO_PAGE_RESP object:nil];
    
    //给人送花
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(sendFlowerSuccess) name:NOTIFY_GET_SEND_USERFLOWER_PAGE_RESP object:nil];
    
    //在线试听音乐回包的通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshTable) name:NOTIFY_GET_MUSIC_AUDITION_PAGE_RESP object:nil];
}

-(void)refreshTable{
    [self.tableView reloadData];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    [self.tableView reloadData];
    //远程控制时间接收与处理
    [[UIApplication sharedApplication] beginReceivingRemoteControlEvents];
    [self becomeFirstResponder];
}

-(void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:animated];
    
    [[UIApplication sharedApplication] endReceivingRemoteControlEvents];
    [self resignFirstResponder];
}

-(void)dealloc{
    //移除通知
    [[NSNotificationCenter defaultCenter] removeObserver:self name:NOTIFY_GET_KTVHOSTMUSICLIST_PAGE_RESP object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:NOTIFY_GET_KTVCOMMEMORATIVELIST_PAGE_RESP object:nil];
//    [[NSNotificationCenter defaultCenter] removeObserver:self name:NOTIFY_GET_COMMEMORATEINFO_PAGE_RESP object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:NOTIFY_GET_SEND_USERFLOWER_PAGE_RESP object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:NOTIFY_GET_MUSIC_AUDITION_PAGE_RESP object:nil];
    
    self.kStoreMemoryDataArr = nil;
    self.lKtvId = 0;
    audioPlayer = nil;
}

-(void)sendFlowerSuccess{
    //送花成功,重新设置当前收花人的花的数量
    YDLog(@"送花成功后需要刷新收花人多收花数目");
//    [self.btnFlowerNum setTitle:[NSString stringWithFormat:@"%d",self.musicWorkBaseInfo.stUserBaseInfoNet.iFlowerNum + self.sendFlowerNum] forState:UIControlStateNormal];
    
}

#pragma mark - 获取数据后刷新界面
-(void)refreshData{
    
    //self.listenToMeData.arrKtvCommemorativeList.count,使用之前K歌回忆里面的纪念册请求的数据
    if ((self.listenToMeData.arrKtvHostMusicList.count == 6) && (self.listenToMeData.arrKtvCommemorativeList.count == 2)) {
        for (int index1 = 0; index1 < 2; index1 ++) {
            CommemorateBaseInfo *commemorateBaseInfo =self.listenToMeData.arrKtvCommemorativeList[index1] ;//self.listenToMeData.arrKtvCommemorativeList[index1];
            if (index1 == 0) {
                for (int index2 = 0; index2 < 3; index2 ++) {
                    MusicWorkBaseInfo *musicWorkBaseInfo = self.listenToMeData.arrKtvHostMusicList[index2];
                    [self.kStoreMemoryDataArr addObject:musicWorkBaseInfo];
                }
                [self.kStoreMemoryDataArr addObject:commemorateBaseInfo];
            }
            
            if (index1 == 1) {
                for (int index3 = 3; index3 < 6; index3 ++) {
                    MusicWorkBaseInfo *musicWorkBaseInfo = self.listenToMeData.arrKtvHostMusicList[index3];
                    [self.kStoreMemoryDataArr addObject:musicWorkBaseInfo];
                }
                [self.kStoreMemoryDataArr addObject:commemorateBaseInfo];
            }
            
        }
    }
    
    if (self.kStoreMemoryDataArr.count >= 8) {
        [self.tableView reloadData];
        //移除数据加载动画
        [self dismissLoadDataView];
    }
    
    
}

#pragma mark - UITableViewDataSource,UITableViewDelegate
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    //3首歌曲一个纪念册为一个分区
//    return (self.listenToMeData.arrKtvHostMusicList.count  + (self.listenToMeData.arrKtvHostMusicList.count / 3));
    return 4;
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 2;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{

    if (indexPath.row < 3) {
        return 155;
    }else{
        return 273;
    }
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    if (section == 0) {
        return 0;
    }else{
        return 15;
    }
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    NSString *identifier = nil;
    
    switch (indexPath.row) {
        case 0:
        case 1:
        case 2:{
            identifier = @"MuscWorkCell";
        }
            break;
        case 3:{
            identifier = @"KMemoryCell";
        }
            break;
 
        default:
            break;
    }
    
    //利用多态
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    if (!cell) {
        cell = [[[NSBundle mainBundle]loadNibNamed:identifier owner:self options:nil] lastObject];
    }
    
    if (indexPath.row < 3 ) {
        YDTopListCell *topListCell = (YDTopListCell *)cell;
        topListCell.delegate = self;

        if (self.kStoreMemoryDataArr.count > 0 ) {

            MusicWorkBaseInfo *musicWorkBaseInfo = self.kStoreMemoryDataArr[indexPath.section * 4 + indexPath.row];
            
            UserBaseInfoNet *userBaseInfoNet = musicWorkBaseInfo.stUserBaseInfoNet;
            SongInfo *songInfo = musicWorkBaseInfo.stSongInfo;
            topListCell.musicWorkBaseInfo = musicWorkBaseInfo;
            topListCell.lbMusicName.text = songInfo.sSongName;
            topListCell.lbSinger.text = songInfo.sSongSinger;
            [topListCell.imgAvatar sd_setImageWithURL:[NSURL URLWithString:userBaseInfoNet.sCovver]];
            
            UIButton *btnAvatar = [[UIButton alloc]initWithFrame:topListCell.imgAvatar.frame];
            btnAvatar.backgroundColor = [UIColor clearColor];
            [topListCell.contentView addSubview:btnAvatar];
            [btnAvatar addTarget:self action:@selector(clickAvatar:) forControlEvents:UIControlEventTouchUpInside];
            
            
            [topListCell.btnSendingFlower addTarget:self action:@selector(sendingFlowers:) forControlEvents:UIControlEventTouchUpInside];
            [topListCell.btnShare addTarget:self action:@selector(alertForShare:) forControlEvents:UIControlEventTouchUpInside];
            
            
            topListCell.btnListener.number = [NSString stringWithFormat:@"%d",musicWorkBaseInfo.iListenNum];
            topListCell.btnFlower.number = [NSString stringWithFormat:@"%d",musicWorkBaseInfo.stUserBaseInfoNet.iFlowerNum];
            
            [topListCell.btnPlay addTarget:self action:@selector(playMusic:) forControlEvents:UIControlEventTouchUpInside];
            
            topListCell.btnPlay.selected = NO;
            
            //判断当前是否有音乐在播放,该音乐是否在当前页面,若果在,那么就将改音乐的播放按键状态设置为选中状态
            if ([ListenToMeData getInstance].currentMusicAudition) {
                
                if (musicWorkBaseInfo.lMusicWorkId == [ListenToMeData getInstance].currentMusicAudition.lMusicWorkId) {
                    YDLog(@"当前处于播放的cell是:%ld-%ld",indexPath.section,indexPath.row);
                    if (STKAudioPlayerStatePlaying == audioPlayer.state || STKAudioPlayerStateBuffering == audioPlayer.state) {
                        topListCell.btnPlay.selected = YES;
                    }else{
                        topListCell.btnPlay.selected = NO;
                    }
                }
                
            }

            
            
            
        }
        
    }else{
        
        YDKMemmoryCell *kMemmoryCell = (YDKMemmoryCell *)cell;
        
        if (self.kStoreMemoryDataArr.count > 0) {
            CommemorateBaseInfo *commemorateBaseInfo = self.kStoreMemoryDataArr[indexPath.section * 4 + indexPath.row];
            kMemmoryCell.arrUserBaseInfoNet = commemorateBaseInfo.stUserBaseInfoNet;
            
            if ([commemorateBaseInfo.sCommIcon isEqualToString:@""] || commemorateBaseInfo == nil) {
                
                kMemmoryCell.imgCover.image = [UIImage imageNamed:@"temp5.png"];
            }else{
                
                [kMemmoryCell.imgCover sd_setImageWithURL:[NSURL URLWithString:commemorateBaseInfo.sCommIcon]];
            }
            
            kMemmoryCell.lbTheme.text = @"闺蜜秀";
            
            if ([commemorateBaseInfo.sCommName isEqualToString:@""] || commemorateBaseInfo.sCommName == nil) {
                kMemmoryCell.lbPartyName.text = @"咸蛋超人的生日趴";
            }else{
                
                kMemmoryCell.lbPartyName.text = commemorateBaseInfo.sCommName;
            }
            
            if (commemorateBaseInfo.stLabelInfo) {
                switch (commemorateBaseInfo.stLabelInfo.count) {
                    case 1:
                         [kMemmoryCell.btnMemoryLabel_01 setTitle:((LabelInfo *)commemorateBaseInfo.stLabelInfo[0]).label forState:UIControlStateNormal];
                        kMemmoryCell.btnMemoryLabel_02.hidden = YES;
                        kMemmoryCell.btnMemoryLabel_03.hidden = YES;
                        break;
                    case 2:
                         [kMemmoryCell.btnMemoryLabel_01 setTitle:((LabelInfo *)commemorateBaseInfo.stLabelInfo[0]).label forState:UIControlStateNormal];
                         [kMemmoryCell.btnMemoryLabel_02 setTitle:((LabelInfo *)commemorateBaseInfo.stLabelInfo[1]).label forState:UIControlStateNormal];
                        kMemmoryCell.btnMemoryLabel_03.hidden = YES;
                        break;
                    case 3:
                         [kMemmoryCell.btnMemoryLabel_01 setTitle:((LabelInfo *)commemorateBaseInfo.stLabelInfo[0]).label forState:UIControlStateNormal];
                         [kMemmoryCell.btnMemoryLabel_02 setTitle:((LabelInfo *)commemorateBaseInfo.stLabelInfo[1]).label forState:UIControlStateNormal];
                         [kMemmoryCell.btnMemoryLabel_03 setTitle:((LabelInfo *)commemorateBaseInfo.stLabelInfo[2]).label forState:UIControlStateNormal];
                        
                        break;
                        
                    default:
                        kMemmoryCell.btnMemoryLabel_01.hidden = YES;
                        kMemmoryCell.btnMemoryLabel_02.hidden = YES;
                        kMemmoryCell.btnMemoryLabel_03.hidden = YES;
                        break;
                }
                
                
            }
            
            kMemmoryCell.imgTheme.image = [UIImage imageNamed:@"memoryTopShow.png"];
            [kMemmoryCell.imgMemoryMaker sd_setImageWithURL:[NSURL URLWithString:commemorateBaseInfo.stUser.sCovver] placeholderImage:[UIImage imageNamed:@"icon.png"]];
            
            kMemmoryCell.btnNumSongs.number = [NSString stringWithFormat:@"%d",commemorateBaseInfo.iMusicNum];
            kMemmoryCell.btnNumAlbums.number =[NSString stringWithFormat:@"%d",commemorateBaseInfo.iPictureNum];
            kMemmoryCell.btnNumSee.number = [NSString stringWithFormat:@"%d",commemorateBaseInfo.iWatchedNum];
            kMemmoryCell.btnNumFlower.number = [NSString stringWithFormat:@"%d",commemorateBaseInfo.stUser.iFlowerNum];
            
            [kMemmoryCell.btnActionFlowes addTarget:self action:@selector(sendingFlowers:) forControlEvents:UIControlEventTouchUpInside];
            [kMemmoryCell.btnActionShare addTarget:self action:@selector(alertForShare:) forControlEvents:UIControlEventTouchUpInside];

        }
        
    }
    
    
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.row < 3) {
        //选择音乐作品,跳入单曲播放页面
        MusicWorkBaseInfo *musicWorkBaseInfo = self.kStoreMemoryDataArr[indexPath.section * 4 + indexPath.row];
        
        
        HWMusicPlayVC *musicPlayVC =[HWMusicPlayVC shareHWMusicPlayVC];
        musicPlayVC.navigationItem.title = musicWorkBaseInfo.stSongInfo.sSongName;
        musicPlayVC.musicWorkBaseInfo = musicWorkBaseInfo;
        musicPlayVC.lWorkID = musicWorkBaseInfo.lMusicWorkId;
        [musicPlayVC playMusicwork:musicWorkBaseInfo];
        [self.navigationController pushViewController:musicPlayVC animated:YES];
    }
   
}


#pragma mark - 点击头像进入私聊
-(void)clickAvatar:(UIButton *)btnAvatar{
    
   
    
   //当前点击头像获取的cell,利用iOS中的多态原理,父类指针可以指向子类
    UITableViewCell *cell = (UITableViewCell *)[[btnAvatar superview] superview];
    //获取cell的indexPath的值
    NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];
    
    MusicWorkBaseInfo *musicWorkBaseInfo = self.kStoreMemoryDataArr[indexPath.section * 4 + indexPath.row];
    //进入私聊界面
    
    if (musicWorkBaseInfo.stUserBaseInfoNet.uuid == [ListenToMeDBManager getUuid]) {
        YDLog(@"自己不能跟自己聊天");
        return;
    }
     YDLog(@"与他人进行私聊");
    FriendsMsgVC *frienddMsgVC = [[FriendsMsgVC alloc]init];
    frienddMsgVC.friendUserBaseInfoNet = musicWorkBaseInfo.stUserBaseInfoNet;
    frienddMsgVC.navigationItem.title = musicWorkBaseInfo.stUserBaseInfoNet.sNick;
    [self.navigationController pushViewController:frienddMsgVC animated:YES];
   
}


#pragma mark - cell中点击分享提示分享平台
-(void)alertForShare:(UIButton *)btnShare{
    _shareVC = [[HWShareAlertVC alloc]init];
//    [[[UIApplication sharedApplication]keyWindow]addSubview:shareVC.view];
    
    [self.view addSubview:_shareVC.view];
    
    
}

#pragma mark - cell中点击送花弹出送花界面
-(void)sendingFlowers:(UIButton *)btnSendFlower{
    //当前点击头像获取的cell
    UITableViewCell *cell = (UITableViewCell *)[[btnSendFlower superview] superview];
    //获取cell的indexPath的值
    NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];
    if (indexPath.row < 3) {
        MusicWorkBaseInfo *musicWorkBaseInfo = self.kStoreMemoryDataArr[indexPath.section * 4 + indexPath.row];
        self.sendToUserBaseInfoNet = musicWorkBaseInfo.stUserBaseInfoNet;
    }else{
        CommemorateBaseInfo *commemorateBaseInfo = self.kStoreMemoryDataArr[indexPath.section * 4 + indexPath.row];
        self.sendToUserBaseInfoNet = commemorateBaseInfo.stUser;
    }
   
    
    //初始化遮盖视图
    self.coverView = [[UIView alloc]initWithFrame:[UIScreen mainScreen].bounds];
    self.coverView.backgroundColor = [UIColor clearColor];
    self.coverView.alpha  = 1.0;
    
    UIButton *alertForGivingFlower = [[UIButton alloc]initWithFrame:[UIScreen mainScreen].bounds];
    //    [self.alertForGift setBackgroundColor:[UIColor clearColor]];
    //    self.alertForGift.alpha = 1;
    alertForGivingFlower.backgroundColor = [UIColor blackColor];
    alertForGivingFlower.alpha = 0.3;
    [alertForGivingFlower addTarget:self action:@selector(backToView) forControlEvents:UIControlEventTouchUpInside];
    [self.coverView addSubview:alertForGivingFlower];
    //弹出遮盖视图
    [[[UIApplication sharedApplication]keyWindow] addSubview:self.coverView];
    
    
    CGFloat sendFW = self.coverView.width - 30;
    CGFloat sendFH = 285;
    CGFloat sendFX = 15;
    CGFloat sendFY = 190;
    
    //设置送花的数目
    self.sendFlowerNum = 0;
    self.haveFlowerNum = self.listenToMeData.stUserBaseInfoNet.iFlowerNum;
    
    self.sendFlowerView = [[GivingFlowerView alloc]init];
    self.sendFlowerView.frame = CGRectMake(sendFX, sendFY, sendFW, sendFH);
    //    self.sendFlowerView.receiveIcon = @"temp2.png";

    self.sendFlowerView.receiveIcon = self.sendToUserBaseInfoNet.sCovver;
    self.sendFlowerView.sendFlowerNum = self.sendFlowerNum;
    [self.sendFlowerView.btnGiveFlower addTarget:self action:@selector(sendFlowerHandle) forControlEvents:UIControlEventTouchUpInside];
    [self.sendFlowerView.btnSendFNum setTitle:[NSString stringWithFormat:@"%d",self.sendFlowerNum] forState:UIControlStateNormal];
    
    //设置颜色
    [self.sendFlowerView setLbTextForDifferentColor:self.sendFlowerView.lbRemain text:[NSString stringWithFormat:@"剩余%ld朵",(self.haveFlowerNum - self.sendFlowerNum)] rangeString:[NSString stringWithFormat:@"%ld",(self.haveFlowerNum - self.sendFlowerNum)] color:[UIColor rgbFromHexString:@"#FF0053" alpaa:1.0]];
    //减一
    [self.sendFlowerView.btnSubFNum addTarget:self action:@selector(subSendFNum) forControlEvents:UIControlEventTouchUpInside];
    //加一
    [self.sendFlowerView.btnAddFNum addTarget:self action:@selector(addSendFNum) forControlEvents:UIControlEventTouchUpInside];
    [self.coverView addSubview:self.sendFlowerView];
    
}

#pragma mark 送花 减一
-(void)subSendFNum{
    
    if (self.sendFlowerNum >= 1) {
        self.sendFlowerNum --;
        [self.sendFlowerView subFlower:self.sendFlowerNum];
        [self.sendFlowerView.btnSendFNum setTitle:[NSString stringWithFormat:@"%d",self.sendFlowerNum] forState:UIControlStateNormal];
        
        [self.sendFlowerView setLbTextForDifferentColor:self.sendFlowerView.lbRemain text:[NSString stringWithFormat:@"剩余%ld朵",(self.haveFlowerNum - self.sendFlowerNum)] rangeString:[NSString stringWithFormat:@"%ld",(self.haveFlowerNum - self.sendFlowerNum)] color:[UIColor rgbFromHexString:@"#FF0053" alpaa:1.0]];
    }
}

#pragma mark 送花 加一
-(void)addSendFNum{
    
    if (self.haveFlowerNum - self.sendFlowerNum > 0) {
        self.sendFlowerNum ++;
        [self.sendFlowerView addFlower:self.sendFlowerNum];
        [self.sendFlowerView.btnSendFNum setTitle:[NSString stringWithFormat:@"%d",self.sendFlowerNum] forState:UIControlStateNormal];
        [self.sendFlowerView setLbTextForDifferentColor:self.sendFlowerView.lbRemain text:[NSString stringWithFormat:@"剩余%ld朵",(self.haveFlowerNum - self.sendFlowerNum)] rangeString:[NSString stringWithFormat:@"%ld",(self.haveFlowerNum - self.sendFlowerNum)] color:[UIColor rgbFromHexString:@"#FF0053" alpaa:1.0]];
    }
}

#pragma mark - sendFlowerHandle 确定送花
-(void)sendFlowerHandle{
    //发送送花请求
    if (self.sendFlowerNum >= 1) {
        [[NetReqManager getInstance] sendGetSendUserFlower:[ListenToMeDBManager getUuid] LUserId:self.sendToUserBaseInfoNet.uuid IFlowerNum:self.sendFlowerNum];
        
    }
    
    [self.coverView removeFromSuperview];
    //    [self.sendFlowerView removeFromSuperview];
}

#pragma mark - 移除送花视图
-(void)backToView{
    
    [self.coverView removeFromSuperview];
}

#pragma mark - 音乐播放处理
-(void)playMusic:(UIButton *)btnPlay{
    //当前点击头像获取的cell,利用iOS中的多态原理,父类指针可以指向子类
    UITableViewCell *cell = (UITableViewCell *)[[btnPlay superview] superview];
    //获取cell的indexPath的值
    NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];
    
    MusicWorkBaseInfo *musicWorkBaseInfo = self.kStoreMemoryDataArr[indexPath.section * 4 + indexPath.row];
    
    
    if (musicWorkBaseInfo.lMusicWorkId != [ListenToMeData getInstance].currentMusicAudition.lMusicWorkId) {
        [[NetReqManager getInstance]sendMusicAuditon:[ListenToMeDBManager getUuid] LMusicWorkId:musicWorkBaseInfo.lMusicWorkId];
    }else{
        
        if (STKAudioPlayerStateStopped == audioPlayer.state) {
            //如果歌曲播放完以后,播放器的状态会被置为stop,在次点击播放时,要改变播放按钮的选中状态
            btnPlay.selected = YES;
        }else if(STKAudioPlayerStatePlaying == audioPlayer.state){
            //当处于正在播放时,再次点击将会变为暂停,改变播放按键的状态
            btnPlay.selected = NO;
        }else if (STKAudioPlayerStatePaused == audioPlayer.state){
            //当处于播放暂停时,再次点击播放,改变播放按键的状态
            btnPlay.selected = YES;
        }else{
            //刷新列表
            //            [self.mTableView reloadData];
        }
    }
    
    [self playMusicWork:musicWorkBaseInfo];
}

#pragma mark - 播放音乐处理
-(void)playMusicWork:(MusicWorkBaseInfo *)musicWorkBaseInfo{
    
    if (nil == musicWorkBaseInfo) {
        return;
    }
    NSURL *url = [NSURL URLWithString:musicWorkBaseInfo.stSongInfo.sSongUrl];
    if ((STKAudioPlayerStateReady == audioPlayer.state) || (STKAudioPlayerStateStopped == audioPlayer.state)) {
        
        [audioPlayer playURL:url];
        
        
    }else if(STKAudioPlayerStatePlaying == audioPlayer.state){
        if (musicWorkBaseInfo.lMusicWorkId == [ListenToMeData getInstance].currentMusicAudition.lMusicWorkId) {
            [audioPlayer pause];
        }else{
            
            [audioPlayer playURL:url];
        }
        
        
    }else if(STKAudioPlayerStatePaused == audioPlayer.state){
        if (musicWorkBaseInfo.lMusicWorkId == [ListenToMeData getInstance].currentMusicAudition.lMusicWorkId) {
            [audioPlayer resume];
        }else{
            
            [audioPlayer playURL:url];
        }
        
    }
    
    
    
}


#pragma mark - SKTAudioPlayerDelegate
-(void)audioPlayer:(STKAudioPlayer *)audioPlayer stateChanged:(STKAudioPlayerState)state previousState:(STKAudioPlayerState)previousState{
    
    
    switch (state) {
        case STKAudioPlayerStateReady:
            
            break;
        case STKAudioPlayerStateBuffering:
            
            break;
        case STKAudioPlayerStatePaused:
            
            break;
        case STKAudioPlayerStatePlaying:
            if (self.listenToMeData.currentMusicAudition) {
#warning 进入后台,锁屏播放
                [self showInfoInLockedScreen:self.listenToMeData.currentMusicAudition];
            }
            break;
        case STKAudioPlayerStateStopped:
            
            [ListenToMeData getInstance].currentMusicAudition = nil;
            [self.tableView reloadData];
            break;
        case STKAudioPlayerStateRunning:
            
            break;
        case STKAudioPlayerStateDisposed:
            
            break;
        case STKAudioPlayerStateError:
            
            break;
            
        default:
            break;
    }
    
}
-(void)audioPlayer:(STKAudioPlayer *)audioPlayer didStartPlayingQueueItemId:(NSObject *)queueItemId{
    
}
-(void)audioPlayer:(STKAudioPlayer *)audioPlayer didFinishBufferingSourceWithQueueItemId:(NSObject *)queueItemId{
    
}

-(void)audioPlayer:(STKAudioPlayer *)audioPlayer didFinishPlayingQueueItemId:(NSObject *)queueItemId withReason:(STKAudioPlayerStopReason)stopReason andProgress:(double)progress andDuration:(double)duration{
    
}

-(void)audioPlayer:(STKAudioPlayer *)audioPlayer unexpectedError:(STKAudioPlayerErrorCode)errorCode{
    
}


#pragma mark - 锁屏后显示播放歌曲的名字
-(void)showInfoInLockedScreen:(MusicWorkBaseInfo *)musicWorkBaseInfo{
    if (!musicWorkBaseInfo) {
        return;
    }
    
    if (NSClassFromString(@"MPNowPlayingInfoCenter")) {
        NSMutableDictionary *info = [NSMutableDictionary dictionary];
        
        //音乐歌曲名
        info[MPMediaItemPropertyTitle] = musicWorkBaseInfo.stSongInfo.sSongName;
        
        //音乐艺术家
        info[MPMediaItemPropertyArtist] = musicWorkBaseInfo.stSongInfo.sSongSinger;
        
        //专辑名称
        info[MPMediaItemPropertyAlbumTitle] = musicWorkBaseInfo.stSongInfo.sSongSinger;
        
        //图片
        info[MPMediaItemPropertyArtwork] = [[MPMediaItemArtwork alloc]initWithImage:[UIImage imageNamed:@"icon.png"]];
        
        //音乐当前已经播放的时间
        info[MPNowPlayingInfoPropertyElapsedPlaybackTime] = [NSNumber numberWithDouble:[ListenToMeData getInstance].audioPlayer.progress];
        
        //进度光标的速度,(可以自己调整播放速率,默认是原速度播放)
        info[MPNowPlayingInfoPropertyPlaybackRate] = [NSNumber numberWithFloat:1.0];
        
        //歌曲总时间的设置
        info[MPMediaItemPropertyPlaybackDuration] = [NSNumber numberWithDouble:[ListenToMeData getInstance].audioPlayer.duration];
        
        //唯一的API,单例,nowPlayingInfo字典
        [MPNowPlayingInfoCenter defaultCenter].nowPlayingInfo = info;
        
    }
}

#pragma mark 接收进入后台锁屏等状态是,执行操作如:暂停,播放,下一曲,上一曲
- (void)remoteControlReceivedWithEvent:(UIEvent *)event {
    //if it is a remote control event handle it correctly
    NSLog(@"%li,%li",event.type,event.subtype);
    if(event.type==UIEventTypeRemoteControl){
        switch (event.subtype) {
            case UIEventSubtypeRemoteControlPlay:
                if (STKAudioPlayerStatePlaying == audioPlayer.state) {
                    [audioPlayer pause];
                }else{
                    [audioPlayer resume];
                }
                NSLog(@"play");
                break;
            case UIEventSubtypeRemoteControlPause:
                [audioPlayer pause];
                NSLog(@"pause");
                
                break;
            case UIEventSubtypeRemoteControlStop:
                NSLog(@"stop");
                break;
            case UIEventSubtypeRemoteControlTogglePlayPause:
                //使用耳机时也可暂定音乐播放
                if (STKAudioPlayerStatePlaying == audioPlayer.state) {
                    [audioPlayer pause];
                }else{
                    [audioPlayer resume];
                }
                NSLog(@"toggle");
                break;
            case UIEventSubtypeRemoteControlNextTrack:
                NSLog(@"Next...");
                break;
            case UIEventSubtypeRemoteControlPreviousTrack:
                NSLog(@"Previous...");
                break;
            case UIEventSubtypeRemoteControlBeginSeekingForward:
                NSLog(@"Begin seek forward...");
                break;
            case UIEventSubtypeRemoteControlEndSeekingForward:
                NSLog(@"End seek forward...");
                break;
            case UIEventSubtypeRemoteControlBeginSeekingBackward:
                NSLog(@"Begin seek backward...");
                break;
            case UIEventSubtypeRemoteControlEndSeekingBackward:
                NSLog(@"End seek backward...");
                break;
            default:
                break;
        }
        //其他操作
        //        [self changeUIState];
        [self.tableView reloadData];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
