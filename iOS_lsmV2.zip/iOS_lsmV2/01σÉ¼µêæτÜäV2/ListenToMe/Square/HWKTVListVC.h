//
//  HWKTVListVC.h
//  ListenToMe
//
//  Created by zhw on 15/6/18.
//  Copyright (c) 2015年 listentome. All rights reserved.
//

#import "YDBaseVC.h"

@interface HWKTVListVC : YDBaseVC
@property(nonatomic,strong) ListenToMeData *listenToMeData;
@end
