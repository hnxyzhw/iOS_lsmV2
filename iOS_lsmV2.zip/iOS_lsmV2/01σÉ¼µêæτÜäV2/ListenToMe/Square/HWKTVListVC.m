//
//  HWKTVListVC.m
//  ListenToMe
//
//  Created by zhw on 15/6/18.
//  Copyright (c) 2015年 listentome. All rights reserved.
//

#import "HWKTVListVC.h"
#import "HMPopMenu.h"
#import "YDPopBt.h"
#import "YDSquareSearchVC.h"
#import "YDSquareCell.h"

#import "HWKTVTrendsVC.h"
#import "HWPerHomePageVC.h"
#import "LoginAlertView.h"
#import "LoadDataView.h"
#import "SDCycleScrollView.h"
#import <MediaPlayer/MPNowPlayingInfoCenter.h>
#import <MediaPlayer/MediaPlayer.h>
#import "HWMusicPlayVC.h"


@interface HWKTVListVC ()<UITableViewDelegate,UITableViewDataSource,YDSquareCellDelegate,SDCycleScrollViewDelegate,STKAudioPlayerDelegate>
{
    STKAudioPlayer *audioPlayer;
    HWKTVTrendsVC *ktvTrend;
}
@property(nonatomic,strong)UITableView *tableView;
@property(strong,nonatomic) UIView *tempView;
/**
 *  导航栏更多菜单
 */
@property(nonatomic,strong)YDPopBt *btnMsg;
@property(nonatomic,strong)YDPopBt *btnPlaying;
@property(nonatomic,strong)YDPopBt *btnRoom;
@property(nonatomic,strong)YDPopBt *btnReport;
/**
 *  正在加载数据动画
 */
@property(nonatomic,strong)LoadDataView *loadDataView;
/**
 *  登录提示
 */
@property(nonatomic,strong)LoginAlertView *loginAlertView;
@end



@implementation HWKTVListVC
/**
 *  导航栏更多菜单
 */
@synthesize btnMsg;
@synthesize btnPlaying;
@synthesize btnRoom;
@synthesize btnReport;



- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
//    self.view.backgroundColor = [UIColor whiteColor];
    
    [self setUI];
    
    //加载数据的动画
    [self setLoadDataGif];
    
    [self initData];
    
    //集成刷新控件
    [self setupRefreshView];
    
}


-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
#warning 如果不在视图出现时将系统的UITabBarButton移除,那么在pop回来是,系统的tabar会显示出来,会跟自定义的tarbar重叠影响视图
    for (UIView *child in self.tabBarController.tabBar.subviews) {
        // 删除系统自动生成的UITabBarButton
        if ([child isKindOfClass:[UIControl class]]) {
            [child removeFromSuperview];
        }
    }
//    //重新刷新一下数据
    [self.tableView reloadData];
    
    
    //远程控制时间接收与处理
    [[UIApplication sharedApplication] beginReceivingRemoteControlEvents];
    [self becomeFirstResponder];
    
}

-(void)viewDidDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [[UIApplication sharedApplication] endReceivingRemoteControlEvents];
    [self resignFirstResponder];
    
}

#pragma mark - setupRefreshView 集成刷新控件
-(void)setupRefreshView{
    //1 下拉刷新
    
    
}

-(void)initData{
    //获取KTV列表数据
    [[NetReqManager getInstance] sendGetKtvListInfo:0 INum:5];
    
    
    self.listenToMeData = [ListenToMeData getInstance];
    
    if (!audioPlayer) {
        audioPlayer = self.listenToMeData.audioPlayer;
        //设置代理,监听播放的状态,通过播放器状态来切歌
        audioPlayer.delegate = self;
    }
   
    
    //获取KTV列表数据的回包通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(notifiLoadData) name:NOTIFY_GET_KTVLIST_PAGE_RESP object:nil];
    //获取K星广场数据的回包通知
//    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(notifiLoadData) name:NOTIFY_GET_POPULARITYLIST_PAGE_RESP object:nil];
    
//    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(notifiLoadData) name:NOTIFY_GET_NEWMUSICLIST_PAGE_RESP object:nil];
    
//    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(notifiLoadData) name:NOTIFY_GET_RECOMMENDLIST_PAGE_RESP object:nil];
    //获取纪念册列表数据的回包通知
//    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(notifiLoadData) name:NOTIFY_GET_COMMEMORATEINFO_PAGE_RESP object:nil];
    
    //获取收藏列表数据的回包通知
//    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(notifiLoadData) name:NOTIFY_GET_COLLECT_WORKLIST_PAGE_RESP object:nil];
    
    //收藏音乐
//    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshCollectData) name:NOTIFY_GET_COLLECT_MUSICWORK_PAGE_RESP object:nil];
    
    //收藏纪念册
    //    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshCollectData) name:NOTIFY_GET_COLLECT_COMMEMORATE_PAGE_RESP object:nil];
    
    //取消收藏音乐
//    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshCollectData) name:NOTIFY_GET_UN_COLLECT_MUSICWORK_PAGE_RESP object:nil];
    
    //取消收藏纪念册
    //    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(refreshCollectData) name:NOTIFY_GET_UN_COLLECT_COMMEMORATE_PAGE_RESP object:nil];
    
    //在线试听音乐回包的通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(notifiLoadData) name:NOTIFY_GET_MUSIC_AUDITION_PAGE_RESP object:nil];
}

#pragma mark - 重新获取收藏列表,并刷新数据的显示,解决收藏显示状态同步显示的问题
-(void)refreshCollectData{
    
    if ([ListenToMeDBManager getUuid] > 0) {
        
        [[NetReqManager getInstance] sendGetCollectWorkList:[ListenToMeDBManager getUuid] IOffset:0 INum:20];
        
    }
    
    
}

#pragma mark - 回包后通知列表数据刷新显示
-(void)notifiLoadData{
    
    [self.tableView reloadData];
    
    [self dismissLoadDataView];
    
    
    
//    if ([ListenToMeData getInstance].bConnected) {
//        if (self.loadDataView) {
//            [self dismissLoadDataView];
//        }
//        
//    }
    
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:NOTIFY_GET_KTVLIST_PAGE_RESP object:nil];
//    [[NSNotificationCenter defaultCenter] removeObserver:self name:NOTIFY_GET_POPULARITYLIST_PAGE_RESP object:nil];
//    [[NSNotificationCenter defaultCenter] removeObserver:self name:NOTIFY_GET_NEWMUSICLIST_PAGE_RESP object:nil];
//    [[NSNotificationCenter defaultCenter] removeObserver:self name:NOTIFY_GET_RECOMMENDLIST_PAGE_RESP object:nil];
//    [[NSNotificationCenter defaultCenter] removeObserver:self name:NOTIFY_GET_COMMEMORATEINFO_PAGE_RESP object:nil];
//    [[NSNotificationCenter defaultCenter] removeObserver:self name:NOTIFY_GET_COLLECT_MUSICWORK_PAGE_RESP object:nil];
//    [[NSNotificationCenter defaultCenter] removeObserver:self name:NOTIFY_GET_COLLECT_COMMEMORATE_PAGE_RESP object:nil];
//    [[NSNotificationCenter defaultCenter] removeObserver:self name:NOTIFY_GET_UN_COLLECT_MUSICWORK_PAGE_RESP object:nil];
//    [[NSNotificationCenter defaultCenter] removeObserver:self name:NOTIFY_GET_UN_COLLECT_COMMEMORATE_PAGE_RESP object:nil];
//    [[NSNotificationCenter defaultCenter] removeObserver:self name:NOTIFY_GET_COLLECT_WORKLIST_PAGE_RESP object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:NOTIFY_GET_MUSIC_AUDITION_PAGE_RESP object:nil];
    
    
}


#pragma mark - 加载动画
-(void)setLoadDataGif{
    
    if (!self.loadDataView) {
        CGRect loadDataFrame = CGRectMake(0, naviAndStatusH, screenWidth, screenHeight - naviAndStatusH - tabBarH);
        self.loadDataView =[[LoadDataView alloc]initWithFrame:loadDataFrame];
    }
    
    //    [[[UIApplication sharedApplication]keyWindow] addSubview:self.loadDataView];
    [self.view addSubview:self.loadDataView];
    
    
}

//动画消失
-(void)dismissLoadDataView{
    [self.loadDataView removeFromSuperview];
}


#pragma mark - setUI
-(void)setUI{
    //自定义navigationBar
    [self customNavigationBar];
    
    [self setktvUI];
}

#pragma mark - UI
#pragma mark -导航栏
-(void)customNavigationBar
{
    UIButton *customButton = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, 100, 41)];
    customButton.backgroundColor = [UIColor clearColor];
    [customButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    customButton.titleLabel.font = [UIFont systemFontOfSize:16.5];
    customButton.titleLabel.textAlignment = NSTextAlignmentCenter;
    [customButton setTitle:@"KTV" forState:UIControlStateNormal];
    self.navigationItem.titleView = customButton;
    
    [self.navigationItem setHidesBackButton:YES];
    UIImage *searchImg = [UIImage imageNamed:@"search.png"];
    UIButton *customBackBtn = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, searchImg.size.width, searchImg.size.height)];
    [customBackBtn addTarget:self action:@selector(customBackAction) forControlEvents:UIControlEventTouchUpInside];
    [customBackBtn setImage:searchImg forState:UIControlStateNormal];
    UIBarButtonItem *customBackItem = [[UIBarButtonItem alloc]initWithCustomView:customBackBtn];
    self.navigationItem.leftBarButtonItem = customBackItem;
    
    UIImage *rightBtImg = [UIImage imageNamed:@"more.png"];
    UIButton *rightBtn = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, rightBtImg.size.width,rightBtImg.size.height)];
    [rightBtn setImageEdgeInsets:UIEdgeInsetsMake(0, 0, 0, -25)];
    [rightBtn setImage:rightBtImg forState:UIControlStateNormal];
    [rightBtn addTarget:self action:@selector(clickRightBarBtnItem) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *customRightBtnItem = [[UIBarButtonItem alloc]initWithCustomView:rightBtn];
    self.navigationItem.rightBarButtonItem = customRightBtnItem;
}

#pragma mark 搜索
-(void)customBackAction
{
    YDSquareSearchVC *squareSearchVC = [[YDSquareSearchVC alloc]init];
    [self.navigationController pushViewController:squareSearchVC animated:NO];
}


#pragma mark -点击事件
#pragma mark 点击了更多
-(void)clickRightBarBtnItem
{
    YDLog(@"点击了导航栏右边的Btn");
    
    UIImage *popImg = [UIImage imageNamed:@"popMenuBg.png"];
    CGFloat popMenuW = popImg.size.width;
    CGFloat popMenuH = popImg.size.height;
    _tempView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, popMenuW, popMenuH)];
    _tempView.userInteractionEnabled = YES;
    
    // 第一个btn的 y
    CGFloat btnW = 145;
    CGFloat btnH = 39;
    CGFloat firstBtnY = 5.5;
    
    btnMsg = [self PopBtnWithImg:@"msg.png" title:@"消息" count:18 frame:CGRectMake(0,firstBtnY, btnW, btnH)];
    btnPlaying = [self PopBtnWithImg:@"playing.png" title:@"正在播放" count:5 frame:CGRectMake(0,firstBtnY + btnH, btnW, btnH)];
    btnRoom = [self PopBtnWithImg:@"yuegebaofang.png" title:@"包房" count:0 frame:CGRectMake(0, firstBtnY + 2 * btnH,btnW, btnH)];
    btnReport = [self PopBtnWithImg:@"report.png" title:@"举报" count:0 frame:CGRectMake(0, firstBtnY + 3 * btnH,btnW, btnH)];
    btnReport.imgLine.hidden = YES;
    
    [_tempView addSubview:btnMsg];
    [_tempView addSubview:btnPlaying];
    [_tempView addSubview:btnRoom];
    [_tempView addSubview:btnReport];
    
    [btnMsg.BtnPop addTarget:self action:@selector(clickMsg) forControlEvents:UIControlEventTouchUpInside];
    [btnPlaying.BtnPop addTarget:self action:@selector(clickPlaying) forControlEvents:UIControlEventTouchUpInside];
    [btnRoom.BtnPop addTarget:self action:@selector(clickRoom) forControlEvents:UIControlEventTouchUpInside];
    [btnReport.BtnPop addTarget:self action:@selector(clickReport) forControlEvents:UIControlEventTouchUpInside];
    
    HMPopMenu *menu = [HMPopMenu popMenuWithContentView:_tempView];
    CGFloat menuW = popMenuW;
    CGFloat menuH = popMenuH;
    CGFloat menuY = 55;
    CGFloat menuX = self.view.width - menuW - 20;
    menu.dimBackground = YES;
    menu.arrowPosition = HMPopMenuArrowPositionRight;
    [menu showInRect:CGRectMake(menuX, menuY, menuW, menuH)];
}


#pragma mark -弹出窗口的点击事件
-(void)clickMsg
{
    YDLog(@"clickMsg");
    [_tempView.superview.superview removeFromSuperview];
}

-(void)clickPlaying
{
    YDLog(@"clickPlaying");
    [_tempView.superview.superview removeFromSuperview];
    if ([ListenToMeData getInstance].currentMusicAudition) {
        HWMusicPlayVC *musicPlayVC = [HWMusicPlayVC shareHWMusicPlayVC];
        musicPlayVC.musicWorkBaseInfo = [ListenToMeData getInstance].currentMusicAudition;
        musicPlayVC.navigationItem.title = [ListenToMeData getInstance].currentMusicAudition.stSongInfo.sSongName;
        musicPlayVC.lWorkID = [ListenToMeData getInstance].currentMusicAudition.lMusicWorkId;
        [musicPlayVC playMusicwork:[ListenToMeData getInstance].currentMusicAudition];
        [self.navigationController pushViewController:musicPlayVC animated:YES];
    }
}

-(void)clickRoom
{
    YDLog(@"clickRoom");
    [_tempView.superview.superview removeFromSuperview];
}

-(void)clickReport
{
    YDLog(@"clickReport");
    [_tempView.superview.superview removeFromSuperview];
}


#pragma mark - KTV_UI
-(void)setktvUI
{

    [self setUpKtvTableView];
    
}
#pragma mark KTVtableview
-(void)setUpKtvTableView
{
    self.tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, screenWidth,self.view.height) style:UITableViewStylePlain];
    
    self.tableView.backgroundColor = [UIColor rgbFromHexString:@"#F1F1F1" alpaa:1.0];
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    self.tableView.showsVerticalScrollIndicator = NO;
    self.tableView.bounces = YES;
    [self.view addSubview:self.tableView];
}


#pragma mark UITableViewDelegate DataSourceDelegate

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.section == 0){
        //要显示广告轮播cell的高度
        return 100;
    }else{
        //普通cell的高度
        return 280 + 150 + 40;
    }
    
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
    
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    //将首页KTV列表,广告轮播放入到cell中,解决广告轮播不吸顶的问题
   return (1 + self.listenToMeData.ktvListBaseInfo.count);
    
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
   if (section == 0 || section == 1) {
        return 0;
    }else{
        return 15;
    }
    
}

//-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
//{
//    return 0;
//    
//}

//-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
//    return nil;
//}
//
//-(UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
//    
//    return nil;
//}

-(id )tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

    //第一个是滚动的广告拦,不吸顶的效果
    if (indexPath.section == 0) {
        UITableViewCell *cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
        
        NSMutableArray *imgArray = [NSMutableArray array];
        
        if (self.listenToMeData.ktvListBannerInfo == nil) {
            imgArray = [NSMutableArray arrayWithObjects:@"homeTemp01.png",@"homeTemp02.png",@"homeTemp03.jpg",@"homeTemp04.png",@"homeTemp05.jpg", nil]; //图片数组
            
        }else{
            
            for (int index =0 ; index < self.listenToMeData.ktvListBannerInfo.count; index ++) {
                KtvListBannerInfo *ktvListBannerInfo = self.listenToMeData.ktvListBannerInfo[index];
                
                NSString *sBannerUrl = ktvListBannerInfo.sBannerUrl;
                [imgArray addObject:sBannerUrl];
            }
            
        }
        
        CGRect scrollerFrame = CGRectMake(0, 0, screenWidth, 100);
        SDCycleScrollView *cycleScrollView = [[SDCycleScrollView alloc]initWithFrame:scrollerFrame];//[SDCycleScrollView cycleScrollViewWithFrame:scrollerFrame imageURLStringsGroup:imgArray];
        cycleScrollView.autoScroll = YES;
        cycleScrollView.autoScrollTimeInterval = 3;
        cycleScrollView.imageURLStringsGroup = imgArray;
        cycleScrollView.pageControlAliment = SDCycleScrollViewPageContolAlimentRight;
        cycleScrollView.delegate = self;
        cycleScrollView.titlesGroup = nil;
        
        cycleScrollView.dotColor = [UIColor rgbFromHexString:@"#AC56FF" alpaa:0.8];
        cycleScrollView.placeholderImage = [UIImage imageNamed:@"homeTemp01.png"];
        [cell.contentView addSubview:cycleScrollView];
        
        
        
        
        return cell;
        
    }else{
        YDSquareCell *cell = [YDSquareCell cellWithTableView:tableView];
        cell.delegate = self;
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.ktvBaseInfo = self.listenToMeData.ktvListBaseInfo[indexPath.section - 1];
        
        cell.tag = 1000 + indexPath.section - 1;
        
        cell.playBtnFirst.selected = NO;
        cell.playBtnSec.selected = NO;
        [cell.playBtnFirst addTarget:self action:@selector(playMusic:) forControlEvents:UIControlEventTouchUpInside];
        [cell.playBtnSec addTarget:self action:@selector(playMusic:) forControlEvents:UIControlEventTouchUpInside];

        
        //        //判断当前是否有音乐在播放,该音乐是否在当前页面,若果在,那么就将改音乐的播放按键状态设置为选中状态
        //判断当前是否有音乐在播放,该音乐是否在当前页面,若果在,那么就将改音乐的播放按键状态设置为选中状态
        if ([ListenToMeData getInstance].currentMusicAudition) {
            NSArray *musicWorkInfoArr = ((KtvBaseInfo *)self.listenToMeData.ktvListBaseInfo[indexPath.section - 1]).stMyMusicWorkInfo;
            for (int index = 0; index < musicWorkInfoArr.count; index ++) {
                MusicWorkBaseInfo *musicWorkBaseInfo = musicWorkInfoArr[index];
                if (musicWorkBaseInfo.lMusicWorkId == [ListenToMeData getInstance].currentMusicAudition.lMusicWorkId) {
                    YDLog(@"当前处于播放的cell是:%ld-%ld",indexPath.section,indexPath.row);
                    if (index == 0) {
                        if (STKAudioPlayerStatePlaying == audioPlayer.state || STKAudioPlayerStateBuffering == audioPlayer.state) {
                            cell.playBtnFirst.selected = YES;
                        }else{
                            cell.playBtnFirst.selected = NO;
                        }
                        
                    }
                    if (index == 1) {
                        if (STKAudioPlayerStatePlaying == audioPlayer.state || STKAudioPlayerStateBuffering == audioPlayer.state) {
                            cell.playBtnSec.selected = YES;
                        }else{
                            cell.playBtnSec.selected = NO;
                        }
                        
                    }
                }
            }
        }
        
        return cell;
    }
    
}


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
#warning 播放状态出问题,明天解决
    //retain]: message sent to deallocated instance
    //设置为属性,暂时解决了,引用计数报错的问题
    if (ktvTrend) {
        ktvTrend = nil;
    }
    ktvTrend = [[HWKTVTrendsVC alloc]init];
    
    ktvTrend.ktvBaseInfo = (self.listenToMeData.ktvListBaseInfo[indexPath.section - 1]);
    [self.navigationController pushViewController:ktvTrend animated:YES];
}



#pragma mark - SDCycleScrollViewDelegate

- (void)cycleScrollView:(SDCycleScrollView *)cycleScrollView didSelectItemAtIndex:(NSInteger)index
{
    YDLog(@"点击了首页的第---%ld张图片",index);
}


#pragma mark -其他 & 工具类
#pragma mark 弹出窗口

-(YDPopBt *)PopBtnWithImg:(NSString *)img title:(NSString *)title count:(int)count frame:(CGRect)frame
{
    YDPopBt *btn = [[YDPopBt alloc]initWithFrame:frame];
    
    btn.imgPop.image = [UIImage imageNamed:img];
    btn.lbPop.text = title;
    
    [btn.btnBadge setTitle:[NSString stringWithFormat:@"%d",count] forState:UIControlStateNormal];
    if ([btn.btnBadge.titleLabel.text isEqual:@""] || [btn.btnBadge.titleLabel.text isEqual:@"0" ] ) {
        btn.btnBadge.hidden = YES;
    }
    
    return btn;
}

#pragma mark -YDSquareCellDelegate 点击头像进入个人/他人主页
-(void)browsePerHmePage:(UserBaseInfoNet *)userBaseInfoNet{
    
    YDLog(@"KTV列表页面,点击头像进入个人主页功能取消,代码功能已经屏蔽,如有需要可以开启注释代码");
    
//    HWPerHomePageVC *personHomePageVC = [[HWPerHomePageVC alloc]init];
//    personHomePageVC.userBaseInfoNet = userBaseInfoNet;
//    [self.navigationController pushViewController:personHomePageVC animated:YES];
    
}


#pragma mark - 播放按键的点击事件
-(void)playMusic:(UIButton *)playButton{
    
    
    NSInteger playTag = playButton.tag - 1000;
    
    YDSquareCell *selectCell = (YDSquareCell *)playButton.superview.superview;
    
    KtvBaseInfo *ktvBaseInfo = self.listenToMeData.ktvListBaseInfo[selectCell.tag - 1000];
    
    
    //    NSString *urlStr = ((MusicWorkBaseInfo *)ktvBaseInfo.stMyMusicWorkInfo[playTag]).stSongInfo.sSongUrl;
    //    [audioPlayer play:[NSURL URLWithString:urlStr]];
    
    MusicWorkBaseInfo *musicWorkInfo = ktvBaseInfo.stMyMusicWorkInfo[playTag];
    
    if (musicWorkInfo.lMusicWorkId != [ListenToMeData getInstance].currentMusicAudition.lMusicWorkId) {
        [[NetReqManager getInstance]sendMusicAuditon:[ListenToMeDBManager getUuid] LMusicWorkId:musicWorkInfo.lMusicWorkId];
    }else{
        
        if (STKAudioPlayerStateStopped == audioPlayer.state) {
            //如果歌曲播放完以后,播放器的状态会被置为stop,在次点击播放时,要改变播放按钮的选中状态
            playButton.selected = YES;
        }else{
            //刷新列表
            [self.tableView reloadData];
        }
        
    }
    
    [self playMusicWork:musicWorkInfo];
    
    
}

#pragma mark - 播放音乐处理
-(void)playMusicWork:(MusicWorkBaseInfo *)musicWorkBaseInfo{
    
    if (nil == musicWorkBaseInfo) {
        return;
    }
    NSURL *url = [NSURL URLWithString:musicWorkBaseInfo.stSongInfo.sSongUrl];
    if ((STKAudioPlayerStateReady == audioPlayer.state) || (STKAudioPlayerStateStopped == audioPlayer.state)) {
        
        [audioPlayer playURL:url];
        
        
    }else if(STKAudioPlayerStatePlaying == audioPlayer.state){
        if (musicWorkBaseInfo.lMusicWorkId == [ListenToMeData getInstance].currentMusicAudition.lMusicWorkId) {
            [audioPlayer pause];
        }else{
            
            [audioPlayer playURL:url];
        }
        
        
    }else if(STKAudioPlayerStatePaused == audioPlayer.state){
        if (musicWorkBaseInfo.lMusicWorkId == [ListenToMeData getInstance].currentMusicAudition.lMusicWorkId) {
            [audioPlayer resume];
        }else{
            
            [audioPlayer playURL:url];
        }
        
    }
    
    
    
}

#pragma mark - 锁屏后显示播放歌曲的名字
-(void)showInfoInLockedScreen:(MusicWorkBaseInfo *)musicWorkBaseInfo{
    if (!musicWorkBaseInfo) {
        return;
    }
    
    if (NSClassFromString(@"MPNowPlayingInfoCenter")) {
        NSMutableDictionary *info = [NSMutableDictionary dictionary];
        
        //音乐歌曲名
        info[MPMediaItemPropertyTitle] = musicWorkBaseInfo.stSongInfo.sSongName;
        
        //音乐艺术家
        info[MPMediaItemPropertyArtist] = musicWorkBaseInfo.stSongInfo.sSongSinger;
        
        //专辑名称
        info[MPMediaItemPropertyAlbumTitle] = musicWorkBaseInfo.stSongInfo.sSongSinger;
        
        //图片
        info[MPMediaItemPropertyArtwork] = [[MPMediaItemArtwork alloc]initWithImage:[UIImage imageNamed:@"icon.png"]];
        
        //音乐当前已经播放的时间
        info[MPNowPlayingInfoPropertyElapsedPlaybackTime] = [NSNumber numberWithDouble:[ListenToMeData getInstance].audioPlayer.progress];
        
        //进度光标的速度,(可以自己调整播放速率,默认是原速度播放)
        info[MPNowPlayingInfoPropertyPlaybackRate] = [NSNumber numberWithFloat:1.0];
        
        //歌曲总时间的设置
        info[MPMediaItemPropertyPlaybackDuration] = [NSNumber numberWithDouble:[ListenToMeData getInstance].audioPlayer.duration];
        
        //唯一的API,单例,nowPlayingInfo字典
        [MPNowPlayingInfoCenter defaultCenter].nowPlayingInfo = info;
    
    }
}

#pragma mark 接收进入后台锁屏等状态是,执行操作如:暂停,播放,下一曲,上一曲
- (void)remoteControlReceivedWithEvent:(UIEvent *)event {
    //if it is a remote control event handle it correctly
    NSLog(@"%li,%li",event.type,event.subtype);
    if(event.type==UIEventTypeRemoteControl){
        switch (event.subtype) {
            case UIEventSubtypeRemoteControlPlay:
                if (STKAudioPlayerStatePlaying == audioPlayer.state) {
                    [audioPlayer pause];
                }else{
                    [audioPlayer resume];
                }
                NSLog(@"play");
                break;
            case UIEventSubtypeRemoteControlPause:
                [audioPlayer pause];
                NSLog(@"pause");
                
                break;
            case UIEventSubtypeRemoteControlStop:
                NSLog(@"stop");
                break;
            case UIEventSubtypeRemoteControlTogglePlayPause:
                //使用耳机时也可暂定音乐播放
                if (STKAudioPlayerStatePlaying == audioPlayer.state) {
                    [audioPlayer pause];
                }else{
                    [audioPlayer resume];
                }
                NSLog(@"toggle");
                break;
            case UIEventSubtypeRemoteControlNextTrack:
                NSLog(@"Next...");
                break;
            case UIEventSubtypeRemoteControlPreviousTrack:
                NSLog(@"Previous...");
                break;
            case UIEventSubtypeRemoteControlBeginSeekingForward:
                NSLog(@"Begin seek forward...");
                break;
            case UIEventSubtypeRemoteControlEndSeekingForward:
                NSLog(@"End seek forward...");
                break;
            case UIEventSubtypeRemoteControlBeginSeekingBackward:
                NSLog(@"Begin seek backward...");
                break;
            case UIEventSubtypeRemoteControlEndSeekingBackward:
                NSLog(@"End seek backward...");
                break;
            default:
                break;
        }
        //其他操作
//        [self changeUIState];
        [self.tableView reloadData];
    }
}

#pragma mark - SKTAudioPlayerDelegate
-(void)audioPlayer:(STKAudioPlayer *)audioPlayer stateChanged:(STKAudioPlayerState)state previousState:(STKAudioPlayerState)previousState{
    
    
    switch (state) {
        case STKAudioPlayerStateReady:
            
            break;
        case STKAudioPlayerStateBuffering:
            
            break;
        case STKAudioPlayerStatePaused:
            
            break;
        case STKAudioPlayerStatePlaying:
            if (self.listenToMeData.currentMusicAudition) {
#warning 进入后台,锁屏时音乐继续播放
                [self showInfoInLockedScreen:self.listenToMeData.currentMusicAudition];
            }
            break;
        case STKAudioPlayerStateStopped:
            
            [ListenToMeData getInstance].currentMusicAudition = nil;
            [self.tableView reloadData];
            break;
        case STKAudioPlayerStateRunning:
            
            break;
        case STKAudioPlayerStateDisposed:
            
            break;
        case STKAudioPlayerStateError:
            
            break;
            
        default:
            break;
    }
    
}
-(void)audioPlayer:(STKAudioPlayer *)audioPlayer didStartPlayingQueueItemId:(NSObject *)queueItemId{
    
}
-(void)audioPlayer:(STKAudioPlayer *)audioPlayer didFinishBufferingSourceWithQueueItemId:(NSObject *)queueItemId{
    
}

-(void)audioPlayer:(STKAudioPlayer *)audioPlayer didFinishPlayingQueueItemId:(NSObject *)queueItemId withReason:(STKAudioPlayerStopReason)stopReason andProgress:(double)progress andDuration:(double)duration{
    
}

-(void)audioPlayer:(STKAudioPlayer *)audioPlayer unexpectedError:(STKAudioPlayerErrorCode)errorCode{
    
}



#pragma mark - 第三方登录
-(void)weiXinLogin:(UIButton *)weiXingBtn{
    
    //需要到微信开放平台进行注册,申请开发者帐号.
    UMSocialSnsPlatform *snsPlatform = [UMSocialSnsPlatformManager getSocialPlatformWithName:UMShareToWechatSession];
    
    snsPlatform.loginClickHandler(self,[UMSocialControllerService defaultControllerService],YES,^(UMSocialResponseEntity *response){
        
        if (response.responseCode == UMSResponseCodeSuccess) {
            
            UMSocialAccountEntity *snsAccount = [[UMSocialAccountManager socialAccountDictionary]valueForKey:UMShareToWechatSession];
            
            YDLog(@"WeiXin username is %@, uid is %@, token is %@ url is %@",snsAccount.userName,snsAccount.usid,snsAccount.accessToken,snsAccount.iconURL);
            
            [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"launchStaue"];
            
            [self.loginAlertView removeFromSuperview];
            //            [self.loginAlertVC.view removeFromSuperview];
            
        }
        
    });
    
    
    
}

-(void)qqLogin:(UIButton *)qqBtn{
    
    //暂时使用QQQzone登录
    UMSocialSnsPlatform *snsPlatform = [UMSocialSnsPlatformManager getSocialPlatformWithName:UMShareToQzone];
    
    snsPlatform.loginClickHandler(self,[UMSocialControllerService defaultControllerService],YES,^(UMSocialResponseEntity *response){
        
        //          获取微博用户名、uid、token等
        
        if (response.responseCode == UMSResponseCodeSuccess) {
            
            UMSocialAccountEntity *snsAccount = [[UMSocialAccountManager socialAccountDictionary] valueForKey:UMShareToQzone];
            
            YDLog(@"QQ username is %@, uid is %@, token is %@ url is %@",snsAccount.userName,snsAccount.usid,snsAccount.accessToken,snsAccount.iconURL);
            [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"launchStaue"];
            
            
            [self.loginAlertView removeFromSuperview];
            //            [self.loginAlertVC.view removeFromSuperview];
        }});
    
    
    
}
-(void)sinaLogin:(UIButton *)sinaBtn{
    
    UMSocialSnsPlatform *snsPlatform = [UMSocialSnsPlatformManager getSocialPlatformWithName:UMShareToSina];
    
    snsPlatform.loginClickHandler(self,[UMSocialControllerService defaultControllerService],YES,^(UMSocialResponseEntity *response){
        
        //        NSDictionary *dic = response.data[@"sina"];
        //        [self setNamelabelAndIcon:dic];
        //        [self setLoginStatus];
        
        if (response.responseCode == UMSResponseCodeSuccess) {
            
            UMSocialAccountEntity *snsAccount = [[UMSocialAccountManager socialAccountDictionary] valueForKey:UMShareToSina];
            
            YDLog(@"Sina username is %@, uid is %@, token is %@ url is %@",snsAccount.userName,snsAccount.usid,snsAccount.accessToken,snsAccount.iconURL);
            
            //获取新浪好友限制30个
            //            [[UMSocialDataService defaultDataService] requestSnsFriends:UMShareToSina  completion:^(UMSocialResponseEntity *response){
            //                YDLog(@"SnsFriends is %@",response.data);
            //            }];
            
            
            [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"launchStaue"];
            
            
            
            [self.loginAlertView removeFromSuperview];
            //            [self.loginAlertVC.view removeFromSuperview];
            
        }
        
    });
    
    
    
    
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    
    YDLog(@"%s:%d obj=%@",__func__,__LINE__,self);
    if ([[UIDevice currentDevice].systemVersion floatValue] >= 6.0) {
        //注意self.isViewLoadde是必不可少的,其他方式访问视图会导致它加载
        //判断是否是正在使用的视图
        if (self.isViewLoaded && !self.view.window) {
            //将self.view置为nil,目的是再次进入时能够重新调用viewDidLaod函数
            self.view = nil;
            
        }
        
        
    }
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
