//
//  YDTopListCell.h
//  ListenToMe
//
//  Created by yadong on 3/6/15.
//  Copyright (c) 2015 listentome. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HWImageAndLabel.h"
@protocol YDTopLiseCellDelegate <NSObject>

/**
 *  点击分享提示分享平台
 */
@optional
-(void)alertForShare;

@end

@interface YDTopListCell : UITableViewCell
/**
 *   设置代理注意要assign
 */
@property(assign,nonatomic)id<YDTopLiseCellDelegate>delegate;

+ (instancetype)cellWithTableView:(UITableView *)tableView;
/**
 * 歌名lb
 */
@property(strong,nonatomic) UILabel *lbMusicName;

/**
* 歌者lb
*/
@property(strong,nonatomic) UILabel *lbSinger;

/**
* 播放btn
*/
@property(strong,nonatomic) UIButton *btnPlay;

/**
* 头像bt
*/
@property(strong,nonatomic) UIImageView *imgAvatar;

/**
 * 歌曲时间lb
 */
@property(strong,nonatomic) UILabel *lbTime;

/**
 * 听众数
 */
@property(strong,nonatomic) HWImageAndLabel *btnListener;

/**
* 鲜花数
*/
@property(strong,nonatomic) HWImageAndLabel *btnFlower;

/**
 *  送花
 */
@property(strong,nonatomic) UIButton *btnSendingFlower;

/**
 * 分享btn
 */
@property(strong,nonatomic) UIButton *btnShare;

/**
 * 收藏btn
 */
@property(strong,nonatomic) UIButton *btnCollection;
/**
 * 波浪
 */
@property(strong,nonatomic) UIImageView *imgWave;

/**
 *  定义一个bool判断是否已经收藏过了
 */
@property(assign,nonatomic)BOOL isCollected;
/**
 *  音乐作品
 */
@property(nonatomic,strong) MusicWorkBaseInfo *musicWorkBaseInfo;
@end
