//
//  HWShareAlertVC.h
//  ListenToMe
//
//  Created by zhw on 15/3/30.
//  Copyright (c) 2015年 listentome. All rights reserved.
//分享提示界面

#import <UIKit/UIKit.h>

@interface HWShareAlertVC : UIViewController

@end
