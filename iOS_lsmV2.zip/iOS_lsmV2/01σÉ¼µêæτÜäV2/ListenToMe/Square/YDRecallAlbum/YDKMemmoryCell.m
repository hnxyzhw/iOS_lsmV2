//
//  YDKMemmoryCell.m
//  ListenToMe
//
//  Created by yadong on 3/9/15.
//  Copyright (c) 2015 listentome. All rights reserved.
//

#import "YDKMemmoryCell.h"

@interface YDKMemmoryCell ()<UIScrollViewDelegate>

@end

@implementation YDKMemmoryCell

+(instancetype)cellWithTableView:(UITableView *)tableView
{
    static NSString *ID = @"memoryCell";
    YDKMemmoryCell *cell = [tableView dequeueReusableCellWithIdentifier:ID];
    if (!cell) {
        cell = [[YDKMemmoryCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:ID];
    }
    return cell;
}

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        CGFloat lineH = 1; // 分割横线的高度
        CGFloat frontX = 15; // 控件距离screen左右的距离
        CGFloat imgCoverH = 150; // 封面高度

        // 聚会封面图片
        _imgCover = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, screenWidth, imgCoverH)];
        _imgCover.contentMode = UIViewContentModeScaleToFill;
        [self.contentView addSubview:_imgCover];
        
        // 聚会主题lb
        CGFloat lbThemeW = 50;
        _lbTheme = [[UILabel alloc]initWithFrame:CGRectMake(screenWidth - frontX - lbThemeW, 10, lbThemeW, 25)];
        _lbTheme.font = [UIFont systemFontOfSize:12.0];
        _lbTheme.textColor = [UIColor whiteColor];
        _lbTheme.textAlignment = NSTextAlignmentRight;
        [self.contentView addSubview:_lbTheme];
        
        // 聚会主题img
        CGFloat imgThemeW = 21;
        CGFloat imgThemeH = 22;
        _imgTheme = [[UIImageView alloc]initWithFrame:CGRectMake(_lbTheme.x - imgThemeW - 6, _lbTheme.y + 5, imgThemeW, imgThemeH)]; 
        [self.contentView addSubview:_imgTheme];
        
        // 白色横线
        UIImageView *whiteLineImg = [[UIImageView alloc]initWithFrame:CGRectMake(_lbTheme.x, _lbTheme.y + _lbTheme.height, _lbTheme.width, 1)];
        whiteLineImg.backgroundColor = [UIColor whiteColor];
        [self.contentView addSubview:whiteLineImg];
        
        //纪念册的标签,标签一,标签二,标签三
        CGFloat btnMemoryLabel_W = 50 + frontX;
        CGFloat btnMemoryLabel_H = 20;
        CGFloat btnMemoryLabel_X =  _imgCover.width - btnMemoryLabel_W;
        CGFloat btnMemoryLabel_Y = whiteLineImg.y + whiteLineImg.height + 10;
        
        //标签一
        _btnMemoryLabel_01 =[[UIButton alloc]initWithFrame:CGRectMake(btnMemoryLabel_X, btnMemoryLabel_Y, btnMemoryLabel_W, btnMemoryLabel_H)];
        _btnMemoryLabel_01.backgroundColor = [UIColor whiteColor];
        _btnMemoryLabel_01.layer.masksToBounds = YES;
        _btnMemoryLabel_01.layer.cornerRadius = 8;
        [_btnMemoryLabel_01 setTitle:@"标签一" forState:UIControlStateNormal];
        [_btnMemoryLabel_01 setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [_btnMemoryLabel_01.titleLabel setFont:[UIFont systemFontOfSize:8.0]];
        [_imgCover addSubview:_btnMemoryLabel_01];
        
        
        //标签二
        
        _btnMemoryLabel_02 =[[UIButton alloc]initWithFrame:CGRectMake(btnMemoryLabel_X, btnMemoryLabel_Y + 20 + 10, btnMemoryLabel_W, btnMemoryLabel_H)];
        _btnMemoryLabel_02.backgroundColor = [UIColor whiteColor];
        _btnMemoryLabel_02.layer.masksToBounds = YES;
        _btnMemoryLabel_02.layer.cornerRadius = 8;
        [_btnMemoryLabel_02 setTitle:@"标签二" forState:UIControlStateNormal];
        [_btnMemoryLabel_02 setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [_btnMemoryLabel_02.titleLabel setFont:[UIFont systemFontOfSize:8.0]];
        [_imgCover addSubview:_btnMemoryLabel_02];
        
        //标签三
        _btnMemoryLabel_03 =[[UIButton alloc]initWithFrame:CGRectMake(btnMemoryLabel_X, btnMemoryLabel_Y + ( 20 + 10) * 2, btnMemoryLabel_W, btnMemoryLabel_H)];
        _btnMemoryLabel_03.backgroundColor = [UIColor whiteColor];
        _btnMemoryLabel_03.layer.masksToBounds = YES;
        _btnMemoryLabel_03.layer.cornerRadius = 8;
        [_btnMemoryLabel_03 setTitle:@"标签三" forState:UIControlStateNormal];
        [_btnMemoryLabel_03 setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [_btnMemoryLabel_03.titleLabel setFont:[UIFont systemFontOfSize:8.0]];
        [_imgCover addSubview:_btnMemoryLabel_03];
        
        
        // 聚会名字
        CGFloat lbPartyNameH = 17;
        _lbPartyName = [[UILabel alloc]initWithFrame:CGRectMake(0, (imgCoverH - lbPartyNameH) * 0.5, screenWidth, lbPartyNameH)];
        _lbPartyName.font = [UIFont systemFontOfSize:15.0];
        _lbPartyName.textColor = [UIColor whiteColor];
        _lbPartyName.textAlignment = NSTextAlignmentCenter;
        [self.contentView addSubview:_lbPartyName];
        
        //纪念册制作者的头像
        CGFloat imgMemeoryMaker_W_H = 30;
        CGFloat imgMemoryMaker_X = 0;
        CGFloat imgMemoryMaker_Y = _imgCover.height - imgMemeoryMaker_W_H;
        _imgMemoryMaker = [[UIImageView alloc]initWithFrame:CGRectMake(imgMemoryMaker_X, imgMemoryMaker_Y, imgMemeoryMaker_W_H, imgMemeoryMaker_W_H)];
        _imgMemoryMaker.image = [UIImage imageNamed:@"temp2.png"];
        [_imgCover addSubview:_imgMemoryMaker];
        
        // 播放按钮
        UIImage *playImg = [UIImage imageNamed:@"btnWhitePlay.png"];
        UIButton *playBtn = [[UIButton alloc]initWithFrame:CGRectMake((screenWidth - playImg.size.width) * 0.5, 100, playImg.size.width, playImg.size.height)];
        [playBtn setImage:playImg forState:UIControlStateNormal];
        
        //去除播放
//        [self.contentView addSubview:playBtn];
        
        // 歌曲名称
//        CGFloat lbMusicNameH = 17.0;
//        _lbMusicName = [[UILabel alloc]initWithFrame:CGRectMake(0, playBtn.y + playBtn.height + 5, screenWidth, lbMusicNameH)];
//        _lbMusicName.font = [UIFont systemFontOfSize:12.0];
//        _lbMusicName.textColor = [UIColor whiteColor];
//        _lbMusicName.textAlignment = NSTextAlignmentCenter;
//        [self.contentView addSubview:_lbMusicName];
        
//        // 头像
        CGFloat avatarCellH = 50; //头像行的cell的高度
//        NSMutableArray *tempAvatar = [NSMutableArray arrayWithCapacity:8];
//        for (int index = 0; index < 8; index ++) {
//            CGFloat widthAndH = 32.5; // 头像的宽高
//            CGFloat margin = 2; // 头像间的间隔
//            CGFloat avatarX = index * (widthAndH + margin) + frontX;
//            UIImageView *avatarImg = [[UIImageView alloc]initWithFrame:CGRectMake(avatarX, 0.5 * (avatarCellH - widthAndH) + imgCoverH, widthAndH, widthAndH)];
//            avatarImg.contentMode = UIViewContentModeScaleToFill;
//            [self.contentView addSubview:avatarImg];
//            [tempAvatar addObject:avatarImg];
//            avatarImg.image = [UIImage imageNamed:@"temp3.png"];
//        }
        
        
        CGFloat widthAndH = 30; // 头像的宽高
        CGFloat avatarY = 0.5 * (avatarCellH - widthAndH) + imgCoverH;
        
        _joinPerScrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(frontX, avatarY, screenWidth - frontX * 2 - widthAndH, widthAndH)];
//        _joinPerScrollView.pagingEnabled = YES;
        _joinPerScrollView.delegate = self;
        _joinPerScrollView.showsHorizontalScrollIndicator = NO;
        _joinPerScrollView.showsVerticalScrollIndicator = NO;
        [self.contentView addSubview:_joinPerScrollView];
        
   
    
//        // 更多按钮
        UIImage *btnPureMoreImg = [UIImage imageNamed:@"btnPuyreMore@2x.png"];
        _btnPureMore = [[UIButton alloc]initWithFrame:CGRectMake(screenWidth - frontX - btnPureMoreImg.size.width, 0.5 * (avatarCellH - btnPureMoreImg.size.height) + imgCoverH, btnPureMoreImg.size.width,btnPureMoreImg.size.height)];
        [_btnPureMore setImage:btnPureMoreImg forState:UIControlStateNormal];
        [_btnPureMore addTarget:self action:@selector(scrollHandle:) forControlEvents:UIControlEventTouchUpInside];
        [self.contentView addSubview:_btnPureMore];
        
        // 分割横线
        UIImageView *lineImg_0 = [[UIImageView alloc]initWithFrame:CGRectMake(frontX, _imgCover.height + avatarCellH, screenWidth - 2 * frontX, lineH)];
        lineImg_0.backgroundColor = [UIColor rgbFromHexString:@"#AC56FF" alpaa:.12];
        [self.contentView addSubview:lineImg_0];
        
        // 多个数目btn
        CGFloat btnsCellH = 30; // 多个数目按钮cell的高度
        CGFloat btnsW = 57;
        //歌曲数
        CGFloat btnNumSongs_X = frontX;
        CGFloat btnNumSongs_Y = lineImg_0.y + lineImg_0.height + 0.5 * (btnsCellH - 15);

        
        _btnNumSongs = [[HWImageAndLabel alloc]initWithFrame:CGRectMake(btnNumSongs_X, btnNumSongs_Y, 45, 15)];
        _btnNumSongs.leftIconFrame = CGRectMake(0, 0, 15, 15);
        _btnNumSongs.imgName = @"作品2.png";
        _btnNumSongs.rightLabFrame = CGRectMake(15, 0, 30, 15);
        _btnNumSongs.number = @"128";
        _btnNumSongs.numberColor = [UIColor rgbFromHexString:@"#A8AEAE" alpaa:1.0];
        [self.contentView addSubview:_btnNumSongs];
        
        _btnNumAlbums = [[HWImageAndLabel alloc]initWithFrame:CGRectMake(btnNumSongs_X + btnsW, btnNumSongs_Y, 45, 15)];
        _btnNumAlbums.leftIconFrame = CGRectMake(0, 0, 15, 15);
        _btnNumAlbums.imgName = @"btnMemoryAlbum.png";
        _btnNumAlbums.rightLabFrame = CGRectMake(15, 0, 30, 15);
        _btnNumAlbums.number = @"24";
        _btnNumAlbums.numberColor = [UIColor rgbFromHexString:@"#A8AEAE" alpaa:1.0];
        [self.contentView addSubview:_btnNumAlbums];
        
        _btnNumSee = [[HWImageAndLabel alloc]initWithFrame:CGRectMake(btnNumSongs_X + btnsW * 2, btnNumSongs_Y, 45, 15)];
        _btnNumSee.leftIconFrame = CGRectMake(0, 0, 15, 15);
        _btnNumSee.imgName = @"btnMemorySee.png";
        _btnNumSee.rightLabFrame = CGRectMake(15, 0, 30, 15);
        _btnNumSee.number = @"20";
        _btnNumSee.numberColor = [UIColor rgbFromHexString:@"#A8AEAE" alpaa:1.0];
        [self.contentView addSubview:_btnNumSee];
        
        _btnNumFlower = [[HWImageAndLabel alloc]initWithFrame:CGRectMake(btnNumSongs_X + btnsW * 3, btnNumSongs_Y, 45, 15)];
        _btnNumFlower.leftIconFrame = CGRectMake(0, 0, 10, 15);
        _btnNumFlower.imgName = @"送花数量.png";
        _btnNumFlower.rightLabFrame = CGRectMake(10, 0, _btnNumFlower.width - 10, 15);
        _btnNumFlower.number = @"114";
        _btnNumFlower.numberColor = [UIColor rgbFromHexString:@"#FF0053" alpaa:1.0];
        [self.contentView addSubview:_btnNumFlower];
        
        // 分割横线
        UIImageView *lineImg_1 = [[UIImageView alloc]initWithFrame:CGRectMake(frontX, lineImg_0.y + lineImg_0.height + 30, screenWidth - 2 * frontX, lineH)];
        lineImg_1.backgroundColor = [UIColor rgbFromHexString:@"#AC56FF" alpaa:.12];
        [self.contentView addSubview:lineImg_1];
        
        // 讨论 送花 收藏等的cell
        CGFloat discussBtnCellH = 40;
        
        //讨论
        UIImage *btnDisImg = [UIImage imageNamed:@"btnMemoryDis.png"];
        _btnDiscuss = [[UIButton alloc]initWithFrame:CGRectMake(frontX, lineImg_1.y + lineImg_1.height + 0.5 * (discussBtnCellH - btnDisImg.size.height), btnDisImg.size.width, btnDisImg.size.height)];
        [_btnDiscuss setImage:btnDisImg forState:UIControlStateNormal];
        [self.contentView addSubview:_btnDiscuss];
        
        //送花
        UIImage *btnActionFlowersImg = [UIImage imageNamed:@"送花数量.png"];
        _btnActionFlowes = [[UIButton alloc]initWithFrame:CGRectMake(_btnDiscuss.x + _btnDiscuss.width + 20, _btnDiscuss.center.y - 10.5, 13, 21)];
        [_btnActionFlowes setImage:btnActionFlowersImg forState:UIControlStateNormal];
        [self.contentView addSubview:_btnActionFlowes];
        
        //收藏
//        UIImage *btnActionCollectImg = [UIImage imageNamed:@"btnMemoryNotCollect.png"];
//        _btnActionCollect = [[UIButton alloc]initWithFrame:CGRectMake(screenWidth - frontX - btnActionCollectImg.size.width, _btnDiscuss.y, btnActionCollectImg.size.width, btnActionCollectImg.size.height)];
//        [_btnActionCollect setImage:btnActionCollectImg forState:UIControlStateNormal];
//        [_btnActionCollect setImage:[UIImage imageNamed:@"squareStarNotCollection.png"] forState:UIControlStateSelected];
//        [self.contentView addSubview:_btnActionCollect];
        
        //分享
        UIImage *btnActionShareImg = [UIImage imageNamed:@"btnMemoryShare.png"];
        _btnActionShare = [[UIButton alloc]initWithFrame:CGRectMake(_btnActionFlowes.x + _btnActionFlowes.width + 20, _btnDiscuss.y, btnActionShareImg.size.width, btnActionShareImg.size.height)];
        [_btnActionShare setImage:btnActionShareImg forState:UIControlStateNormal];
        [self.contentView addSubview:_btnActionShare];
        

        
        // 分割横线
//        UIImageView *lineImg_2 = [[UIImageView alloc]initWithFrame:CGRectMake(0, lineImg_1.y + lineImg_1.height + 40, screenWidth , lineH)];
//        lineImg_2.backgroundColor = [UIColor rgbFromHexString:@"#AC56FF" alpaa:.12];
//        [self.contentView addSubview:lineImg_2];
        
        //添加一个纪念册编辑的按键
        self.btnEditeMyMemmory = [[UIButton alloc]initWithFrame:CGRectMake(0, self.btnActionFlowes.y + self.btnActionFlowes.height + 10, screenWidth, 40)];
        UIImageView *btnBgImgView = [[UIImageView alloc]initWithFrame:self.btnEditeMyMemmory.bounds];
        [btnBgImgView setImage:[UIImage imageNamed:@"纪念册背景框.png"]];
        [self.btnEditeMyMemmory addSubview:btnBgImgView];
        UILabel *lbEditeTitle = [[UILabel alloc]initWithFrame:self.btnEditeMyMemmory.bounds];
        lbEditeTitle.text = @"编辑该纪念册";
        lbEditeTitle.textColor = [UIColor rgbFromHexString:@"#000000" alpaa:1.0];
        lbEditeTitle.font = [UIFont systemFontOfSize:12.0];
        lbEditeTitle.textAlignment = NSTextAlignmentCenter;
        [self.btnEditeMyMemmory addSubview:lbEditeTitle];
        [self.contentView addSubview:self.btnEditeMyMemmory];
        self.btnEditeMyMemmory.hidden = YES;
       
        
    }
    
    return self;
        
    }
#pragma mark 改变scrollView的偏移量,滑动到最右端
-(void)scrollHandle:(UIButton *)button{
    
    if (_joinPerScrollView.contentSize.width > _joinPerScrollView.width) {
        _joinPerScrollView.contentOffset = CGPointMake(_joinPerScrollView.contentSize.width - _joinPerScrollView.width,0);
    }
    
}

-(void)setArrUserBaseInfoNet:(NSArray *)arrUserBaseInfoNet{
    
    if (arrUserBaseInfoNet) {
        _arrUserBaseInfoNet = arrUserBaseInfoNet;
        
        
        CGFloat widthAndH = 30; // 头像的宽高
        CGFloat margin = 2; // 头像间的间隔
        CGFloat avatarY = 0; //0.5 * (avatarCellH - widthAndH) + imgCoverH;
        
#warning 解决纪念册显示时头像数据错乱的问题
        while ([_joinPerScrollView.subviews lastObject] != nil) {
            for (UIView *view in _joinPerScrollView.subviews) {
                [view removeFromSuperview];
            }
        }
        
        _joinPerScrollView.contentSize = CGSizeMake((widthAndH + margin) * _arrUserBaseInfoNet.count, widthAndH);


        for (int index = 0; index < _arrUserBaseInfoNet.count; index ++) {
            
            UserBaseInfoNet *userBaseInfoNet = _arrUserBaseInfoNet[index];
            
             CGFloat avatarX = index * (widthAndH + margin);
            UIImageView *avatarImgView = [[UIImageView alloc]initWithFrame:CGRectMake(avatarX ,avatarY , widthAndH, widthAndH)];
            avatarImgView.contentMode = UIViewContentModeScaleToFill;
            [avatarImgView sd_setImageWithURL:[NSURL URLWithString:userBaseInfoNet.sCovver]];
//            [self.contentView addSubview:avatarImgView];
            
//            UIButton *btnAvatar = [[UIButton alloc]initWithFrame:avatarImgView.frame];
//            btnAvatar.tag = 100 + index;
//            btnAvatar.backgroundColor = [UIColor clearColor];
//            
//            [self.contentView addSubview:btnAvatar];
            
            [_joinPerScrollView addSubview:avatarImgView];

        }
        

    }
    
}


-(void)setIsPushFromPerCenter:(BOOL)isPushFromPerCenter{
    _isPushFromPerCenter = isPushFromPerCenter;
    if (_isPushFromPerCenter) {
        self.btnEditeMyMemmory.hidden = NO;
    }
}

@end
