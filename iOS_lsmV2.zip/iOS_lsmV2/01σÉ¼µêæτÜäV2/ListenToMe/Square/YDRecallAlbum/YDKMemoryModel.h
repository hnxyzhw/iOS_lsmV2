//
//  YDKMemoryModel.h
//  ListenToMe
//
//  Created by yadong on 3/9/15.
//  Copyright (c) 2015 listentome. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YDKMemoryModel : NSObject


@end
