//
//  YDKMemmoryCell.h
//  ListenToMe
//
//  Created by yadong on 3/9/15.
//  Copyright (c) 2015 listentome. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HWImageAndLabel.h"
@interface YDKMemmoryCell : UITableViewCell
+(instancetype)cellWithTableView:(UITableView *)tableView;
// 数据
@property(assign,nonatomic) int tagTheme;
@property(nonatomic,copy) NSString *strPartyName;
@property(nonatomic,copy) NSString *strTopMusicName;
@property(nonatomic,strong) NSMutableArray *aryAvatar;
@property(assign,nonatomic) int numSongs;
@property(assign,nonatomic) int numAlbums;
@property(assign,nonatomic) int numSee;
@property(assign,nonatomic) int numFlower;
// 控件
/**
 * 封面
 */
@property(strong,nonatomic) UIImageView *imgCover;
/**
 * 聚会名
 */
@property(strong,nonatomic) UILabel *lbPartyName;

/**
 * 歌曲名
 */
@property(strong,nonatomic) UILabel *lbMusicName;
/**
 * 聚会主题
 */
@property(strong,nonatomic) UILabel *lbTheme;
/**
 * 聚会主题图片标识
 */
@property(strong,nonatomic) UIImageView *imgTheme;
/**
 * 歌曲数目
 */
@property(strong,nonatomic) HWImageAndLabel *btnNumSongs;
/**
 * 聚会照片数目
 */
@property(strong,nonatomic) HWImageAndLabel *btnNumAlbums;
/**
 * 聚会查看数目
 */
@property(strong,nonatomic) HWImageAndLabel *btnNumSee;
/**
 * 聚会送花数目
 */
@property(strong,nonatomic) HWImageAndLabel *btnNumFlower;
/**
 *  纪念册的制作者的头像
 */
@property(strong,nonatomic) UIImageView *imgMemoryMaker;
/**
 *  纪念册的标签01
 */
@property(strong,nonatomic) UIButton *btnMemoryLabel_01;
/**
 *  纪念册的标签02
 */
@property(strong,nonatomic) UIButton *btnMemoryLabel_02;
/**
 *  纪念册的标签03
 */
@property(strong,nonatomic) UIButton *btnMemoryLabel_03;
/**
 * 更多btn
 */
@property(strong,nonatomic) UIButton *btnPureMore;
/**
 * 讨论按钮
 */
@property(strong,nonatomic) UIButton *btnDiscuss;
/**
 * 送花
 */
@property(strong,nonatomic) UIButton *btnActionFlowes;
/**
 * 分享
 */
@property(strong,nonatomic) UIButton *btnActionShare;
/**
 * 收藏
 */
@property(strong,nonatomic) UIButton *btnActionCollect;
/**
 *  纪念册中参与人数组
 */
@property(nonatomic,strong) NSArray *arrUserBaseInfoNet;
/**
 *  用于显示头像的scrollview
 */
@property(nonatomic,strong) UIScrollView *joinPerScrollView;
/**
 *  编辑纪念册
 */
@property(nonatomic,strong) UIButton *btnEditeMyMemmory;
/**
 *  是否是从个人中心进入的,是则显示编辑纪念册的按键,否则,不显示编辑纪念册的按键
 */
@property(nonatomic,assign) BOOL isPushFromPerCenter;
@end
