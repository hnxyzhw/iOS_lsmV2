//
//  HWAlbumDetailVC.h
//  ListenToMe
//
//  Created by zhw on 15/4/10.
//  Copyright (c) 2015年 listentome. All rights reserved.
//

#import "YDBaseVC.h"

@interface HWAlbumDetailVC : YDBaseVC

@end
