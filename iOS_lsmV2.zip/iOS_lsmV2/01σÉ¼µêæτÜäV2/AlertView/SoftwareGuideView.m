//
//  SoftwareGuideView.m
//  ListenToMe
//
//  Created by zhw on 15/6/23.
//  Copyright (c) 2015年 listentome. All rights reserved.
//

#import "SoftwareGuideView.h"
#import "SDCycleScrollView.h"

@interface SoftwareGuideView ()<SDCycleScrollViewDelegate>

@end


@implementation SoftwareGuideView

-(id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [self setUI];
    }
    
    return self;
}

-(void)setUI{
    
    self.backgroundColor = [UIColor colorWithRed:234/255.0 green:234/255.0 blue:234/255.0 alpha:1.0];
    
    CGFloat bgView_W = self.width - 50;
    CGFloat bgView_H = 296 + 15;
    CGFloat bgView_X = 25;
    CGFloat bgView_Y = (self.height - bgView_H) * 0.5;
    UIImageView *backgroundView =[[UIImageView alloc] initWithFrame:CGRectMake(bgView_X, bgView_Y, bgView_W, bgView_H)];
    backgroundView.image = [UIImage imageNamed:@"SoftwareGuideBgView.png"];
    backgroundView.userInteractionEnabled = YES;
    [self addSubview:backgroundView];
    
    
    //图片数组
    NSMutableArray *imageArr = [NSMutableArray array];
    for (int i = 1; i <= 4; i ++) {
        UIImage *image = [UIImage imageNamed:[NSString stringWithFormat:@"SoftwareGuideView%d.png",i]];
        [imageArr addObject:image];
        
    }
    SDCycleScrollView *cycleScrollView = [[SDCycleScrollView alloc]initWithFrame:CGRectMake(- 5, 0, bgView_W + 10, 296)];
    cycleScrollView.backgroundColor = [UIColor clearColor];
    cycleScrollView.autoScroll = NO;
    cycleScrollView.infiniteLoop = NO;
    cycleScrollView.autoScrollTimeInterval = 0;
    cycleScrollView.localizationImagesGroup = imageArr;
    cycleScrollView.pageControlAliment = SDCycleScrollViewPageContolAlimentCenter;
    cycleScrollView.delegate = self;
    cycleScrollView.titlesGroup = nil;
    
    cycleScrollView.dotColor = [UIColor rgbFromHexString:@"#EAEAEA" alpaa:0.8];
    cycleScrollView.placeholderImage = [UIImage imageNamed:@"homeTemp01.png"];
    [backgroundView addSubview:cycleScrollView];
    
    //添加一个跳过软件引导页的按钮
    CGFloat btnSkipGuidge_W = 40;
    CGFloat btnSkipGuidge_H = 40;
    CGFloat btnSkipGuidge_X = cycleScrollView.width - 15 - btnSkipGuidge_W;
    CGFloat btnSkipGuidge_Y = 12;
    UIButton *btnSkipGuidge = [[UIButton alloc]initWithFrame:CGRectMake(btnSkipGuidge_X, btnSkipGuidge_Y, btnSkipGuidge_W, btnSkipGuidge_H)];
    [btnSkipGuidge setTitle:@"跳过" forState:UIControlStateNormal];
    [btnSkipGuidge setTitleColor:[UIColor rgbFromHexString:@"#EAEAEA" alpaa:1.0] forState:UIControlStateNormal];
    [btnSkipGuidge.titleLabel setFont:[UIFont systemFontOfSize:12.0]];
    [btnSkipGuidge addTarget:self action:@selector(skipGuidgeHandle:) forControlEvents:UIControlEventTouchUpInside];
    [cycleScrollView addSubview:btnSkipGuidge];
    
    
}

#pragma mark - SDCycleScrollViewDelegate

- (void)cycleScrollView:(SDCycleScrollView *)cycleScrollView didSelectItemAtIndex:(NSInteger)index
{
    if (index == 3) {
        [self removeFromSuperview];
    }
}

-(void)skipGuidgeHandle:(UIButton *)button{
    [self removeFromSuperview];
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
