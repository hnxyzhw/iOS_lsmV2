//
//  MyWorksVC.m
//  ListenToMe
//
//  Created by yadong on 2/5/15.
//  Copyright (c) 2015 listentome. All rights reserved.
//

#import "MyWorksVC.h"

@implementation MyWorksVC
#pragma mark -生命周期
-(void)viewDidLoad
{
    [super viewDidLoad];
    
    [self setUI];
}

#pragma mark -UI
-(void)setUI
{
 
}
@end
