//
//  YDIndividualVC.m
//  ListenToMe
//
//  Created by yadong on 1/26/15.
//  Copyright (c) 2015 listentome. All rights reserved.
//

#import "YDIndividualVC.h"
#import "MyAlbumVC.h"
#import "MyBookVC.h"
#import "MyCollectionVC.h"
#import "MyGiftCertificateVC.h"
#import "MyMessageVC.h"
#import "MyRecommendVC.h"
#import "MyMusicListVC.h"
#import "MySubscribeVC.h"
#import "MyWorksVC.h"
#import "SettingsVC.h"
#import "PIVC.h"

@interface YDIndividualVC () <UITableViewDelegate,UITableViewDataSource> // UIScrollViewDelegate 哪里用得到
@property(strong,nonatomic) UIScrollView *mScrollView; // 整个页面的滚动视图
@property(strong,nonatomic) UITableView *mTableView;
@property(strong,nonatomic) UIView *viewUserInfo; // 头像 & 个性签名 等个人信息的承载视图
@property(strong,nonatomic) UIImageView *imgAlbum; // 相册封面页
@property(strong,nonatomic) UIButton *btnAvatar;
@property(strong,nonatomic) UIImageView *imgMask; // 头像外围的白框
@property(strong,nonatomic) UILabel *lbUserName;
@property(strong,nonatomic) UIButton *btnRank;
@property(strong,nonatomic) UIButton *btnFlower;
@property(strong,nonatomic) UILabel *lbDesc; // 个性签名
@property(strong,nonatomic) UIButton *btnAccessoty; // 更改签名的Btn
@end

@implementation YDIndividualVC                                                                                                                                                                                                                                                                       
@synthesize mScrollView;
@synthesize mTableView;
@synthesize viewUserInfo;
@synthesize imgAlbum;
@synthesize btnAvatar;
@synthesize imgMask;
@synthesize lbUserName;
@synthesize btnRank;
@synthesize btnFlower;
@synthesize lbDesc;
@synthesize btnAccessoty;

#pragma mark -生命周期
- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setUI];
    
}

#pragma mark -UI
-(void)setUI
{
 
    
    [self setRightBtnItem];
    
    [self setScrollView];
}

#pragma mark  滚动视图
-(void)setScrollView
{
    mScrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, screenWidth, screenHeight)];
    mScrollView.contentSize = CGSizeMake(screenWidth, 1000);
    [self.view addSubview:mScrollView];
    
    mScrollView.showsVerticalScrollIndicator = NO;
    
    [self setImgAlbum];
    [self setViewUserInfo];
}

#pragma mark tableview
-(void)setTableView
{
    mTableView = [[UITableView alloc]initWithFrame:CGRectMake(0, viewUserInfo.frame.origin.y + viewUserInfo.frame.size.height + 10, screenWidth, 800) style:UITableViewStyleGrouped];
    [mScrollView addSubview:mTableView];
    
    mTableView.backgroundColor = [UIColor clearColor];
    mTableView.scrollEnabled = NO;
    mTableView.delegate = self;
    mTableView.dataSource = self;
}

#pragma mark 相册封页
-(void)setImgAlbum
{
    imgAlbum = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, screenWidth, 80)];
    imgAlbum.backgroundColor = [UIColor greenColor];
    [mScrollView addSubview:imgAlbum];
    
    UIButton *btnAlbum = [[UIButton alloc]initWithFrame:imgAlbum.frame];
    [mScrollView addSubview:btnAlbum];
    btnAlbum.backgroundColor = [UIColor clearColor];
    [btnAlbum addTarget:self action:@selector(clickImgAlbum) forControlEvents:UIControlEventTouchUpInside];
}

#pragma mark 个人信息的承载页
-(void)setViewUserInfo
{
    // 个人信息承载页
    viewUserInfo = [[UIView alloc]initWithFrame:CGRectMake(0,imgAlbum.frame.origin.y + imgAlbum.frame.size.height, screenWidth, 70)];
    viewUserInfo.backgroundColor = [UIColor orangeColor];
    [mScrollView addSubview:viewUserInfo];
    
    // 头像
    btnAvatar = [[UIButton alloc]initWithFrame:CGRectMake(35, - 20, 40, 40)];
    btnAvatar.backgroundColor = [UIColor redColor];
    [viewUserInfo addSubview:btnAvatar];
    
    [btnAvatar addTarget:self action:@selector(clickAvatar) forControlEvents:UIControlEventTouchUpInside];
    btnAvatar.layer.cornerRadius = 0.2 * btnAvatar.frame.size.width;
    btnAvatar.layer.masksToBounds = YES;
    
    // mask
    imgMask = [[UIImageView alloc]initWithFrame:btnAvatar.frame];
    
    // 用户名
    lbUserName = [[UILabel alloc]initWithFrame:CGRectMake(btnAvatar.frame.size.height + btnAvatar.frame.origin.x + 10, 10, 40, 20)];
    viewUserInfo.backgroundColor = [UIColor blueColor];
    [viewUserInfo addSubview:lbUserName];
    
    // 个性签名
    lbDesc = [[UILabel alloc]initWithFrame:CGRectMake(btnAvatar.frame.origin.x, btnAvatar.frame.size.height, 290, 20)];
    lbDesc.backgroundColor = [UIColor whiteColor];
    [viewUserInfo addSubview:lbDesc];
    
    [lbDesc setText:@"深夜，听着紧随的脚步声，突然，哦，我的..."];
    
    // 更改签名Btn
    btnAccessoty = [[UIButton alloc]initWithFrame:CGRectMake(screenWidth - 30, lbDesc.center.y, 10, 15)];
    btnAccessoty.backgroundColor = [UIColor purpleColor];
    [viewUserInfo addSubview:btnAccessoty];
    
    // 等级
    btnRank = [[UIButton alloc]initWithFrame:CGRectMake(screenWidth - 230, 20, 50, 10)];
    [btnRank setTitle:@"Baby" forState:UIControlStateNormal];
    [viewUserInfo addSubview:btnRank];
    
    // 花
    btnFlower = [[UIButton alloc]initWithFrame:CGRectMake(screenWidth - 160, 20, 80, 10)];
    [btnFlower setTitle:@"comeOn" forState:UIControlStateNormal];
    [viewUserInfo addSubview:btnFlower];
    
    [self setTableView];
}

#pragma mark 导航栏右边的Btn
-(void)setRightBtnItem
{
    UIButton *rightBtn = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, 10, 40)];
    rightBtn.backgroundColor = [UIColor whiteColor];
    [rightBtn addTarget:self action:@selector(clickRightBarBtnItem) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *customRightBtnItem = [[UIBarButtonItem alloc]initWithCustomView:rightBtn];
    self.navigationItem.rightBarButtonItem = customRightBtnItem;

}


#pragma mark -点击事件
-(void)clickRightBarBtnItem
{
    YDLog(@"点击了导航栏的右边按钮");
}

-(void)clickImgAlbum
{
    YDLog(@"点击了相册封面");
}

-(void)clickAvatar
{
    YDLog(@"点击了头像");
}

#pragma mark 点击了cell
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    YDLog(@"点击了第 %ld组- 第 %ld行",(long)indexPath.section,(long)indexPath.row);
    switch (indexPath.section) {
            //  组
        case 0:{
            // row
            switch (indexPath.row) {
                case 0:{
                    MyAlbumVC *myAlbumVC = [[MyAlbumVC alloc]init];
                    [self.navigationController pushViewController:myAlbumVC animated:YES];
                    break;
                }case 1:{
                    MyMessageVC *myMessageVC = [[MyMessageVC alloc]init];
                    [self.navigationController pushViewController:myMessageVC animated:YES];
                    break;
                }case 2:{
                    MyWorksVC *myWorksVC = [[MyWorksVC alloc]init];
                    [self.navigationController pushViewController:myWorksVC animated:YES];
                    break;
                    
                }case 3:{
                    MySubscribeVC *mySubscribeVC = [[MySubscribeVC alloc]init];
                    [self.navigationController pushViewController:mySubscribeVC animated:YES];
                    break;
                    
                }case 4:{
                    MyBookVC *myBookVC = [[MyBookVC alloc]init];
                    [self.navigationController pushViewController:myBookVC animated:YES];
                    break;
                }case 5:{
                    PIVC *piVC = [[PIVC alloc]init];
                    [self.navigationController pushViewController:piVC animated:YES];
                    break;
                }
                    
                default:
                    break;
            }
            break;
        }
            //  组
        case 1:{
            // row
            switch (indexPath.row) {
                case 0:{
                    MyMusicListVC *myMusicListVC = [[MyMusicListVC alloc]init];
                    [self.navigationController pushViewController:myMusicListVC animated:YES];
                    break;
                }case 1:{
                    MyCollectionVC *myCollectionVC = [[MyCollectionVC alloc]init];
                    [self.navigationController pushViewController:myCollectionVC animated:YES];
                    break;
                }case 2:{
                    MyGiftCertificateVC *myGiftCertificateVC = [[MyGiftCertificateVC alloc]init];
                    [self.navigationController pushViewController:myGiftCertificateVC animated:YES];
                    break;
                }
                default:
                    break;
            }
            break;
            
        }
            //  组
        case 2:{
            MyRecommendVC *myRecommendVC = [[MyRecommendVC alloc]init];
            [self.navigationController pushViewController:myRecommendVC animated:YES];
            break;
        }
            //  组
        case 3:{
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"itms-apps://itunes.apple.com/cn/app/jie-zou-da-shi/id493901993?mt=8"]];
            break;
            
        }
            // 组
        case 4:{
            SettingsVC *settingsVC = [[SettingsVC alloc]init];
            [self.navigationController pushViewController:settingsVC animated:YES];
            break;
        }
        default:
            break;
    }
    
}

#pragma mark -tableview代理 & 数据源
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    
    static NSString *identifier = @"individual";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (nil == cell) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    
    switch (indexPath.section) {
            // 0 组
        case 0:{
            // row
            switch (indexPath.row) {
                case 0:{
                    cell.textLabel.text = @"我的相册";
                    break;
                }case 1:{
                    cell.textLabel.text = @"我的消息";
                    break;
                }case 2:{
                    cell.textLabel.text = @"我的作品";
                    break;
                    
                }case 3:{
                    cell.textLabel.text = @"我的约歌";
                    break;
                    
                }case 4:{
                    cell.textLabel.text = @"我的纪念册";
                    break;
                }case 5:{
                    cell.textLabel.text = @"个人信息";
                    break;
                }
                    
                default:
                    break;
            }
            break;
        }
            // 0 组
        case 1:{
            // row
            switch (indexPath.row) {
                case 0:{
                    cell.textLabel.text = @"我的歌单";
                    break;
                }case 1:{
                    cell.textLabel.text = @"我的收藏";
                    break;
                }case 2:{
                    cell.textLabel.text = @"我的礼券";
                    break;
                }
                default:
                    break;
            }
            break;
            
        }
            // 0 组
        case 2:{
            cell.textLabel.text = @"推荐使用";
            break;
        }
            // 0 组
        case 3:{
            cell.textLabel.text = @"写好评";
            break;
            
        }
            // 0 组
        case 4:{
            cell.textLabel.text = @"设置";
            break;
        }
        default:
            break;
    }
    
    cell.accessoryType =  UITableViewCellAccessoryDisclosureIndicator;
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    return cell;
    
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 5;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    switch (section) {
        case 0:{
            return 6;
            break;
        }
        case 1:{
            return 3;
            break;
        }
        case 2:{
            return 1;
            break;
        }
        case 3:{
            return 1;
            break;
        }
        case 4:{
            return 1;
            break;
        }
        default:
            return 0;
            break;
    }
    
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 25;
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *ydHeadView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, screenWidth, 25)];
    ydHeadView.backgroundColor = [UIColor clearColor];
    
    return ydHeadView;
}

#pragma mark -其他
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
