//
//  PIVC.m
//  ListenToMe
//
//  Created by yadong on 2/7/15.
//  Copyright (c) 2015 listentome. All rights reserved.
//

#import "PIVC.h"

@interface PIVC ()<UITableViewDataSource,UITableViewDelegate,UITextFieldDelegate,UIActionSheetDelegate,UIImagePickerControllerDelegate>
@property(strong,nonatomic) UIScrollView *mScrollView;
@property(strong,nonatomic) UITableView *mTableView;
@property(strong,nonatomic) UIButton *btnAvatar;
@property(strong,nonatomic) UITextField *textFdNickName;
@property(strong,nonatomic) UITextField *textFdLocation;
@property(strong,nonatomic) UITextField *textFdDesc;
@property(strong,nonatomic) UIDatePicker *datePicker;
@property(strong,nonatomic) UIButton *timeCancelBtn;
@property(strong,nonatomic) UIButton *timeChooseBtn;
@property(strong,nonatomic) UIView *viewBtnBG;
@property(strong,nonatomic) UILabel *lbBirthday;
@property(assign,nonatomic) BOOL keyboardIsShow;
@property(strong,nonatomic) UIAlertController *alertCtrl;
@end

@implementation PIVC
@synthesize btnAvatar;
@synthesize mTableView;
@synthesize textFdNickName;
@synthesize textFdLocation;
@synthesize textFdDesc;
@synthesize datePicker;
@synthesize timeCancelBtn;
@synthesize timeChooseBtn;
@synthesize viewBtnBG;
@synthesize lbBirthday;
@synthesize keyboardIsShow;
@synthesize mScrollView;

#pragma mark -生命周期
- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setMData];
    
    [self setUI];
}

#pragma mark -Data
-(void)setMData
{
    keyboardIsShow = NO;
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardDidShowRec:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHideRec:) name:UIKeyboardWillHideNotification object:nil];
    
}

#pragma mark -UI
-(void)setUI
{
    // 滚动视图
    CGFloat mScrollViewW = screenWidth;
    CGFloat mScrollViewH = screenHeight;
    CGFloat mScrollViewX = 0;
    CGFloat mScrollViewY = 0;
    mScrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(mScrollViewX, mScrollViewY, mScrollViewW, mScrollViewH)];
    mScrollView.delegate = self;
    mScrollView.scrollEnabled = YES;
    [self.view addSubview:mScrollView];
    
    mScrollView.contentSize = CGSizeMake(screenWidth, screenHeight);
    
    // tableView
    CGFloat mTableViewW = screenWidth;
    CGFloat mTableViewH = screenHeight + 20;
    CGFloat mTableViewX = 0;
    CGFloat mTableViewY = -20;
    mTableView = [[UITableView alloc]initWithFrame:CGRectMake(mTableViewX, mTableViewY, mTableViewW, mTableViewH) style:UITableViewStyleGrouped];
    mTableView.delegate = self;
    mTableView.dataSource = self;
    [mScrollView addSubview:mTableView];
    
    mTableView.scrollEnabled = NO;
    
}

#pragma mark -点击Actionsheet对应Btn的事件
-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    YDLog(@"这是第几个btn--%ld",buttonIndex);
    if (buttonIndex == 0) {
        
    }else if(buttonIndex == 1){
        
        [self openAlbum];
        
    }else if(buttonIndex == 2){
        [self openCamera];
    }else if(buttonIndex == 3){
        
    }else {
        YDLog(@"不可能");
    }
}

#pragma mark 初始化actionsheet
-(void)presentSheet
{
    
    if (iOS8_greater) { // iOS8及其以上
        _alertCtrl = [UIAlertController alertControllerWithTitle:nil message:nil preferredStyle:UIAlertControllerStyleActionSheet];
        
        [_alertCtrl addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];
        [_alertCtrl addAction:[UIAlertAction actionWithTitle:@"我的相册" style:UIAlertActionStyleDefault handler:nil]];
        [_alertCtrl addAction:[UIAlertAction actionWithTitle:@"本地相册" style:UIAlertActionStyleDefault handler:nil]];
        [_alertCtrl addAction:[UIAlertAction actionWithTitle:@"拍摄" style:UIAlertActionStyleDefault handler:nil]];
        
        [[UIView appearanceWhenContainedIn:[UIAlertController class], nil] setTintColor:[UIColor purpleColor]];
       
        [self presentViewController:_alertCtrl animated:YES completion:^{
        
        }];

        
    }else{ // iOS7及其以下
        
        UIActionSheet *menu = [[UIActionSheet alloc]initWithTitle:nil delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"我的相册",@"本地相册",@"拍摄", nil];
        
        [menu showInView:self.view];
    }
}

// ActionSheet的代理方法，设置其文字颜色
// iOS8 无法这样设置, actionSheet.subviews.count == 0
-(void)willPresentActionSheet:(UIActionSheet *)actionSheet
{
    if (iOS7_less) {
        for (UIView *subView in actionSheet.subviews) {
            
            if ([subView isKindOfClass:[UIButton class]]) {
                UIButton *btn = (UIButton *)subView;
                [btn setTitleColor:[UIColor purpleColor] forState:UIControlStateNormal];
            }
        }
    } else if(iOS8_greater){
        
                YDLog(@"iOS8下，ActionSheet的字体颜色设置不能通过遍历其子控件的方式来实现\n改用actionsheete为alertController");
    }
}

#pragma mark -键盘遮挡输入框
#pragma mark 显示 or 隐藏键盘
-(void)keyboardDidShowRec:(NSNotification *)noti
{
    if (keyboardIsShow) {
        return;
    }
    
    NSDictionary *userInfo = [noti userInfo];
    // get the size of the keyboard
    CGSize keyboardSize = [[userInfo objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size;
    
    // get original scrollview,then reSize it'frame
    CGRect oldToNewSViewFrame = mScrollView.frame;
    oldToNewSViewFrame.size.height -= (keyboardSize.height);
    
    [mScrollView setFrame:oldToNewSViewFrame];
    [UIView commitAnimations];
    
    // 滚动到当前UITextView
    //    CGRect textViewFrame = [textFdDesc frame];
    CGRect textViewFrame = CGRectMake(0,300, screenWidth, 20);
    
    [mScrollView scrollRectToVisible:textViewFrame animated:YES];
    
    keyboardIsShow = YES;
}

-(void)keyboardWillHideRec:(NSNotification *)noti
{
    
    //    NSDictionary *userinfo = [noti userInfo];
    //    CGSize keyboardSize = [[userinfo objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].size;
    
    // newToOldFrame
    //    CGRect newToOldFrame = mScrollView.frame;
    //    newToOldFrame.size.height += keyboardSize.height;
    CGRect scrollToFrame = CGRectMake(0, 20, screenWidth, 20);
    [mScrollView scrollRectToVisible:scrollToFrame animated:YES];
    
    mScrollView.frame = CGRectMake(0, 0, screenWidth, screenHeight);
    
    if (!keyboardIsShow) {
        return;
    }
    
    keyboardIsShow = NO;
}



#pragma mark -textField的代理方法
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [self.view endEditing:YES];
    
    // 保存操作
    
    return YES;
}

#pragma mark -delegate & datasource
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"personalInfo";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:identifier];
    }
    
    if (indexPath.section == 0) {
        if (indexPath.row == 0) {
            
            cell.textLabel.text = @"头像";
            
            CGFloat btnAvatarW = 30;
            CGFloat btnAvatarH = 30;
            CGFloat btnAvatarX = screenWidth - 80;
            CGFloat btnAvatarY = ( 50 - btnAvatarH ) * 0.5;
            btnAvatar = [[UIButton alloc]initWithFrame:CGRectMake(btnAvatarX, btnAvatarY, btnAvatarW, btnAvatarH)];
            [cell addSubview:btnAvatar];
            
            btnAvatar.layer.cornerRadius = 5;
            btnAvatar.layer.masksToBounds = YES;
            btnAvatar.backgroundColor = [UIColor orangeColor];
            
        }else if(indexPath.row == 1){
            cell.textLabel.text = @"昵称";
            
            CGFloat textFdNickNameW = screenWidth * 0.5;
            CGFloat textFdNickNameH = 44;
            CGFloat textFdNickNameX = screenWidth - textFdNickNameW - 30; // 30是更多图标的宽度
            CGFloat textFdNickNameY = 0;
            textFdNickName = [[UITextField alloc]initWithFrame:CGRectMake(textFdNickNameX, textFdNickNameY, textFdNickNameW, textFdNickNameH)];
            [cell addSubview:textFdNickName];
            
            textFdNickName.text = @"念念不忘de昵称";
            textFdNickName.delegate = self;
            textFdNickName.textColor = [UIColor lightGrayColor];
            textFdNickName.textAlignment = NSTextAlignmentRight;
            
        }else if(indexPath.row == 2){
            cell.textLabel.text = @"生日";
            
            CGFloat lbBirthdayW = screenWidth * 0.5;
            CGFloat lbBirthdayH = 44;
            CGFloat lbBirthdayX = screenWidth - lbBirthdayW - 30; // 30是更多图标的宽度
            CGFloat lbBirthdayY = 0;
            lbBirthday = [[UILabel alloc]initWithFrame:CGRectMake(lbBirthdayX, lbBirthdayY, lbBirthdayW, lbBirthdayH)];
            [cell addSubview:lbBirthday];
            
            lbBirthday.text = @"06-12 双子座";
            lbBirthday.textColor = [UIColor lightGrayColor];
            lbBirthday.textAlignment = NSTextAlignmentRight;
            
        }else if(indexPath.row == 3){
            cell.textLabel.text = @"性别";
            cell.detailTextLabel.text = @"男";
        }else if (indexPath.row == 4){
            cell.textLabel.text = @"所在地";
            
            CGFloat textFdLocationW = screenWidth * 0.5;
            CGFloat textFdLocationH = 44;
            CGFloat textFdLocationX = screenWidth - textFdLocationW - 30; // 30是更多图标的宽度
            CGFloat textFdLocationY = 0;
            textFdLocation = [[UITextField alloc]initWithFrame:CGRectMake(textFdLocationX, textFdLocationY, textFdLocationW, textFdLocationH)];
            [cell addSubview:textFdLocation];
            
            textFdLocation.text = @"北京";
            textFdLocation.delegate = self;
            textFdLocation.textColor = [UIColor lightGrayColor];
            textFdLocation.textAlignment = NSTextAlignmentRight;
        }
        
    }else if(indexPath.section == 1){
        cell.textLabel.text = @"个性签名";
        
        CGFloat textFdDescW = screenWidth * 0.5;
        CGFloat textFdDescH = 44;
        CGFloat textFdDescX = screenWidth - textFdDescW - 30; // 30是更多图标的宽度
        CGFloat textFdDescY = 0;
        textFdDesc = [[UITextField alloc]initWithFrame:CGRectMake(textFdDescX, textFdDescY, textFdDescW, textFdDescH)];
        [cell addSubview:textFdDesc];
        
        textFdDesc.text = @"个性签名,sorry";
        textFdDesc.delegate = self;
        textFdDesc.textAlignment = NSTextAlignmentRight;
        [textFdDesc setTextColor:[UIColor lightGrayColor]];
    }
    
    
    
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (datePicker.hidden == NO) {
        datePicker.hidden = YES;
        viewBtnBG.hidden = YES;
    }
    
    if (indexPath.section == 0) {
        if (indexPath.row == 0) {
            YDLog(@"修改头像");
            [self presentSheet];
        }else if(indexPath.row == 1){
            YDLog(@"修改昵称");
        }else if(indexPath.row == 2){
            
            YDLog(@"修改生日");
            [self setupDatePicker];
            
        }else if(indexPath.row == 3){
            YDLog(@"修改性别");
        }else if (indexPath.row == 4){
            YDLog(@"修改所在地");
        }
    }else if(indexPath.section == 1){
        YDLog(@"修改个性签名");
    }
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section == 0) {
        return 5;
    }else{
        return 1;
    }
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 50;
}


#pragma mark  - 时间选择器
-(void)setupDatePicker
{
    if (datePicker == nil) {
        // 时间选择器
        CGFloat datePickerW = screenWidth;
        CGFloat datePickerH = 200;
        CGFloat datePickerX = 0;
        CGFloat datePickerY = screenHeight - datePickerH + 20;
        CGRect datePickerFrame = CGRectMake(datePickerX, datePickerY, datePickerW, datePickerH);
        self.datePicker = [[UIDatePicker alloc]init];
        [self.datePicker setFrame:datePickerFrame];
        [mScrollView addSubview:self.datePicker];
        
        self.datePicker.backgroundColor = [UIColor colorWithRed:255 green:255 blue:255 alpha:1.0];
        self.datePicker.datePickerMode = UIDatePickerModeDate;
        [self.datePicker setDate:[NSDate date]];
        [self.datePicker addTarget:self action:@selector(dateTimeChange) forControlEvents:UIControlEventValueChanged];
        
        // 按钮的承载视图
        CGFloat viewBtnBGW = screenWidth;
        CGFloat viewBtnBGH = 30;
        CGFloat viewBtnBGX = 0;
        CGFloat viewBtnBGY = datePickerY - viewBtnBGH;
        viewBtnBG = [[UIView alloc]initWithFrame:CGRectMake(viewBtnBGX, viewBtnBGY, viewBtnBGW, viewBtnBGH)];
        [mScrollView addSubview:viewBtnBG];
        
        [viewBtnBG setBackgroundColor:[UIColor colorWithRed:255 green:255 blue:255 alpha:1.0]];
        
        
        // 取消Btn
        CGFloat timeCancelBtnW = 50;
        CGFloat timeCancelBtnH = 20;
        CGFloat timeCancelBtnX = 50;
        CGFloat timeCancelBtnY = 0.5 * (viewBtnBGH - timeCancelBtnH);
        CGRect timeCancelBtnFrame = CGRectMake(timeCancelBtnX, timeCancelBtnY, timeCancelBtnW, timeCancelBtnH);
        self.timeCancelBtn = [[UIButton alloc]initWithFrame:timeCancelBtnFrame];
        [viewBtnBG addSubview:self.timeCancelBtn];
        
        [self.timeCancelBtn setTitle:@"取消" forState:UIControlStateNormal];
        [self.timeCancelBtn setTitleColor:[UIColor rgbFromHexString:@"#573305" alpaa:1.0] forState:UIControlStateNormal];
        [self.timeCancelBtn addTarget:self action:@selector(clickTimeCancelBtn) forControlEvents:UIControlEventTouchUpInside];
        
        // 确定Btn
        CGFloat timeChooseBtnW = timeCancelBtnW;
        CGFloat timeChooseBtnH = timeCancelBtnH;
        CGFloat timeChooseBtnX = screenWidth - timeCancelBtnX - timeChooseBtnW;
        CGFloat timeChooseBtnY = 0.5 * ( viewBtnBGH - timeChooseBtnH);
        CGRect timeChooseBtnFrame = CGRectMake(timeChooseBtnX, timeChooseBtnY, timeChooseBtnW, timeChooseBtnH);
        self.timeChooseBtn = [[UIButton alloc]initWithFrame:timeChooseBtnFrame];
        [viewBtnBG addSubview:self.timeChooseBtn];
        
        [self.timeChooseBtn setTitle:@"确定" forState:UIControlStateNormal];
        [self.timeChooseBtn setTitleColor:[UIColor rgbFromHexString:@"#573305" alpaa:1.0] forState:UIControlStateNormal];
        [self.timeChooseBtn addTarget:self action:@selector(clickTimeChooseBtn) forControlEvents:UIControlEventTouchUpInside];
        
    }
    
    if (viewBtnBG.hidden == YES && datePicker.hidden == YES) {
        viewBtnBG.hidden = NO;
        datePicker.hidden = NO;
    }
    
}

-(void)dateTimeChange
{
    NSDate *select = [self.datePicker date];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
    [dateFormatter setDateFormat:@"MM-dd"];
    NSString *dateAndTime = [dateFormatter stringFromDate:select];
    [lbBirthday setText:dateAndTime];
    
    [lbBirthday setFont:[UIFont systemFontOfSize:12.0]];
    [lbBirthday setTextColor:[UIColor whiteColor]];
}

#pragma mark -按钮点击事件
/**
 * 打开听我的相册
 */

/**
 * 打开本地相册
 */
-(void)openAlbum
{
    UIImagePickerController *pickerImage = [[UIImagePickerController alloc] init];
    if([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary]) {
        pickerImage.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        //pickerImage.sourceType = UIImagePickerControllerSourceTypeSavedPhotosAlbum;
        pickerImage.mediaTypes = [UIImagePickerController availableMediaTypesForSourceType:pickerImage.sourceType];
        
    }
    pickerImage.delegate = (id)self;
    pickerImage.allowsEditing = NO;
    [self presentViewController:pickerImage animated:YES completion:^{
        
    }];
    
}

/**
 * 拍摄--打开相机
 */
-(void)openCamera
{
    //先设定sourceType为相机，然后判断相机是否可用（ipod）没相机，不可用将sourceType设定为相片库
    UIImagePickerControllerSourceType sourceType = UIImagePickerControllerSourceTypeCamera;
    //    if (![UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypeCamera]) {
    //        sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    //    }
    //sourceType = UIImagePickerControllerSourceTypeCamera; //照相机
    //sourceType = UIImagePickerControllerSourceTypePhotoLibrary; //图片库
    //sourceType = UIImagePickerControllerSourceTypeSavedPhotosAlbum; //保存的相片
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];//初始化
    picker.delegate = (id)self;
    picker.allowsEditing = YES;//设置可编辑
    picker.sourceType = sourceType;
    [self presentViewController:picker animated:YES completion:^{
        
    }];
    
}

/**
 * 当选择一张照片后，进入这里
 */
#pragma makr 当选择一张照片之后进入这里
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    // 定义类型
    NSString *type = [info objectForKey:UIImagePickerControllerMediaType];
    // 当选择的类型是图片
    if ([type isEqualToString:@"public.image"]) {
        // 先把图片转成NSData
        UIImage *image = [info objectForKey:@"UIImagePickerControllerOriginalImage"];
        
        if (UIImagePNGRepresentation(image) == nil) {
            //            NSData *tempData = UIImageJPEGRepresentation(image, 0.1);
        }else{
            //            data = UIImagePNGRepresentation(image);
            //             NSData *tempData = UIImageJPEGRepresentation(image, 0.1);
        }
        
        // 关闭相册界面
        [picker dismissViewControllerAnimated:YES completion:^{
            
            // 替换头像为选择的图片
            
            
        }];
        
    }
}

/**
 * 点击取消Btn
 */
-(void)clickTimeCancelBtn
{
    YDLog(@"取消时间选择");
    self.datePicker.hidden = YES;
    self.viewBtnBG.hidden = YES;
    
}

/**
 * 点击确定Btn
 */
-(void)clickTimeChooseBtn
{
    YDLog(@"确定选择时间");
    self.datePicker.hidden = YES;
    self.viewBtnBG.hidden = YES;
}


#pragma mark -其他
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
