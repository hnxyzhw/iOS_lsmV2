//
//  MyMessageVC.m
//  ListenToMe
//
//  Created by yadong on 2/5/15.
//  Copyright (c) 2015 listentome. All rights reserved.
//

#import "MyMessageVC.h"
#import "OfficialMsgVC.h"
#import "MsgCell.h"
#import "FriendsMsgVC.h"

@interface MyMessageVC ()<UISearchBarDelegate,UITextFieldDelegate,UITableViewDataSource,UITableViewDelegate>
@property(strong,nonatomic) UISearchBar *msgSearchBar;
@property(strong,nonatomic) UIButton *BtnGrayBg;
@property(strong,nonatomic) UITableView *mTableView;
@end

@implementation MyMessageVC
@synthesize msgSearchBar;
@synthesize BtnGrayBg;
@synthesize mTableView;

#pragma mark -生命周期
-(void)viewDidLoad
{
    [super viewDidLoad];
    
    [self setUI];
}

#pragma mark -UI
-(void)setUI
{
 
    
    [self setSearchBar];
    
    [self setUpTableView];
}

#pragma mark 搜索框
-(void)setSearchBar
{
    CGFloat msgSearchBarW = screenWidth;
    CGFloat msgSearchBarH = 40;
    CGFloat msgSearchBarX = 0;
    CGFloat msgSearchBarY = 64;
    msgSearchBar = [[UISearchBar alloc]initWithFrame:CGRectMake(msgSearchBarX, msgSearchBarY, msgSearchBarW, msgSearchBarH)];
    [self.view addSubview:msgSearchBar];
    
    msgSearchBar.delegate = self;
    
    msgSearchBar.placeholder = @"搜索";
    
    // 去掉搜索栏边框
    msgSearchBar.backgroundColor = [UIColor clearColor];
    msgSearchBar.backgroundImage = nil;
}


#pragma mark tableView
-(void)setUpTableView
{
    CGFloat mTableViewW = screenWidth;
    CGFloat mTableViewH = screenHeight - msgSearchBar.frame.origin.y - msgSearchBar.frame.size.height;
    CGFloat mTableViewX = 0;
    CGFloat mTableViewY = msgSearchBar.frame.origin.y + msgSearchBar.frame.size.height - 15;
    mTableView = [[UITableView alloc]initWithFrame:CGRectMake(mTableViewX, mTableViewY, mTableViewW, mTableViewH) style:UITableViewStyleGrouped];
    [self.view addSubview:mTableView];
    
    mTableView.delegate = self;
    mTableView.dataSource = self;
    mTableView.backgroundColor = [UIColor clearColor];
}

#pragma mark - tableView的 delegate & datasource
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section == 0) {
        return 1;
    }else{
    return 10;
    }
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
    
}

-(MsgCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"msg";
    MsgCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[MsgCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 60;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    // 暂时这样，后面加上消息的类型来进行判断
    // 如果有 2组的话，则第0组是官方消息
    if (2 == tableView.numberOfSections) {
        if (indexPath.section == 0) {
            [self.navigationController pushViewController:[[OfficialMsgVC alloc]init] animated:YES];
        } else if(indexPath.section == 1){
            [self.navigationController pushViewController:[[FriendsMsgVC alloc] init] animated:YES];
        }
    }
}

#pragma mark -searchBar的代理
#pragma mark 开始输入
-(void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar
{
    [msgSearchBar setShowsCancelButton:YES animated:YES];
    
    [self setUpGrayBacground];
}

#pragma mark 点击取消Btn
-(void)searchBarCancelButtonClicked:(UISearchBar *)searchBar
{
    [UIView animateWithDuration:0.5 animations:^{
        
        [self cancelGrayBacground];
    }];
}

#pragma mark 点击搜索键
- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    YDLog(@"点击搜索Btn");
    [msgSearchBar setShowsCancelButton:NO animated:YES];
    BtnGrayBg.alpha = 0.0;
    BtnGrayBg = nil;
    [msgSearchBar resignFirstResponder];
}


#pragma mark - 点击事件
-(void)btnGrayBgClick{

    [msgSearchBar setShowsCancelButton:NO animated:YES];
    BtnGrayBg.alpha = 0.0;
    BtnGrayBg = nil;
    [msgSearchBar resignFirstResponder];
}

#pragma mark -灰质背景
// 取消灰质背景
-(void)cancelGrayBacground
{
    // 隐藏cancelBtn & 取消灰质 & 注销第一响应
    [msgSearchBar setShowsCancelButton:NO animated:YES];
    BtnGrayBg.alpha = 0.0;
    BtnGrayBg = nil;
    msgSearchBar.text = @"";
    [msgSearchBar resignFirstResponder];
}

// 初始化灰质背景
-(void)setUpGrayBacground
{
    if (BtnGrayBg == nil) {
        BtnGrayBg = [UIButton buttonWithType:UIButtonTypeCustom];
        BtnGrayBg.frame = CGRectMake(0, msgSearchBar.frame.origin.y + msgSearchBar.frame.size.height, screenWidth, screenHeight - (msgSearchBar.frame.size.height + msgSearchBar.frame.origin.y));
        [self.view addSubview:BtnGrayBg];

        [BtnGrayBg addTarget:self action:@selector(btnGrayBgClick) forControlEvents:UIControlEventTouchUpInside];
    }
    
    BtnGrayBg.alpha = 0.0;
    BtnGrayBg.backgroundColor = [UIColor blackColor];
    [self.view bringSubviewToFront:BtnGrayBg];
    
    // screen灰质的block动画
    [UIView animateWithDuration:0.5 animations:^{
        BtnGrayBg.alpha = 0.35;
    }];
    
}
@end



