//
//  FriendsMsgVC.m
//  ListenToMe
//
//  Created by yadong on 2/7/15.
//  Copyright (c) 2015 listentome. All rights reserved.
//

#import "FriendsMsgVC.h"
#import "FreindMsgModel.h"
#import "FreindMsgFrameModel.h"
#import "FriendMsgCell.h"

@interface FriendsMsgVC ()<UITableViewDataSource,UITableViewDelegate,UITextFieldDelegate>
@property(strong,nonatomic) UITableView *mTableView;
/**
 * 顶部工具栏
 */
@property(strong,nonatomic) UIView *viewTopBar;
/**
 * 底部工具栏
 */
@property(strong,nonatomic) UIView *viewBottom;
@property(strong,nonatomic) UIButton *btnGift;
@property(strong,nonatomic) UIButton *btnSong;
@property(strong,nonatomic) UIButton *btnBlackRoom;
/**
 * 存放---消息数据
 */
@property(strong,nonatomic) NSMutableArray *arrayMessages;
/**
 * 存放所有的自动回复数据
 */
@property(strong,nonatomic) NSDictionary *dicAutoReplays;
/**
 * 输入框架
 */
@property(strong,nonatomic) UITextField *textFInput;
@end

@implementation FriendsMsgVC

#pragma mark -生命周期
- (void)viewDidLoad {
    [super viewDidLoad];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillChange:) name:UIKeyboardWillChangeFrameNotification object:nil];
    
    [self setUpUI];
}


#pragma mark -UI
-(void)setUpUI
{
    [self setUpviewTopBar];
    
    [self setUpBottom];
    
    [self setUpTableview];
}

#pragma mark 顶部-工具栏
-(void)setUpviewTopBar
{
    _viewTopBar = [[UIView alloc]initWithFrame:CGRectMake(0,naviAndStatusH, screenWidth, 50)];
    [_viewTopBar setBackgroundColor:[UIColor whiteColor]];
    [self.view addSubview:_viewTopBar];
    
    CGFloat btnsW = 40;
    CGFloat btnsH = 40;
    CGFloat btnsY = 5;
    
    // 送礼物
    _btnGift = [[UIButton alloc]initWithFrame:CGRectMake(20, btnsY, btnsW, btnsH)];
    [_viewTopBar addSubview:_btnGift];
    
    [_btnGift setImage:[UIImage imageNamed:@"temp.png"] forState:UIControlStateNormal];
    
    // 送歌
    _btnSong = [[UIButton alloc]initWithFrame:CGRectMake((screenWidth - btnsW) * 0.5, btnsY, btnsW, btnsH)];
    [_viewTopBar addSubview:_btnSong];
    
    [_btnSong setImage:[UIImage imageNamed:@"temp.png"] forState:UIControlStateNormal];
    
    // 关进小黑屋
    _btnBlackRoom = [[UIButton alloc]initWithFrame:CGRectMake(screenWidth - _btnGift.x - btnsW, btnsY, btnsW, btnsH)];
    [_viewTopBar addSubview:_btnBlackRoom];
    
    [_btnBlackRoom setImage:[UIImage imageNamed:@"temp.png"] forState:UIControlStateNormal];
}

#pragma mark 底部-工具栏
-(void)setUpBottom
{
    // 底部承载视图
    _viewBottom = [[UIView alloc]initWithFrame:CGRectMake(0, screenHeight - 60, screenWidth, 60)];
    _viewBottom.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:_viewBottom];
    
    // 输入框
    _textFInput = [[UITextField alloc]initWithFrame:CGRectMake(50, (_viewBottom.height - 35) * 0.5, 260, 35)];
    _textFInput.backgroundColor = [UIColor colorWithRed:0.8 green:0.8 blue:0.8 alpha:1.0];
    [_viewBottom addSubview:_textFInput];
    
    _textFInput.delegate = self;
}

#pragma mark tableview
-(void)setUpTableview
{
    CGFloat tableviewH = screenHeight - naviAndStatusH - _viewTopBar.height - _viewBottom.height;  // tableview的高度
    _mTableView = [[UITableView alloc]initWithFrame:CGRectMake(0, _viewTopBar.y + _viewTopBar.height, screenWidth,tableviewH) style:UITableViewStylePlain];
    _mTableView.backgroundColor = [UIColor clearColor];
    [self.view addSubview:_mTableView];
    
    _mTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    _mTableView.showsVerticalScrollIndicator = NO;
    _mTableView.allowsSelection = NO;
    
    _mTableView.delegate = self;
    _mTableView.dataSource = self;
}

#pragma mark - 懒加载--messages
-(NSMutableArray *)arrayMessages
{
    if (_arrayMessages == nil) {
        NSString *fullPath = [[NSBundle mainBundle] pathForResource:@"messages.plist" ofType:nil];
        NSArray *dictArray = [NSArray arrayWithContentsOfFile:fullPath];
        NSMutableArray *modelsArray = [NSMutableArray arrayWithCapacity:dictArray.count];
        for (NSDictionary *dict in dictArray) {
            // 1.创建当前数据模型
            FreindMsgModel *messageModel = [FreindMsgModel FreindMsgModelWithDict:dict];
            
            // 获取上一次的数据模型
            FreindMsgModel *previousMessageModel = (FreindMsgModel *)[[modelsArray lastObject] message];
            
            // 设置是否隐藏时间
            messageModel.hiddenTime = [messageModel.time isEqualToString:previousMessageModel.time];
            
            
            // 创建frame模型
            FreindMsgFrameModel *msgFrameModel = [[FreindMsgFrameModel alloc]init];
            msgFrameModel.message = messageModel;
            
            // 将frame模型保存到数组中
            [modelsArray addObject:msgFrameModel];
        }
        
        self.arrayMessages = [modelsArray mutableCopy];
    }
    return  _arrayMessages;
}

#pragma mark -delegate & datasource
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    FriendMsgCell *cell = [FriendMsgCell cellWithTableView:tableView];
    cell.messageFrame = self.arrayMessages[indexPath.row];
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    FreindMsgFrameModel *modelFrame = self.arrayMessages[indexPath.row];
    return modelFrame.cellHeight;
}

#pragma mark - Data
#pragma mark 回复信息
-(NSDictionary *)dicAutoReplays
{
    if (_dicAutoReplays == nil) {
        NSString *fullPath = [[NSBundle mainBundle] pathForResource:@"autoReplay.plist" ofType:nil];
        _dicAutoReplays = [NSDictionary dictionaryWithContentsOfFile:fullPath];
    }
    
    return _dicAutoReplays;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.arrayMessages.count;
}

#pragma mark 滚动的时候，注销输入
-(void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    [self.view endEditing:YES];
}

#pragma mark  -点击事件
#pragma mark 点击return键
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    _textFInput.text = @"";
    [self.view endEditing:YES];
    return YES;
}


#pragma mark - 其他
#pragma mark 键盘变化
- (void)keyboardWillChange:(NSNotification  *)notification
{
       // 1.获取键盘的Y值
    NSDictionary *dict  = notification.userInfo;
    CGRect keyboardFrame = [dict[UIKeyboardFrameEndUserInfoKey] CGRectValue];
    CGFloat keyboardY = keyboardFrame.origin.y;
    // 获取动画执行时间
    CGFloat duration = [dict[UIKeyboardAnimationDurationUserInfoKey]doubleValue];
    // 2.计算需要移动的距离
    CGFloat translationY = keyboardY - self.view.frame.size.height;

    [UIView animateWithDuration:duration delay:0.0 options:7 << 16 animations:^{
        // 需要执行动画的代码
        self.view.transform = CGAffineTransformMakeTranslation(0, translationY);
    } completion:^(BOOL finished) {
        // 动画执行完毕执行的代码
    }];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
