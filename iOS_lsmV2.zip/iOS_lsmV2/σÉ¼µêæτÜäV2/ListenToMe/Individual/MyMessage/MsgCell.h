//
//  MsgCell.h
//  ListenToMe
//
//  Created by yadong on 2/6/15.
//  Copyright (c) 2015 listentome. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "YDBadgeBtn.h"
#import "YDCircleAvatarBtn.h"

@interface MsgCell : UITableViewCell
@property(strong,nonatomic) YDBadgeBtn *badgeBtn;
@property(strong,nonatomic) YDCircleAvatarBtn *btnMsgAvatar;
@property(strong,nonatomic) UILabel *lbTalkWith;
@property(strong,nonatomic) UILabel *lbLastMsg;
@property(strong,nonatomic) UILabel *lbLastTime;
@end
