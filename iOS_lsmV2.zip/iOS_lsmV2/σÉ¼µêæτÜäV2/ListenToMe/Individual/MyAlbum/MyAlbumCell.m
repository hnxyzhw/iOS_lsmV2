//
//  MyAlbumCell.m
//  ListenToMe
//
//  Created by yadong on 2/5/15.
//  Copyright (c) 2015 listentome. All rights reserved.
//

#import "MyAlbumCell.h"

@implementation MyAlbumCell
@synthesize imgPicture;
@synthesize btnPicName;
@synthesize lbTime;

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {

        [self setUI];
    }
    return self;
}

-(void)setUI
{
    CGFloat imgPictureW = screenWidth;
    CGFloat imgPictureH = 180;
    CGFloat imgPictureX = 0;
    CGFloat imgPictureY = 0;
    imgPicture = [[UIImageView alloc]initWithFrame:CGRectMake(imgPictureX, imgPictureY, imgPictureW, imgPictureH)];
    [self addSubview:imgPicture];
    
    imgPicture.backgroundColor = [UIColor orangeColor];
    
    
    btnPicName = [[UIButton alloc]initWithFrame:CGRectMake(0, imgPictureY + imgPictureH, screenWidth * 0.7, 20)];
    [self addSubview:btnPicName];
    [btnPicName setTitle:@"同一首歌 - 苏州桥店" forState:UIControlStateNormal];
    [btnPicName setBackgroundColor:[UIColor redColor]];
    
    
    lbTime = [[UILabel alloc]initWithFrame:CGRectMake(screenWidth * 0.7, imgPictureY + imgPictureH, screenWidth * 0.3, 20)];
    [self addSubview:lbTime];
    [lbTime setText:@"2015-06-12"];
    [lbTime setBackgroundColor:[UIColor blueColor]];
}

@end

//@property(strong,nonatomic) UIImageView *imgPicture;
//@property(strong,nonatomic) UIButton *btnPicName;
//@property(strong,nonatomic) UILabel *lbTime;