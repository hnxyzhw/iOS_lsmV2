//
//  ListenToMeData.h
//  ListenToMe
//
//  Created by yadong on 1/27/15.
//  Copyright (c) 2015 listentome. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NetRecvDelegate.h"

@interface ListenToMeData : NSObject

@property(strong,nonatomic) AsyncSocket *socketIns;
@property(strong,nonatomic) NetRecvDelegate *netRecvDelegate;
@property(assign,nonatomic) BOOL bConnecting;
@property(assign,nonatomic) BOOL bConnected;
@property(assign,nonatomic) BOOL bAPMode;


+(ListenToMeData *)getInstance;
@end
